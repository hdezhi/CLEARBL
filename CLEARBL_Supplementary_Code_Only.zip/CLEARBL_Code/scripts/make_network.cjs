const fs=require('fs'),path=require('path'),E=require('ethers'),L=require('./lib.cjs');
const dir=path.resolve(process.argv[2]),n=Number(process.argv[3]||4),routed=process.argv.includes('--routed');fs.mkdirSync(dir,{recursive:true});
const validators=Array.from({length:n},(_,i)=>{let key='0x'+BigInt(501+i).toString(16).padStart(64,'0');let w=new E.Wallet(key);return {key,address:w.address,pub:E.SigningKey.computePublicKey(key,false).slice(4),p2p:39200+i,proxy:(routed?41000:39100)+i,rpc:39400+i};});
const addresses=validators.map(v=>v.address.toLowerCase()).sort();
const extra=E.encodeRlp(['0x'+'00'.repeat(32),addresses,'0x','0x00000000',[]]);
const genesis={config:{chainId:20260929,berlinBlock:0,londonBlock:0,zeroBaseFee:true,ibft2:{blockperiodseconds:1,epochlength:30000,requesttimeoutseconds:2}},nonce:'0x0',timestamp:'0x0',extraData:extra,gasLimit:'0x1c9c380',difficulty:'0x1',mixHash:'0x63746963616c2062797a616e74696e65206661756c7420746f6c6572616e6365',alloc:Object.fromEntries(L.keys.map(k=>[new E.Wallet(k).address.slice(2),{balance:'0x3635c9adc5dea00000'}]))};
fs.writeFileSync(path.join(dir,'genesis.json'),JSON.stringify(genesis,null,2));
for(const [i,v] of validators.entries()){const d=path.join(dir,'node'+i);fs.mkdirSync(d,{recursive:true});fs.writeFileSync(path.join(d,'key'),v.key.slice(2));fs.writeFileSync(path.join(d,'static-nodes.json'),JSON.stringify(validators.filter((_,j)=>j!==i).map(x=>`enode://${x.pub}@127.0.0.1:${x.proxy+(routed?i*100:0)}`)));}
fs.writeFileSync(path.join(dir,'network.json'),JSON.stringify(validators,null,2));
fs.writeFileSync(path.join(dir,'impairment.json'),JSON.stringify({delayMs:0,jitterMs:0,cut:[],seed:260929}));console.log(dir);
