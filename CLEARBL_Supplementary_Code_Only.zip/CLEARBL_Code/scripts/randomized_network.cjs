// Actual local IBFT measurements; Poisson arrivals and paired hot-object traces.
const L=require('./lib.cjs'),fs=require('fs'),path=require('path'),assert=require('assert/strict');
const agent=require('./network_transport.cjs'),sleep=ms=>new Promise(r=>setTimeout(r,ms));
const spec=JSON.parse(fs.readFileSync(path.join(L.root,'experiment-spec18.json'))),cfg=spec.networkCampaign,pilot=process.argv.includes('--pilot'),tag=pilot?'network-pilot':'network';
function rng(seed){let s=seed>>>0;return()=>{s+=0x6D2B79F5;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
(async()=>{
 const net=path.resolve(process.env.CLEARBL_NETWORK),ctx=await L.environment(process.env.CLEARBL_RPC||'http://127.0.0.1:39400');ctx.provider.pollingInterval=150;
 const fixtures=await L.fixture(ctx),pools={};const n=pilot?16:cfg.objects,hotCount=pilot?4:16,warm=pilot?1:cfg.warmupSeconds,duration=pilot?4:cfg.measurementSeconds;
 for(const mode of cfg.modes){const c=fixtures[mode==='direct'?'single':'reserved'];pools[mode]=[];
  for(let i=0;i<n;i+=16){const ids=await Promise.all(Array.from({length:Math.min(16,n-i)},(_,j)=>L.issue(ctx,c,tag+'-'+mode+'-'+(i+j))));pools[mode].push(...ids.map(b=>({b,version:0,controller:1,tail:Promise.resolve()})));}
 }
 const file=path.join(L.root,'results/randomized18',tag+'-cells.jsonl'),resume=process.argv.includes('--resume');
 const cells=resume&&fs.existsSync(file)?fs.readFileSync(file,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
 if(!resume)fs.writeFileSync(file,'');
 const completed=new Set(cells.map(c=>[c.seed,c.rate,c.hotShare,c.mode].join('/')));
 for(const seed of (pilot?[18200]:cfg.seeds))for(const rate of (pilot?[4]:cfg.rates))for(const hotShare of cfg.hotspotShares){
  const rand=rng(seed+rate*100),arrivals=[];let t=0;
  while((t+=-Math.log(1-rand())*1000/rate)<(warm+duration)*1000){const branch=rand(),u=rand(),object=branch<hotShare?Math.floor(u*hotCount):Math.floor(u*n);arrivals.push({plannedMs:t,object});}
  for(const mode of (seed%2?['direct','reserved']:['reserved','direct'])){
   if(completed.has([seed,rate,hotShare,mode].join('/')))continue;
   fs.writeFileSync(path.join(net,'impairment.json'),JSON.stringify({delayMs:20,jitterMs:15,seed,runToken:[seed,rate,hotShare,mode].join('/'),cut:[]}));
   const c=fixtures[mode==='direct'?'single':'reserved'],pool=pools[mode],address=await c.getAddress(),rows=[],samples=[];
   let active=0,pending=0,complete=0,dropped=0,failed=0;const waiters=[];
   const nonces=await Promise.all([9,10,11].map(i=>ctx.provider.getTransactionCount(ctx.wallets[i].address,'pending')));
   const clock=await L.now(ctx),wall=performance.now(),height=await ctx.provider.getBlockNumber();
   const elapsed=()=>performance.now()-wall,warmMs=warm*1000,endMs=(warm+duration)*1000;
   async function slot(){if(active>=cfg.maxInflight)await new Promise(r=>waiters.push(r));active++;}
   function free(){active--;const next=waiters.shift();if(next)next();}
   function observe(){samples.push({ms:elapsed(),active,pending,complete,dropped,failed});}
   const timer=setInterval(observe,500);observe();
   async function send(i,stage,data,row){
    const j=i%3,w=ctx.wallets[9+j],nonce=nonces[j]++,raw=await w.signTransaction({type:0,chainId:ctx.chainId,to:address,data,nonce,gasLimit:500000,gasPrice:1000000000n});
    const hash=L.ethers.keccak256(raw),tr={stage,hash,nonce,submittedMs:elapsed(),data};row.transactions.push(tr);
    assert.equal(await ctx.provider.send('eth_sendRawTransaction',[raw]),hash);
    const receipt=await ctx.provider.waitForTransaction(hash,1,45000);if(!receipt)throw Error('receipt timeout');
    Object.assign(tr,{status:receipt.status,gas:Number(receipt.gasUsed),block:receipt.blockNumber,receiptMs:elapsed()});
    if(receipt.status!==1)throw Error('mined revert at '+stage);
   }
   const tasks=[];
   for(let i=0;i<arrivals.length;i++){
    const event=arrivals[i];await sleep(Math.max(0,wall+event.plannedMs-performance.now()));
    const row={i,...event,admittedMs:elapsed(),measured:event.plannedMs>=warmMs,transactions:[]};rows.push(row);
    if(pending>=cfg.admissionBound){row.outcome='admission-drop';dropped++;continue;}
    pending++;const obj=pool[event.object],previous=obj.tail;
    const task=(async()=>{await previous;await slot();row.startedMs=elapsed();
     try{
      if(obj.poisoned)throw Error('uncertain prior object state');
      const target=obj.controller===1?2:1,a={b:obj.b,kind:0,target:ctx.wallets[target].address,recipient:L.A0,ref:L.Z,terms:L.Z,flags:0,version:obj.version,policy:1,deadline:clock+Math.floor(elapsed()/1000)+600};
      const sigs=await L.signatures(ctx,c,L.AT,a,[1,2]);
      if(mode==='reserved')await send(i,'reserve',c.interface.encodeFunctionData('reserve',[a,sigs,clock+Math.floor(elapsed()/1000)+25]),row);
      await send(i,'execute',c.interface.encodeFunctionData('execute',[a,sigs]),row);obj.version++;obj.controller=target;row.outcome='success';complete++;
     }catch(e){row.outcome='failure';row.error=e.shortMessage||e.message;obj.poisoned=true;failed++;}
     finally{row.finishedMs=elapsed();pending--;free();}
    })();obj.tail=task;tasks.push(task);
   }
   await sleep(Math.max(0,wall+endMs-performance.now()));const atEnd={ms:elapsed(),pending,active,complete,dropped,failed};
   let timeout;const drained=await Promise.race([Promise.all(tasks).then(()=>true),new Promise(r=>{timeout=setTimeout(()=>r(false),cfg.drainSeconds*1000);})]);clearTimeout(timeout);
   observe();clearInterval(timer);const measured=rows.filter(r=>r.measured),success=measured.filter(r=>r.outcome==='success'),latencies=success.map(r=>r.finishedMs-r.plannedMs).sort((a,b)=>a-b);
   const percentile=p=>latencies.length?latencies[Math.ceil(p*latencies.length)-1]:null;
   const cell={seed,rate,hotShare,hotCount,mode,utc:new Date().toISOString(),arrivalModel:'Poisson',warmMs,endMs,objects:n,delayMs:20,jitterMs:15,startHeight:height,endHeight:await ctx.provider.getBlockNumber(),drained,elapsedMs:elapsed(),atEnd,
    summary:{offered:measured.length,success:success.length,dropped:measured.filter(r=>r.outcome==='admission-drop').length,failed:measured.filter(r=>r.outcome==='failure').length,unfinished:measured.filter(r=>!r.outcome).length,p50Ms:percentile(.5),p95Ms:percentile(.95),windowThroughput:rows.filter(r=>r.outcome==='success'&&r.finishedMs>=warmMs&&r.finishedMs<endMs).length/duration},rows,samples};
   fs.appendFileSync(file,JSON.stringify(cell)+'\n');cells.push(cell);console.log(JSON.stringify({seed,rate,hotShare,mode,...cell.summary,drained}));
   if(!drained){
    // The serialized cell above remains frozen at the original observation cutoff.
    // Extra waiting is cleanup only and cannot improve any reported outcome.
    let cleanupTimer;const cleaned=await Promise.race([Promise.all(tasks).then(()=>true),new Promise(r=>{cleanupTimer=setTimeout(()=>r(false),120000);})]);clearTimeout(cleanupTimer);
    fs.appendFileSync(path.join(L.root,'results/randomized18',tag+'-cleanup.jsonl'),JSON.stringify({seed,rate,hotShare,mode,cleaned,elapsedMs:elapsed(),failed})+'\n');
    assert.ok(cleaned,'Cleanup exceeded; frozen raw outcomes retained');
   }
   assert.equal(failed,0,'Execution uncertainty; retain outcomes and stop');
  }
 }
 L.save('randomized18/'+tag+'-manifest.json',{complete:true,cells:cells.length,pilot,engine:await ctx.provider.send('web3_clientVersion',[]),hostScope:'Four JVM validators on one physical host',networkImpairment:'20 +/- 15 ms uniform delay per forwarded TCP chunk; independently seeded directional streams',cfg});
 ctx.provider.destroy();agent.destroy();
})().catch(e=>{console.error(e);process.exitCode=1;});
