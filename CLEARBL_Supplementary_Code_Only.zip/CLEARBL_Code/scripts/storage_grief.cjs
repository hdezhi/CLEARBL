const L=require('./lib.cjs'),assert=require('assert/strict');
(async()=>{
 const ctx=await L.environment(),f=await L.fixture(ctx),c=f.single,layout=L.artifact('ClearBL').storageLayout;
 const recordMap=layout.storage.find(x=>x.label==='records'),claimMap=layout.storage.find(x=>x.label==='claims');
 const recordType=layout.types[layout.types[recordMap.type].value];
 const recordSlots=Math.ceil(Number(recordType.numberOfBytes)/32);
 const claimArray=layout.types[layout.types[claimMap.type].value],claimSlots=Math.ceil(Number(layout.types[claimArray.base].numberOfBytes)/32);
 const abi=L.ethers.AbiCoder.defaultAbiCoder();
 async function occupancy(b){
  const rb=BigInt(L.ethers.keccak256(abi.encode(['bytes32','uint256'],[b,recordMap.slot]))),cb=BigInt(L.ethers.keccak256(abi.encode(['bytes32','uint256'],[b,claimMap.slot])));
  const start=BigInt(L.ethers.keccak256(L.ethers.toBeHex(cb,32))),slots=[];
  for(let i=0;i<recordSlots;i++)slots.push(rb+BigInt(i));slots.push(cb);
  for(let i=0;i<16*claimSlots;i++)slots.push(start+BigInt(i));
  let occupied=0;for(const s of slots){const value=await ctx.provider.getStorage(await c.getAddress(),s);if(value!=='0x'&&BigInt(value)!==0n)occupied++;}
  return {active:(await c.activeClaims(b)).length,recordSlots,claimSlots,inspectedSlots:slots.length,nonzeroSlots:occupied,nonzeroSlotBytes:occupied*32};
 }
 const b=await L.issue(ctx,c,'storage');const storage=[{stage:'issue',...await occupancy(b)}];
 for(let i=0;i<16;i++){await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[3].address,ref:L.ethers.toBeHex(i,32),terms:L.H('claim'+i),flags:3},[1,3]),'claim');if([1,4,8,16].includes(i+1))storage.push({stage:'create'+(i+1),...await occupancy(b)});}
 for(let i=0;i<16;i++)await L.execute(ctx,c,await L.signedAction(ctx,c,b,2,{ref:L.ethers.toBeHex(i,32)},[3]),'discharge');
 storage.push({stage:'all-discharged',...await occupancy(b)});
 await L.confirm(ctx,c,b,0);await L.confirm(ctx,c,b,1);const cap=await L.authorize(ctx,c,b);await(await c.connect(ctx.signers[8]).consume(b,cap)).wait();storage.push({stage:'consumed',...await occupancy(b)});
 const grief=[],r=f.reserved;
 for(const ttl of [2,10,30]){
  const b=await L.issue(ctx,r,'grief'+ttl);const x=await L.signedAction(ctx,r,b,0,{target:ctx.wallets[2].address},[1,2]);
  const rr=await(await r.reserve(x.a,x.sigs,await L.now(ctx)+ttl)).wait();
  await ctx.provider.send('evm_increaseTime',[ttl+1]);await ctx.provider.send('evm_mine',[]);
  const er=await(await r.connect(ctx.signers[12]).expire(b)).wait();let denied=0;
  for(let i=0;i<100;i++){try{await r.connect(ctx.signers[i%15]).reserve.staticCall(x.a,x.sigs,await L.now(ctx)+ttl)}catch(e){if(e.code==='CALL_EXCEPTION')denied++;else throw e;}}
  assert.equal(denied,100);
  const alt=await L.signedAction(ctx,r,b,0,{target:ctx.wallets[12].address},[1,12]);
  const ar=await(await r.connect(ctx.signers[12]).execute(alt.a,alt.sigs)).wait();
  grief.push({ttlSeconds:ttl,clock:'evm_increaseTime; simulated expiration, not wall-clock delay',repeatAttempts:100,denied,initialReservationGas:String(rr.gasUsed),cleanupGas:String(er.gasUsed),honestFallbackGas:String(ar.gasUsed),controller:await r.record(b).then(s=>s.controller)});
 }
 L.save('storage.json',storage);L.save('grief.json',grief);L.save('storage-receipts.json',ctx.rows);console.log(L.stringify({storage,grief}));await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
