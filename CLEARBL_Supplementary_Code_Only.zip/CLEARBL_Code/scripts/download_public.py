"""Download frozen public measurement data; no new active measurements are created."""
from pathlib import Path
import requests,json,hashlib,concurrent.futures,datetime
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'public-data';C=json.loads((P/'study-config.json').read_text());M=[]
def fetch(name,url):
 p=P/name
 if not p.exists():
  r=requests.get(url,timeout=(15,120));r.raise_for_status();p.write_bytes(r.content)
 data=p.read_bytes();j=json.loads(data) if name.endswith('.json') else None
 return {'file':name,'url':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'downloaded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},j
start=int(datetime.datetime.fromisoformat(C['window_start'].replace('Z','+00:00')).timestamp());stop=int(datetime.datetime.fromisoformat(C['window_stop'].replace('Z','+00:00')).timestamp());probes=','.join(str(x['probe']) for x in C['anchors'])
def target(a):
 mid=a['measurement']; out=[]
 for name,url in [(f'measurement-{mid}.json',f'https://atlas.ripe.net/api/v2/measurements/{mid}/'),(f'results-{mid}.json',f'https://atlas.ripe.net/api/v2/measurements/{mid}/results/?start={start}&stop={stop}&probe_ids={probes}')]:
  m,j=fetch(name,url);out.append(m)
  if name.startswith('results'):print(mid,'records',len(j),'probes',sorted({v['prb_id'] for v in j}),flush=True)
 return out
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  for result in ex.map(target,C['anchors']):M.extend(result)
 for name,url in [('ecb2024.html','https://www.ecb.europa.eu/press/targetservar/html/ecb.targetservar2024.en.html')]:
  m,j=fetch(name,url);M.append(m)
 (P/'download-manifest.json').write_text(json.dumps(M,indent=2),encoding='utf-8');print('Saved provenance for',len(M),'files')
