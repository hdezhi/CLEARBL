"""Loopback-only Besu IBFT harness. TCP-chunk delay/partition, not packet-level loss.
Runs until stop file appears; owns and terminates only processes it starts.
"""
import asyncio,json,pathlib,subprocess,sys,os,random,time
net=pathlib.Path(sys.argv[1]).resolve();runtime=pathlib.Path(sys.argv[2]).resolve()
nodes=json.loads((net/'network.json').read_text());processes=[];launch_args=[];launch_logs=[]
java=next(runtime.glob('jdk-*-jre/bin/java.exe'));jars=runtime/'besu-25.9.0/lib/*'
tmp=net/'tmp';tmp.mkdir(exist_ok=True)
def config():
    try:return json.loads((net/'impairment.json').read_text())
    except (OSError,ValueError):return {'delayMs':0,'jitterMs':0,'cut':[]}
async def proxy(reader,writer,index,origin):
    cfg=config()
    if index in cfg.get('cut',[]) or index in cfg.get('isolated',[]) or origin in cfg.get('isolated',[]):writer.close();return
    try:r,w=await asyncio.open_connection('127.0.0.1',nodes[index]['p2p'])
    except OSError:writer.close();return
    rng_forward=random.Random(260929+origin*100+index); rng_reverse=random.Random(260929+index*100+origin+10000)
    async def pump(src,dst,rng,direction):
        active_epoch=None
        try:
            while True:
                data=await src.read(65536)
                if not data:break
                cfg=config()
                epoch=cfg.get('runToken',str(cfg.get('seed',260929)))
                if epoch!=active_epoch:
                    rng.seed(cfg.get('seed',260929)+origin*1000+index*10+direction)
                    active_epoch=epoch
                if index in cfg.get('cut',[]) or index in cfg.get('isolated',[]) or origin in cfg.get('isolated',[]):break
                if rng.random()<cfg.get('resetProbability',0):break
                delay=max(0,cfg.get('delayMs',0)+rng.uniform(-cfg.get('jitterMs',0),cfg.get('jitterMs',0)))
                if delay:await asyncio.sleep(delay/1000)
                dst.write(data);await dst.drain()
        except (ConnectionError,OSError):pass
        finally:dst.close()
    await asyncio.gather(pump(reader,w,rng_forward,0),pump(r,writer,rng_reverse,1))
async def main():
    servers=[]
    for origin in range(len(nodes)):
        for dest,node in enumerate(nodes):
            if origin!=dest:
                servers.append(await asyncio.start_server(lambda r,w,j=dest,k=origin:proxy(r,w,j,k),'127.0.0.1',node['proxy']+origin*100))
    for i,node in enumerate(nodes):
        args=[str(java),'-Xms32m','-Xmx512m','-XX:MaxDirectMemorySize=128m','-XX:MaxMetaspaceSize=128m',f'-Djava.io.tmpdir={tmp}','-cp',str(jars),'org.hyperledger.besu.Besu',f'--data-path={net/('node'+str(i))}',f'--genesis-file={net/'genesis.json'}','--network-id=20260929','--p2p-interface=127.0.0.1','--p2p-host=127.0.0.1',f'--p2p-port={node['p2p']}','--discovery-enabled=false','--rpc-http-enabled','--rpc-http-host=127.0.0.1',f'--rpc-http-port={node['rpc']}','--rpc-http-api=ETH,NET,WEB3,IBFT,ADMIN,DEBUG','--host-allowlist=localhost,127.0.0.1','--min-gas-price=0','--data-storage-format=FOREST','--sync-mode=FULL',f'--max-peers={len(nodes)-1}','--logging=INFO']
        log=(net/f'node{i}.log').open('ab');env=os.environ.copy();env['TEMP']=str(tmp);env['TMP']=str(tmp)
        launch_args.append(args);launch_logs.append(log)
        p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),env=env);processes.append(p)
        print('Started',i,p.pid,flush=True)
        await asyncio.sleep(3)
    (net/'pids.json').write_text(json.dumps([p.pid for p in processes]))
    try:
        while not (net/'stop').exists():
            try:desired=json.loads((net/'fault-request.json').read_text()).get('stop',[])
            except (OSError,ValueError):desired=[]
            for i,p in enumerate(processes):
                if i in desired and p.poll() is None:
                    p.terminate();p.wait(timeout=15);print('Omission stop',i,flush=True)
                elif i not in desired and p.poll() is not None:
                    if p.returncode not in (0,1,143,-15):
                        print('Node exit/restart',i,p.returncode,flush=True)
                    processes[i]=subprocess.Popen(launch_args[i],stdout=launch_logs[i],stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),env=env)
                    print('Restarted',i,processes[i].pid,flush=True)
            await asyncio.sleep(1)
    finally:
        for s in servers:s.close()
        for p in processes:
            if p.poll() is None:p.terminate()
        for p in processes:
            try:p.wait(timeout=15)
            except subprocess.TimeoutExpired:p.kill()
asyncio.run(main())

