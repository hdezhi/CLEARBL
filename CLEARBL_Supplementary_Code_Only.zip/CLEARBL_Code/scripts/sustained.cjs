// Open-loop, duration-based transfers over a fixed rotating object pool.
// Admission and object queues are measured separately from receipt latency.
const L=require('./lib.cjs'),fs=require('fs'),path=require('path'),assert=require('assert/strict');
const agent=require('./network_transport.cjs');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const ctx=await L.environment(process.env.CLEARBL_RPC||'http://127.0.0.1:39400');ctx.provider.pollingInterval=200;
 const f=await L.fixture(ctx),tag='sustained',out=path.join(L.root,'results',tag);fs.mkdirSync(out,{recursive:true});
 const cfg={rates:[8,32],repeats:3,warmupSeconds:10,measureSeconds:60,drainSeconds:45,objects:128,maxInflight:96,receiptTimeoutMs:40000,validators:4,hostScope:'one physical host',delayProfile:'no injected delay'};
 if(process.env.CLEARBL_PILOT==='1')Object.assign(cfg,{rates:[8],repeats:1,warmupSeconds:2,measureSeconds:5,objects:32,maxInflight:24});
 const key=process.env.CLEARBL_PILOT==='1'?'pilot':'measurement';
 L.save(tag+'/'+key+'-config.json',{...cfg,utc:new Date().toISOString(),contractManifest:L.artifact('ClearBL').evm.deployedBytecode.object.length/2});
 const pools={};
 for(const mode of ['single','reserved']){
  pools[mode]=[];
  for(let i=0;i<cfg.objects;i+=16){const ids=await Promise.all(Array.from({length:Math.min(16,cfg.objects-i)},(_,j)=>L.issue(ctx,f[mode],`sustained-${key}-${mode}-${i+j}`)));pools[mode].push(...ids.map(b=>({b,version:0,controller:1,tail:Promise.resolve()})));}
 }
 const cells=[];
 for(let repeat=0;repeat<cfg.repeats;repeat++)for(const rate of (repeat%2?[32,8]:cfg.rates))for(const mode of (repeat%2?['reserved','single']:['single','reserved'])){
  if(!cfg.rates.includes(rate))continue;
  const c=f[mode],pool=pools[mode],address=await c.getAddress(),rows=[],samples=[];
  let inflight=0,pending=0,completed=0,failed=0,dropped=0;const waiters=[];
  const nonces=await Promise.all([9,10,11].map(i=>ctx.provider.getTransactionCount(ctx.wallets[i].address,'pending')));
  const clock=await L.now(ctx),wall=performance.now(),height=await ctx.provider.getBlockNumber();
  const elapsed=()=>performance.now()-wall;
  const warmMs=cfg.warmupSeconds*1000,endMs=warmMs+cfg.measureSeconds*1000,count=Math.round(rate*endMs/1000);
  async function slot(){if(inflight>=cfg.maxInflight)await new Promise(r=>waiters.push(r));inflight++;}
  function free(){inflight--;const r=waiters.shift();if(r)r();}
  const observe=()=>samples.push({tMs:elapsed(),pending,inflight,completed,failed,dropped});
  const timer=setInterval(observe,1000);observe();
  async function tx(i,stage,data,row){
   const j=i%3,w=ctx.wallets[9+j],nonce=nonces[j]++,begin=elapsed();
   const raw=await w.signTransaction({type:0,chainId:ctx.chainId,to:address,data,nonce,gasLimit:400000,gasPrice:1000000000n});
   const hash=L.ethers.keccak256(raw);
   const tr={stage,hash,nonce,submittedMs:begin};row.transactions.push(tr);
   const returned=await ctx.provider.send('eth_sendRawTransaction',[raw]);assert.equal(returned,hash);
   const receipt=await ctx.provider.waitForTransaction(hash,1,cfg.receiptTimeoutMs);
   if(!receipt)throw Error('receipt timeout');
   Object.assign(tr,{status:receipt.status,gas:receipt.gasUsed.toString(),block:receipt.blockNumber,receiptMs:elapsed()});
   if(receipt.status!==1)throw Error('mined revert at '+stage);
  }
  const tasks=[];
  for(let i=0;i<count;i++){
   const planned=i*1000/rate;await sleep(Math.max(0,wall+planned-performance.now()));
   const row={i,plannedMs:planned,admittedMs:elapsed(),measured:planned>=warmMs&&planned<endMs,transactions:[]};rows.push(row);
   // Bound admission, but retain each rejected offered request in denominators.
   if(pending>=cfg.objects*4){row.outcome='admission-drop';dropped++;continue;}
   pending++;const o=pool[i%pool.length],previous=o.tail;
   const job=(async()=>{
    await previous;await slot();row.startedMs=elapsed();
    try{
     if(o.poisoned)throw Error('object quarantined after uncertain outcome');
     const target=o.controller===1?2:1;
     const a={b:o.b,kind:0,target:ctx.wallets[target].address,recipient:L.A0,ref:L.Z,terms:L.Z,flags:0,version:o.version,policy:1,deadline:clock+Math.floor(elapsed()/1000)+600};
     const sigs=await L.signatures(ctx,c,L.AT,a,[1,2]);
     if(mode==='reserved')await tx(i,'reserve',c.interface.encodeFunctionData('reserve',[a,sigs,clock+Math.floor(elapsed()/1000)+25]),row);
     await tx(i,'execute',c.interface.encodeFunctionData('execute',[a,sigs]),row);
     o.version++;o.controller=target;row.outcome='success';completed++;
    }catch(e){row.outcome='failure';row.error=e.shortMessage||e.message;o.poisoned=true;failed++;}
    finally{row.finishedMs=elapsed();pending--;free();}
   })();o.tail=job;tasks.push(job);
  }
  // Stop arrival at the exact window end before observing the drain.
  await sleep(Math.max(0,wall+endMs-performance.now()));const atEnd={pending,inflight,completed,failed,dropped,tMs:elapsed()};
  const finished=await Promise.race([Promise.all(tasks).then(()=>true),sleep(cfg.drainSeconds*1000).then(()=>false)]);
  observe();clearInterval(timer);
  const cell={repeat,rate,mode,utc:new Date().toISOString(),startHeight:height,endHeight:await ctx.provider.getBlockNumber(),warmMs,endMs,atEnd,drained:finished,elapsedMs:elapsed(),rows,samples};
  cells.push(cell);L.save(tag+'/'+key+'.json',cells);console.log(JSON.stringify({repeat,rate,mode,offered:count,completed,failed,dropped,drained:finished,pendingAtEnd:atEnd.pending}));
  assert.ok(finished,'Drain deadline exceeded; preserve data and stop instead of overlapping runs');
  assert.equal(failed,0,'Protocol/client failures retained; stop before carrying uncertain object versions');
 }
 ctx.provider.destroy();agent.destroy();if(ctx.engine)await ctx.engine.disconnect();
})().catch(e=>{console.error(e);process.exitCode=1});
