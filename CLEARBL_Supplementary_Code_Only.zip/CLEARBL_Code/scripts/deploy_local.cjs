// Runnable local deployment of the measured admission + priority profile.
// Public test keys; loopback-only Ganache. This is deployment tooling, not a new benchmark.
const L = require('./lib.cjs');
const fs = require('fs'), path = require('path'), assert = require('assert/strict');
const ganache = require('ganache');
async function main() {
  const smoke = process.argv.includes('--smoke');
  const port = smoke ? 0 : Number(process.env.CLEARBL_LOCAL_PORT || 18545);
  const server = ganache.server({logging:{quiet:true},chain:{chainId:20260929,hardfork:'merge'},wallet:{accounts:L.keys.map(secretKey=>({secretKey,balance:'0x3635c9adc5dea00000'}))},miner:{blockGasLimit:30000000,instamine:'eager'}});
  await server.listen(port,'127.0.0.1');
  const endpoint = `http://127.0.0.1:${server.address().port}`;
  const ctx = await L.environment(endpoint);
  try {
    const directory = await L.deploy(ctx,'AdmittedIssuanceDirectory');
    const registry = await L.deploy(ctx,'ObligationAdmissionRegistry',[await directory.getAddress()]);
    await (await directory.bindRegistry(await registry.getAddress())).wait();
    const carrierNamespace=L.H('CLEARBL-local-demo-carrier');
    const adapter=await L.deploy(ctx,'AdmittedIssuer',[await registry.getAddress(),ctx.wallets[0].address,ctx.wallets[7].address,1,carrierNamespace]);
    const roles=[...L.roles];roles[0]=2;
    const addresses={directory:await directory.getAddress(),registry:await registry.getAddress(),adapter:await adapter.getAddress()};
    const domains={};
    for(const [name,reserved] of [['direct',false],['reserved',true],['destination',false]]) {
      const c=await L.deploy(ctx,'ClearBLPriority',[addresses.directory,reserved,[...ctx.wallets.slice(0,15).map(w=>w.address),addresses.adapter],[...L.institutions,1],[...roles,1]]);
      domains[name]=c;addresses[name]=await c.getAddress();
      await (await directory.enroll(addresses[name])).wait();
    }
    await (await registry.enroll(addresses.adapter,carrierNamespace)).wait();
    await (await registry.seal()).wait();await (await directory.seal()).wait();
    const a={target:addresses.direct,carrierReference:L.H('demo-001'),platformAlias:L.H('demo-alias'),controller:ctx.wallets[1].address,bank:ctx.wallets[5].address,document:L.H('demo-document'),paymentTerms:L.H('demo-terms'),deadline:await L.now(ctx)+600};
    const types={Admission:[['target','address'],['carrierReference','bytes32'],['platformAlias','bytes32'],['controller','address'],['bank','address'],['document','bytes32'],['paymentTerms','bytes32'],['deadline','uint256']].map(([name,type])=>({name,type}))};
    const domain={name:'CLEAR-BL-Admission',version:'1',chainId:ctx.chainId,verifyingContract:addresses.adapter};
    const sig=await Promise.all([0,7].map(i=>ctx.wallets[i].signTypedData(domain,types,a)));
    const tx=await adapter.issue(a,...sig);await tx.wait();
    const o=await adapter.obligation(a.carrierReference),b=await domains.direct.businessId(addresses.adapter,o);
    assert.equal(await registry.admittedBy(o),addresses.adapter);
    assert.equal(await directory.current(b),addresses.direct);
    assert.equal((await domains.direct.record(b)).phase,1n);
    const manifest={scope:'Local deployment smoke test; not a paper measurement',chainId:String(ctx.chainId),endpoint,addresses,sealed:{directory:await directory.isSealed(),registry:await registry.isSealed()},example:{obligation:o,record:b,transaction:tx.hash},testAccounts:ctx.wallets.slice(0,15).map((w,i)=>({address:w.address,institution:L.institutions[i],roles:roles[i]})),issuerAdapterRole:1,sourceBuild:JSON.parse(fs.readFileSync(path.join(L.root,'build/manifest.json')))};
    const out=path.join(L.root,'deployment');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'local-deployment.json'),JSON.stringify(manifest,null,2));
    console.log(JSON.stringify({endpoint,addresses,admittedRecord:b,smokePassed:true},null,2));
    if(!smoke) {console.log('Local chain is running; Ctrl+C stops this deployment. Test keys are defined in lib.cjs.');await new Promise(resolve=>{process.once('SIGINT',resolve);process.once('SIGTERM',resolve);});}
  } finally {ctx.provider.destroy();await server.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
