"""Public-trace-calibrated source/release simulation, NOT a WAN EVM benchmark.

Run after setup.py, download_public.py and network_bench.cjs:
    python scripts/public_simulation.py
Raw observations, modeled RPC/ledger composition, and assumed fault rates are
kept separate. No banking error rate is inferred from ICMP measurements.
"""
from pathlib import Path
import csv, hashlib, itertools, json, math
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'public-data'
OUT = ROOT / 'results/public-simulation'
OUT.mkdir(parents=True, exist_ok=True)
C = json.loads((DATA / 'study-config.json').read_text(encoding='utf-8'))
ANCHORS = C['anchors']
START, SLOTS, STEP = 1756684800, 2520, 240
POLICIES = ('bank_only', 'bank_and_one', 'all_three')

def save(name, rows):
    if not rows: return
    with (OUT / (name + '.csv')).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def policy_time(a, policy):
    if policy == 'bank_only': return a[..., 0]
    if policy == 'bank_and_one': return np.maximum(a[..., 0], np.minimum(a[..., 1], a[..., 2]))
    if policy == 'all_three': return np.max(a, axis=-1)
    raise ValueError(policy)

def policy_accept(bits, policy):
    return bool(bits[0] and (policy == 'bank_only' or
        (any(bits[1:]) if policy == 'bank_and_one' else all(bits[1:]))))

def common_error(p, c, policy):
    # Enumerate the eight independent-error coalitions, not a fitted distribution.
    independent = sum(p ** sum(b) * (1-p) ** (3-sum(b))
        for b in itertools.product((0, 1), repeat=3) if policy_accept(b, policy))
    return c + (1-c) * independent

def retry_delay(packets, scale=1., timeout=3.):
    # Missing report remains NaN. Recorded timeouts become an explicit proxy for
    # failed hypothetical attempts; three failed attempts give +inf, not zero.
    present = ~np.isnan(packets).all(axis=-1)
    result = np.full(packets.shape[:-1], np.inf)
    for k in range(2, -1, -1):
        good = np.isfinite(packets[..., k]) & (packets[..., k] * scale < timeout)
        result = np.where(good, k*timeout + packets[..., k]*scale, result)
    result = np.where(np.isinf(result) & np.isnan(packets).any(axis=-1), np.nan, result)
    return np.where(present, result, np.nan)

def load_traces():
    packets = np.full((SLOTS, 5, 5, 3), np.nan)
    timestamps = np.full((SLOTS, 5, 5), np.nan)
    rows, summary, duplicates = [], [], 0
    probes = {a['probe']: i for i, a in enumerate(ANCHORS)}
    for j, a in enumerate(ANCHORS):
        path = DATA / f'results-{a["measurement"]}.json'
        raw = json.loads(path.read_text())
        for r in sorted(raw, key=lambda r: r['timestamp']):
            i = probes[r['prb_id']]; slot = (r['timestamp'] - START)//STEP
            if not 0 <= slot < SLOTS: continue
            assert r['msm_id'] == a['measurement'] and r['af'] == 4
            sent_packets=[v for v in r['result'] if not v.get('dup')]
            assert r.get('step') == STEP and 1 <= len(sent_packets) <= 3
            if not np.isnan(timestamps[slot, i, j]): duplicates += 1; continue
            timestamps[slot, i, j] = r['timestamp']
            for k, v in enumerate(sent_packets):
                val = v.get('rtt'); packets[slot, i, j, k] = val/1000 if val is not None and val >= 0 else np.inf
            if i != j:
                for k, v in enumerate(packets[slot, i, j]):
                    if np.isnan(v): continue  # Unsent packets are not observed timeouts.
                    rows.append(dict(slot=int(slot), timestamp=r['timestamp'], client=ANCHORS[i]['city'],
                        source=a['city'], probe=r['prb_id'], measurement=a['measurement'],
                        destination_address=r.get('dst_addr',''), packet=k,
                        outcome='reply' if np.isfinite(v) else 'timeout_or_error', rtt_ms=v*1000 if np.isfinite(v) else ''))
        for i in range(5):
            if i == j: continue
            arr = packets[:,i,j,:]; present = ~np.isnan(arr).all(axis=1); good = arr[np.isfinite(arr)]
            summary.append(dict(client=ANCHORS[i]['city'], source=a['city'],
                expected_reports=SLOTS, observed_reports=int(present.sum()), missing_reports=int((~present).sum()),
                packets=int((~np.isnan(arr)).sum()), replies=int(len(good)),
                unsent_packets=int(present.sum()*3-(~np.isnan(arr)).sum()),
                timeouts=int(np.isinf(arr).sum()), all_timeout_reports=int(np.isinf(arr).all(axis=1).sum()),
                median_ms=float(np.median(good)*1000) if len(good) else '',
                p95_ms=float(np.quantile(good,.95)*1000) if len(good) else '',
                p99_ms=float(np.quantile(good,.99)*1000) if len(good) else ''))
    assert duplicates == 0, ('ambiguous bin alignment', duplicates)
    save('trace-packets', rows); save('trace-links', summary)
    # Self-pings are retained raw but excluded from network analysis.
    return packets, timestamps, summary

def placements(topology, base):
    idx = C['topologies'][topology]; arrays=[]; labels=[]
    for client in idx:
        sources = [s for s in idx if s != client]
        for bank in sources:
            vv = [s for s in sources if s != bank]
            arrays.append(base[:,client,[bank,*vv]])
            labels.append((client,bank,*vv))
    return np.stack(arrays, axis=1), labels  # time, placement, bank/V1/V2

def ledger_times():
    path=ROOT/'results/ibft4/receipts.json'; raw=json.loads(path.read_text())
    rows=[]; values={}
    for mode in ('single','reserved'):
        labels=['confirmPay','confirmDoc','authorize','consume']
        if mode=='reserved': labels.insert(2,'authorize.reserve')
        vv=[]
        for run in range(10):
            stages=[next(r for r in raw if r['mode']==mode and r['run']==run and r['label']==label) for label in labels]
            val=sum(r['ms'] for r in stages)/1000; vv.append(val)
            rows.append(dict(mode=mode,run=run,stages=';'.join(labels),seconds=val,receipt_hashes=';'.join(r['hash'] for r in stages)))
        values[mode]=np.array(vv)
    save('local-stage-calibration', rows)
    return values, np.array([r['ms']/1000 for r in raw if r['mode']=='single' and r['label']=='consume'])

def summarize_completion(t, budget):
    unknown=np.isnan(t); good=t<budget; known=~unknown
    finite=t[np.isfinite(t)]
    return dict(cases=int(t.size),completed=int(good.sum()),unknown=int(unknown.sum()),
        unreachable=int(np.isinf(t).sum()),late=int(((t>=budget)&np.isfinite(t)).sum()),
        coverage_lower=float(good.mean()),coverage_upper=float((good|unknown).mean()),
        p50_completed_path_s=float(np.median(finite)) if len(finite) else '',
        p95_completed_path_s=float(np.quantile(finite,.95)) if len(finite) else '')

def run_sources(packets, ledgers):
    rows=[]; daily=[]; snapshots=[]; composed=[]; model_cases=0
    for timeout in (1.,3.,5.):
        for scale in (.5,1.,2.,4.):
            base=retry_delay(packets,scale,timeout)
            for topology in C['topologies']:
                source,labels=placements(topology,base)
                # A missing report cannot be replaced by a successful assumed RPC.
                unknown=np.isnan(source).any(axis=-1)
                for processing in (0.,.1,1.,5.):
                    for policy in POLICIES:
                        t=policy_time(source+processing,policy); t=np.where(unknown,np.nan,t)
                        model_cases+=t.size
                        for budget in (1.,2.,5.,10.,20.,30.):
                            rows.append(dict(topology=topology,timeout=timeout,rtt_scale=scale,
                                processing_s=processing,policy=policy,budget_s=budget,**summarize_completion(t,budget)))
                        if timeout==3 and scale==1 and processing==.1:
                            for day in range(7):
                                for budget in (1.,2.,5.,10.,20.,30.):
                                    daily.append(dict(topology=topology,day=day+1,policy=policy,budget_s=budget,
                                        **summarize_completion(t[day*360:(day+1)*360],budget)))
                            for slot in range(SLOTS):
                                for pl,l in enumerate(labels):
                                    v=t[slot,pl]; snapshots.append(dict(topology=topology,slot=slot,day=slot//360+1,
                                        client=ANCHORS[l[0]]['city'],bank=ANCHORS[l[1]]['city'],policy=policy,
                                        outcome='unknown' if np.isnan(v) else ('unreachable_proxy' if np.isinf(v) else 'reply'),
                                        seconds=float(v) if np.isfinite(v) else ''))
                            if policy=='bank_and_one':
                                for mode,lt in ledgers.items():
                                    total=t[...,None]+lt[None,None,:]
                                    for split,sl in [('calibration',slice(0,1440)),('validation',slice(1440,None)),('all',slice(None))]:
                                        for budget in (2.,5.,10.,20.,30.):
                                            composed.append(dict(topology=topology,mode=mode,split=split,budget_s=budget,
                                                **summarize_completion(total[sl],budget)))
    save('source-sweep',rows);save('source-daily',daily);save('source-snapshots',snapshots);save('release-composition',composed)
    chosen=[]
    for topology,mode in itertools.product(C['topologies'],ledgers):
        cc=[r for r in composed if r['topology']==topology and r['mode']==mode and r['split']=='calibration' and r['coverage_lower']>=.99]
        if cc:
            budget=min(r['budget_s'] for r in cc)
            v=next(r for r in composed if r['topology']==topology and r['mode']==mode and r['split']=='validation' and r['budget_s']==budget)
            chosen.append(dict(topology=topology,mode=mode,chosen_budget_s=budget,target=.99,
                validation_lower=v['coverage_lower'],validation_upper=v['coverage_upper']))
        else:chosen.append(dict(topology=topology,mode=mode,chosen_budget_s='none',target=.99,validation_lower='',validation_upper=''))
    save('budget-validation',chosen)
    return rows,composed,model_cases

def run_errors():
    rows=[]
    for p,c,policy in itertools.product(C['scenarios']['independent_false_probability'],C['scenarios']['fault_common_probability'],POLICIES):
        prob=common_error(p,c,policy)
        rows.append(dict(independent_error=p,common_error=c,policy=policy,false_accept_probability=prob))
    save('correlated-error',rows)
    return rows

def exposure_fraction(delta, lifetime):
    x=np.minimum(delta/lifetime,1.)
    return x-x*x/2

def run_revocation(packets,local_consume):
    # One snapshot per placement, paired with each measured local consume run.
    src,_=placements('alternative_sg',retry_delay(packets))
    bank=src[:,:,0].ravel(); observed=bank[~np.isnan(bank)]
    # Deterministic midpoint quadrature for the residual polling delay.
    u=(np.arange(100)+.5)/100
    rows=[]
    for poll,L in itertools.product((0.,1.,5.,30.,60.),(2.,5.,10.,20.,30.,60.)):
        vals=[]
        for service in local_consume:
            # Failed network attempts: withdrawal unavailable for this snapshot;
            # do not infer recovery at a sub-240s resolution absent observations.
            d=observed[:,None]+service+u[None,:]*poll
            vals.append(float(exposure_fraction(d,L).mean()))
        rows.append(dict(poll_s=poll,lifetime_s=L,known_snapshots=len(observed),unknown_snapshots=int(np.isnan(bank).sum()),
            unsafe_uniform_attempt_fraction=float(np.mean(vals)),local_run_min=float(min(vals)),local_run_max=float(max(vals)),
            interpretation='conditional hypothetical reversal; not observed fraud or unconditional attack probability'))
    save('withdrawal-window',rows);return rows

def cdf_bounds(budget,profile):
    # Only published constraints; populations must never be pooled.
    x=np.asarray(budget)
    if profile=='T2_annual': knots=[(0.,0.),(120.,.9973),(300.,.999)]
    elif profile=='T2_peak_day': knots=[(0.,0.),(25.,.54),(38.,.92)]
    elif profile=='TIPS_annual': knots=[(0.,0.),(5.,.9999)]
    else: raise ValueError(profile)
    lo=np.zeros_like(x,dtype=float);hi=np.ones_like(x,dtype=float)
    for b,v in knots:
        lo=np.where(x>=b,np.maximum(lo,v),lo)
        hi=np.where(x<=b,np.minimum(hi,v),hi)
    lo=np.where(x<0,0.,lo);hi=np.where(x<=0,0.,hi)
    return lo,hi

def run_settlement(packets,ledgers):
    src,_=placements('alternative_sg',retry_delay(packets));t=policy_time(src+.1,'bank_and_one')
    t=np.where(np.isnan(src).any(axis=-1),np.nan,t)
    rows=[]
    for mode,service in ledgers.items():
        overhead=(t[...,None]+service).ravel();unknown=np.isnan(overhead);unreachable=np.isinf(overhead)
        for profile,B in itertools.product(('T2_annual','T2_peak_day','TIPS_annual'),(10.,30.,120.,300.)):
            lo,hi=cdf_bounds(B-overhead,profile)
            lo=np.where(unknown|unreachable,0.,lo);hi=np.where(unknown,1.,np.where(unreachable,0.,hi))
            rows.append(dict(mode=mode,profile=profile,business_budget_s=B,cases=len(overhead),
                lower=float(lo.mean()),upper=float(hi.mean()),
                assumptions='same settlement CDF in each network snapshot; document already ready; no ledger contention; no bank API time included'))
    save('settlement-bounds',rows);return rows

def queue_scenario(duration,arrival_rate,capacity,poll,horizon_after=3600):
    # Constant-rate synthetic arrivals including the blackout and recovery hour.
    # The poll grid begins at0; all observations are released only after restore.
    horizon=duration+horizon_after
    arrivals=np.arange(0.,horizon,1/arrival_rate)
    ready=np.ceil(np.maximum(arrivals,duration)/poll)*poll
    finish=np.empty(len(arrivals));last=0.
    for i,r in enumerate(ready):
        last=max(last,r)+1/capacity;finish[i]=last
    mask=finish<=horizon;delay=finish[mask]-arrivals[mask]
    return dict(arrivals=len(arrivals),finished=int(mask.sum()),pending=int((~mask).sum()),
        completion_fraction=float(mask.mean()),conditional_p95_wait_s=float(np.quantile(delay,.95)),
        longest_observed_wait_s=float(delay.max()),
        drain_lower_bound_s=float(max(0.,finish[-1]-horizon)))

def run_outages():
    rows=[]
    for duration,rate,capacity,poll in itertools.product((2760,3000,13200),(.1,1.,10.),(2.,8.,32.),(1.,5.,30.,60.)):
        rows.append(dict(outage_s=duration,arrival_rate=rate,capacity=capacity,poll_s=poll,
            **queue_scenario(duration,rate,capacity,poll)))
    save('outage-recovery',rows);return rows

def validate():
    checks=[]
    def check(name,condition):
        assert condition,name;checks.append(name)
    for policy in POLICIES:
        for b in itertools.product((False,True),repeat=3):
            t=np.where(b,1.,np.inf)
            check(f'access_{policy}_{b}',np.isfinite(policy_time(t,policy))==policy_accept(b,policy))
    check('retry_second_attempt',retry_delay(np.array([np.inf,.2,.3]))==3.2)
    check('missing_is_not_success',np.isnan(retry_delay(np.full(3,np.nan))))
    check('all_timeouts_not_missing',np.isinf(retry_delay(np.full(3,np.inf))))
    for policy in POLICIES:
        check('common_floor_'+policy,common_error(.01,.1,policy)>=.1)
        check('all_sound_'+policy,common_error(0.,0.,policy)==0)
        check('all_false_'+policy,common_error(1.,0.,policy)==1)
    rng=np.random.default_rng(20260930);n=200000;c=.01;p=.1
    common=rng.random(n)<c;bits=rng.random((n,3))<p
    for policy in POLICIES:
        sim=np.array([policy_accept(b,policy) for b in bits])|common;exact=common_error(p,c,policy)
        check('stochastic_vs_exact_'+policy,abs(sim.mean()-exact)<6*math.sqrt(exact*(1-exact)/n))
    L=10.;d=2.;r=rng.random(n)*L;t=rng.random(n)*L
    empirical=((r<=t)&(t<np.minimum(r+d,L))).mean()
    check('race_integral',abs(empirical-exposure_fraction(d,L))<.004)
    check('short_reports_with_success',retry_delay(np.array([.2,.3,np.nan]))==.2)
    check('unsent_is_not_observed_failure',np.isnan(retry_delay(np.array([np.inf,np.inf,np.nan]))))
    lo,hi=cdf_bounds(np.array([24.,25.,30.,38.]),'T2_peak_day')
    check('peak_population_bounds',np.allclose(lo,[0,.54,.54,.92]) and np.allclose(hi,[.54,.54,.92,.92]))
    q=queue_scenario(10.,1.,2.,1.,20)
    check('queue_conservation',q['arrivals']==q['finished']+q['pending'])
    check('underload_drains',q['pending']==0)
    q2=queue_scenario(10.,3.,1.,1.,20)
    check('overload_censored',q2['pending']>0)
    return checks

def main():
    tests=validate();packets,timestamps,links=load_traces();lt,consume=ledger_times()
    sweep,composition,cases=run_sources(packets,lt)
    errors=run_errors();race=run_revocation(packets,consume);settlement=run_settlement(packets,lt);outages=run_outages()
    sources={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in list(DATA.glob('results-*.json'))+[DATA/'study-config.json',DATA/'ecb-calibration.json',
            DATA/'ecb2024.html',DATA/'selected-anchors.json',DATA/'experiment-spec.md',
            ROOT/'results/ibft4/receipts.json',Path(__file__)]}
    report=dict(kind='simulation calibrated by public ICMP data and retained local receipts',seed=20260930,
        trace_reports=sum(r['observed_reports'] for r in links),trace_packets=sum(r['packets'] for r in links),
        trace_missing_reports=sum(r['missing_reports'] for r in links),trace_replies=sum(r['replies'] for r in links),
        trace_timeouts=sum(r['timeouts'] for r in links),source_unique_model_cases=cases,
        source_parameter_cells=len(sweep),composition_cells=len(composition),error_cells=len(errors),
        withdrawal_cells=len(race),settlement_bound_cells=len(settlement),outage_cells=len(outages),
        tests_passed=tests,source_hashes=sources,
        statistical_unit='day and aligned 240s snapshot; Cartesian combinations/local repeats are not independent public observations',
        caveats=['ICMP cannot establish TCP/application liveness or bank truth',
                 'local ledger kept local; no simulated Besu/WAN consensus or throughput claim',
                 'original Singapore endpoint all-timeout trace retained',
                 'source processing, retry timeout, attack rates, poll intervals, arrival rates and service capacities are assumptions',
                 'settlement CDF bounds are aggregate-calibrated and do not contain individual bank transactions'])
    (OUT/'summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('source_hashes','tests_passed')},indent=2))
    print('Validation checks:',len(tests))

if __name__=='__main__': main()
