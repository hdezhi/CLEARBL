const L=require('./lib.cjs');
(async()=>{
 const ctx=await L.environment();
 for(let i=0;i<16;i++)ctx.wallets.push(new L.ethers.Wallet(L.key(100+i),ctx.provider));
 const dir=await L.deploy(ctx,'IssuanceDirectory');
 const keys=[...ctx.wallets.slice(0,15),...ctx.wallets.slice(18)].map(w=>w.address);
 const ids=[...L.institutions,...Array.from({length:16},(_,i)=>100+i)],roles=[...L.roles,...Array(16).fill(4)];
 const c=await L.deploy(ctx,'ClearBL',[await dir.getAddress(),false,keys,ids,roles]);
 await(await dir.enroll(await c.getAddress())).wait();await(await dir.seal()).wait();const results=[];
 for(const n of [1,4,8,16]){
  const b=await L.issue(ctx,c,'distinct-financiers-'+n);let total=0;
  for(let i=0;i<n;i++){
   const r=await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[18+i].address,ref:L.ethers.toBeHex(i,32),terms:L.H('terms-'+i),flags:3},[1,18+i]),'create-distinct-claim');total+=Number(r.gas);
  }
  const transfer=await L.execute(ctx,c,await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2,...Array.from({length:n},(_,i)=>18+i)]),'transfer-distinct-financiers');
  const discharge=await L.execute(ctx,c,await L.signedAction(ctx,c,b,2,{ref:L.Z},[18]),'discharge-first-distinct');
  results.push({activeClaims:n,distinctFinanciers:n,transferSignatures:n+2,allCreateGas:total,transferGas:Number(transfer.gas),firstDischargeGas:Number(discharge.gas)});
 }
 L.save('distinct-financier-gas.json',results);L.save('distinct-financier-receipts.json',ctx.rows);console.log(L.stringify(results));await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
