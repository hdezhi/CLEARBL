const L=require('./lib.cjs'),assert=require('assert/strict');
(async()=>{
 const ctx=await L.environment(undefined,{miner:{timestampIncrement:0}}),f=await L.fixture(ctx),c=f.reserved,rows=[],summary=[];
 async function mine(label,promise,expected,meta){const t=await promise;let r;try{r=await t.wait()}catch(e){r=e.receipt;if(!r)throw e;}assert.equal(r.status,expected,label);const block=await ctx.provider.getBlock(r.blockNumber);const row={label,...meta,status:r.status,gas:String(r.gasUsed),hash:t.hash,data:t.data,block:r.blockNumber,blockHash:r.blockHash,ledgerTime:block.timestamp};rows.push(row);return row;}
 async function at(t){await ctx.provider.send('evm_setTime',[t*1000]);await ctx.provider.send('evm_mine',[]);assert.equal(await L.now(ctx),t)}
 for(const ttl of [2,5,10,20,30]){
  for(const offset of [-1,0,1]){
   const b=await L.issue(ctx,c,`window-${ttl}-${offset}`),x=await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]);
   const start=await L.now(ctx),until=start+ttl,meta={ttl,offset,b};
   const reserve=await mine('reserve',c.reserve(x.a,x.sigs,until),1,meta);await at(until+offset);
   const s0=await c.record(b),commit=await mine('commit',c.execute(x.a,x.sigs,{gasLimit:1000000}),offset<0?1:0,meta);
   let cleanup=null,fallback=null,rejected=0;
   if(offset>=0){
    assert.equal((await c.record(b)).version,s0.version);cleanup=await mine('cleanup',c.expire(b),1,meta);
    for(let j=0;j<10;j++){await mine('repeat-reservation',c.reserve(x.a,x.sigs,await L.now(ctx)+ttl,{gasLimit:1000000}),0,{...meta,j});rejected++;}
    const alt=await L.signedAction(ctx,c,b,0,{target:ctx.wallets[12].address},[1,12]);fallback=await mine('different-direct-fallback',c.execute(alt.a,alt.sigs),1,meta);
   }
   summary.push({ttl,offset,committed:commit.status,reserveGas:Number(reserve.gas),commitGas:Number(commit.gas),cleanupGas:cleanup?Number(cleanup.gas):null,fallbackGas:fallback?Number(fallback.gas):null,rejectedRepeats:rejected});
  }
 }
 // Exact one-reservation-per-version does not imply a bound across fresh versions.
 const b=await L.issue(ctx,c,'fresh-versions');let controller=1;const across=[];
 for(let round=0;round<6;round++){
  const target=controller===1?2:1,x=await L.signedAction(ctx,c,b,0,{target:ctx.wallets[target].address},[controller,target]);const start=await L.now(ctx),until=start+5;
  await mine('fresh-version-reserve',c.reserve(x.a,x.sigs,until),1,{round});await at(until);await mine('fresh-version-cleanup',c.expire(b),1,{round});await mine('fresh-version-authorized-transfer',c.execute(x.a,x.sigs),1,{round});
  across.push({round,versionBefore:String(x.a.version),versionAfter:String((await c.record(b)).version),excludedLedgerSeconds:5});controller=target;
 }
 L.save('revision8/reservation-windows.json',{clock:'Ganache timestampIncrement=0 with explicit evm_setTime/mine. Ledger-time guard experiment, not measured wall-clock latency.',summary,acrossFreshVersions:across,receipts:rows,setupReceipts:ctx.rows});console.log(L.stringify({cells:summary.length,minedRepeatRejections:summary.reduce((n,x)=>n+x.rejectedRepeats,0),freshVersionCycles:across.length,receipts:rows.length+ctx.rows.length}));await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
