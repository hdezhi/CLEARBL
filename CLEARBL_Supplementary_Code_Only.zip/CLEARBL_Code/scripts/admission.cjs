const L=require('./lib.cjs'),assert=require('assert/strict'),fs=require('fs'),path=require('path'),crypto=require('crypto');
(async()=>{
 const ctx=await L.environment(),d=await L.deploy(ctx,'AdmittedIssuanceDirectory');
 const registry=await L.deploy(ctx,'ObligationAdmissionRegistry',[await d.getAddress()]);
 await(await d.bindRegistry(await registry.getAddress())).wait();
 const issuer=await L.deploy(ctx,'AdmittedIssuer',[await registry.getAddress(),ctx.wallets[0].address,ctx.wallets[7].address,1,L.H('carrier-namespace')]);
 const otherIssuer=await L.deploy(ctx,'AdmittedIssuer',[await registry.getAddress(),ctx.wallets[3].address,ctx.wallets[7].address,4,L.H('carrier-namespace')]);
 for(const adapter of [issuer,otherIssuer])await(await registry.enroll(await adapter.getAddress(),L.H('carrier-namespace'))).wait();await(await registry.seal()).wait();
 const roles=[...L.roles];roles[0]=2;
 const keys=[...ctx.wallets.slice(0,15).map(x=>x.address),await issuer.getAddress(),await otherIssuer.getAddress()],ids=[...L.institutions,1,4],rs=[...roles,1,1];
 const domains=[];for(let i=0;i<2;i++)domains.push(await L.deploy(ctx,'ClearBLPriority',[await d.getAddress(),false,keys,ids,rs]));
 for(const c of domains)await(await d.enroll(await c.getAddress())).wait();await(await d.seal()).wait();
 const types={Admission:[['target','address'],['carrierReference','bytes32'],['platformAlias','bytes32'],['controller','address'],['bank','address'],['document','bytes32'],['paymentTerms','bytes32'],['deadline','uint256']].map(([name,type])=>({name,type}))};
 const domain={name:'CLEAR-BL-Admission',version:'1',chainId:ctx.chainId,verifyingContract:await issuer.getAddress()};
 const cases=[],receipts=[];
 async function input(n,overrides={}){return {target:await domains[0].getAddress(),carrierReference:L.H('transport-'+n),platformAlias:L.H('platform-'+n),controller:ctx.wallets[1].address,bank:ctx.wallets[5].address,document:L.H('document-'+n),paymentTerms:L.H('terms-'+n),deadline:await L.now(ctx)+600,...overrides}}
 async function signs(a){return Promise.all([0,7].map(i=>ctx.wallets[i].signTypedData(domain,types,a)))}
 async function attempt(label,a,sigs,expected,adapter=issuer){
  const o=await adapter.obligation(a.carrierReference),before=await adapter.admitted(o),globalBefore=await registry.admittedBy(o);
  const bid=L.ethers.keccak256(L.ethers.AbiCoder.defaultAbiCoder().encode(['uint256','bytes32'],[await adapter.issuerInstitution(),o])),stagedBefore=await d.stagedDomain(bid);
  const t=await adapter.connect(ctx.signers[12]).issue(a,...sigs,{gasLimit:2000000});let r;try{r=await t.wait()}catch(e){r=e.receipt;if(!r)throw e;}
  assert.equal(r.status,expected?1:0,label);if(!expected){assert.equal(await adapter.admitted(o),before,label+' rollback');assert.equal(await registry.admittedBy(o),globalBefore,label+' global rollback');assert.equal(await d.stagedDomain(bid),stagedBefore,label+' staged-domain rollback');}
  cases.push({label,status:r.status});receipts.push({label,hash:t.hash,data:t.data,block:r.blockNumber,blockHash:r.blockHash,status:r.status,gas:String(r.gasUsed),logs:r.logs.map(x=>({address:x.address,topics:x.topics,data:x.data}))});return o;
 }
 const a=await input('one');const sigs=await signs(a);const o=await attempt('joint-admission',a,sigs,true);
 const otherDomain={...domain,verifyingContract:await otherIssuer.getAddress()};
 const otherSigns=a=>Promise.all([3,7].map(i=>ctx.wallets[i].signTypedData(otherDomain,types,a)));
 const duplicate={...a,target:await domains[1].getAddress(),platformAlias:L.H('other-issuer-alias')};
 await attempt('different-issuer-same-obligation',duplicate,await otherSigns(duplicate),false,otherIssuer);
 const independent=await input('other-issuer-independent');await attempt('other-issuer-fresh-obligation',independent,await otherSigns(independent),true,otherIssuer);
 for(const [label,call] of [['unregistered-claim-static',()=>registry.claim.staticCall(L.H('unregistered'))],['sealed-enrollment-static',()=>registry.enroll.staticCall(otherIssuer.target,L.H('new-namespace'))]]){
  let failed=false;try{await call()}catch(e){if(e.code==='CALL_EXCEPTION')failed=true;else throw e;}assert(failed,label);cases.push({label,status:0});
 }
 for(const [name,change] of [['changed-alias',{platformAlias:L.H('another-local-id')}],['changed-domain',{target:await domains[1].getAddress()}],['same-reference-new-document',{document:L.H('different-bytes')}],['same-reference-new-controller',{controller:ctx.wallets[2].address}]] ){
  const b={...a,...change};await attempt(name,b,await signs(b),false);
 }
 for(const field of ['document','paymentTerms','platformAlias','carrierReference']){const b=await input('tamper-'+field),ss=await signs(b);b[field]=L.H('tampered');await attempt('signed-field-'+field,b,ss,false)}
 const b=await input('missing-carrier');let ss=await signs(b);ss[1]=await ctx.wallets[6].signTypedData(domain,types,b);await attempt('wrong-carrier',b,ss,false);
 const expired=await input('expired',{deadline:await L.now(ctx)-1});await attempt('expired',expired,await signs(expired),false);
 const bad=await input('bad-domain',{target:ctx.wallets[13].address});await attempt('not-enrolled',bad,await signs(bad),false);
 const rollback=await input('rollback',{bank:L.A0});await attempt('inner-issue-reverts',rollback,await signs(rollback),false);rollback.bank=ctx.wallets[5].address;await attempt('retry-after-rollback',rollback,await signs(rollback),true);
 const id=await domains[0].businessId(await issuer.getAddress(),o);
 // The enrolled EOA can sign documentary evidence but cannot bypass admission.
 let rejected=false;try{await domains[0].issue.staticCall(L.H('bypass'),ctx.wallets[1].address,ctx.wallets[5].address,L.H('doc'),L.H('pay'))}catch(e){if(e.code==='CALL_EXCEPTION')rejected=true;else throw e;}assert(rejected);cases.push({label:'direct-issuer-bypass-static',status:0});
 await L.confirm(ctx,domains[0],id,0);await L.confirm(ctx,domains[0],id,1);const cap=await L.authorize(ctx,domains[0],id);await L.receipt(ctx,'consume-admitted',domains[0].connect(ctx.signers[8]).consume(id,cap));
 await attempt('reissue-after-consumption',{...a,platformAlias:L.H('after-consume')},await signs({...a,platformAlias:L.H('after-consume')}),false);
 // Deliberate residual-risk control: two authorities endorsing a false fresh
 // carrier reference can admit the same supplied document bytes twice.
 const falseRef=await input('joint-false-reference',{document:a.document});await attempt('jointly-false-reference-control',falseRef,await signs(falseRef),true);
 // Institution identity is stable under core key rotation; old credentials fail.
 const rot={oldKey:ctx.wallets[0].address,newKey:ctx.wallets[15].address,policy:await domains[0].policyEpoch(),deadline:await L.now(ctx)+600};
 await L.receipt(ctx,'rotate-admission-issuer',domains[0].rotateKey(rot.oldKey,rot.newKey,rot.deadline,await L.signatures(ctx,domains[0],L.RT,rot,[0,9,10])));
 const renewed=await input('after-rotation');await attempt('revoked-issuer-admission',renewed,await signs(renewed),false);
 const renewedSigs=await signs(renewed);renewedSigs[0]=await ctx.wallets[15].signTypedData(domain,types,renewed);const renewedObligation=await attempt('rotated-issuer-admission',renewed,renewedSigs,true);
 const renewedId=await domains[0].businessId(await issuer.getAddress(),renewedObligation);
 await L.confirm(ctx,domains[0],renewedId,0);await L.confirm(ctx,domains[0],renewedId,1,[15,7]);
 const state=await domains[0].record(renewedId),wt={WithdrawDocument:[['target','address'],['b','bytes32'],['version','uint256'],['policy','uint256'],['deadline','uint256']].map(([name,type])=>({name,type}))};
 const withdrawal={target:await domains[0].getAddress(),b:renewedId,version:state.version,policy:await domains[0].policyEpoch(),deadline:await L.now(ctx)+600};
 const ws=await ctx.wallets[15].signTypedData(domain,wt,withdrawal);
 await L.receipt(ctx,'withdraw-admitted-document',issuer.withdrawDocument(withdrawal.target,renewedId,withdrawal.deadline,ws));
 assert.equal((await domains[0].record(renewedId)).doc.digest,L.Z);assert.equal((await domains[0].record(renewedId)).version,state.version+1n);cases.push({label:'adapter-withdrawal-invalidates',status:1});
 let replayRejected=false;try{await issuer.withdrawDocument.staticCall(withdrawal.target,renewedId,withdrawal.deadline,ws)}catch(e){if(e.code==='CALL_EXCEPTION')replayRejected=true;else throw e;}assert(replayRejected);cases.push({label:'withdrawal-replay-static',status:0});
 for(const [label,call] of [['unauthorized-directory-stage-static',()=>d.stage.staticCall(o,domains[0].target)],['sealed-directory-rebind-static',()=>d.bindRegistry.staticCall(registry.target)]]){
  let failed=false;try{await call()}catch(e){if(e.code==='CALL_EXCEPTION')failed=true;else throw e;}assert(failed,label);cases.push({label,status:0});
 }
 // A valid governance rotation can grant a raw EOA the wrapper's ISSUER role.
 // Directory-level admission must still reject its unadmitted issuance.
 const adapterRotation={oldKey:await issuer.getAddress(),newKey:ctx.wallets[16].address,policy:await domains[0].policyEpoch(),deadline:await L.now(ctx)+600};
 await L.receipt(ctx,'rotate-wrapper-issuer-role',domains[0].rotateKey(adapterRotation.oldKey,adapterRotation.newKey,adapterRotation.deadline,await L.signatures(ctx,domains[0],L.RT,adapterRotation,[15,9,10])));
 assert.equal((await domains[0].identities(ctx.wallets[16].address)).roles & 1n,1n);
 const rawRef=L.H('rotated-raw-issuer-bypass'),rawId=L.ethers.keccak256(L.ethers.AbiCoder.defaultAbiCoder().encode(['uint256','bytes32'],[1,rawRef]));
 const rawTx=await domains[0].connect(ctx.signers[16]).issue(rawRef,ctx.wallets[1].address,ctx.wallets[5].address,L.H('raw-doc'),L.H('raw-pay'),{gasLimit:2000000});let rawReceipt;try{rawReceipt=await rawTx.wait()}catch(e){rawReceipt=e.receipt;if(!rawReceipt)throw e;}
 assert.equal(rawReceipt.status,0);assert.equal(await d.current(rawId),L.A0);assert.equal((await domains[0].record(rawId)).phase,0n);
 let admissionGateRejected=false;try{await domains[0].connect(ctx.signers[16]).issue.staticCall(rawRef,ctx.wallets[1].address,ctx.wallets[5].address,L.H('raw-doc'),L.H('raw-pay'))}catch(e){assert.equal(e.reason,'unadmitted-issue');admissionGateRejected=true;}assert(admissionGateRejected);
 cases.push({label:'rotated-raw-issuer-bypass',status:0});receipts.push({label:'rotated-raw-issuer-bypass',hash:rawTx.hash,data:rawTx.data,block:rawReceipt.blockNumber,blockHash:rawReceipt.blockHash,status:0,gas:String(rawReceipt.gasUsed),logs:[]});
 L.save('revision8/admission.json',{sourceSHA256:crypto.createHash('sha256').update(fs.readFileSync(path.join(L.root,'contracts/AdmittedIssuer.sol'))).digest('hex'),cases,receipts,businessReceipts:ctx.rows,limitations:'Single-ledger admission; carrier reference truth and unique document reconciliation are institutional premises. The positive false-reference control is intentional.'});
 console.log(L.stringify({cases:cases.length,receipts:receipts.length+ctx.rows.length,accepted:cases.filter(x=>x.status===1).length}));await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
