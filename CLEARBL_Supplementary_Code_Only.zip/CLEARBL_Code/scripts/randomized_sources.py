"""Moving-block bootstrap of observed RIPE Atlas packets, not new bank measurements.

Entire time blocks are shared by all routes and policies. Missing observations
and timeouts remain explicit. All placements in both existing topologies retained.
"""
from pathlib import Path
import csv,json,hashlib,importlib.util
import numpy as np
R=Path(__file__).resolve().parents[1];O=R/'results/randomized18';O.mkdir(parents=True,exist_ok=True)
cfg={'seeds':list(range(18401,18441)),'blockSlots':30,'slotsPerSample':2520,'secondsPerSlot':240,'budgets':[.2,.35,.5,.75,1,2,4,8],'retryTimeout':3.,'processingSeconds':.1,'policies':['S','S_AND_V1','S_AND_ANY_V','S_AND_ALL_V'],'outageFraction':[0,.1,.2,.3,.4,.5],
     'scope':'Bootstrap sensitivity conditional on the retained public ICMP observations and stated ICMP-to-RPC proxy; not a bank or WAN blockchain experiment.',
     'outageModel':'Additional hypothetical V1 outage in a randomly located contiguous fraction of each bootstrap time sequence; all three-route time dependence retained.'}
specFile=R/'source-experiment-spec18.json';specFile.write_text(json.dumps(cfg,indent=2))
sp=importlib.util.spec_from_file_location('prior',R/'scripts/public_simulation.py');prior=importlib.util.module_from_spec(sp);sp.loader.exec_module(prior)
prior.OUT=O/'source-calibration';prior.OUT.mkdir(exist_ok=True)
packets,_,_=prior.load_traces();base=prior.retry_delay(packets,timeout=cfg['retryTimeout'])+cfg['processingSeconds']
def policy(a,p):
 if p=='S':return a[...,0]
 if p=='S_AND_V1':return np.maximum(a[...,0],a[...,1])
 if p=='S_AND_ANY_V':return np.maximum(a[...,0],np.minimum(a[...,1],a[...,2]))
 if p=='S_AND_ALL_V':return np.max(a,axis=-1)
 raise ValueError(p)
def record(seed,topology,family,parameter,p,t,budget):
 good=t<budget;unknown=np.isnan(t)
 return dict(seed=seed,topology=topology,family=family,parameter=parameter,policy=p,budget=budget,n=t.size,completed=int(good.sum()),unknown=int(unknown.sum()),timeout=int(np.isinf(t).sum()),coverageLower=float(good.mean()),coverageUpper=float((good|unknown).mean()))
rows=[];indices={}
for seed in cfg['seeds']:
 rand=np.random.default_rng(seed);starts=rand.integers(0,2520-cfg['blockSlots']+1,size=84)
 idx=np.concatenate([np.arange(s,s+cfg['blockSlots']) for s in starts]);indices[str(seed)]=starts.tolist()
 for topology in prior.C['topologies']:
  source,_=prior.placements(topology,base);a=source[idx]
  for p in cfg['policies']:
   t=policy(a,p)
   for budget in cfg['budgets']:rows.append(record(seed,topology,'deadline',budget,p,t,budget))
  offset=int(rand.integers(0,2520));order=(np.arange(2520)+offset)%2520
  for fraction in cfg['outageFraction']:
   b=a.copy();b[order[:int(2520*fraction)],:,1]=np.inf
   for p in cfg['policies']:rows.append(record(seed,topology,'verifier-outage',fraction,p,policy(b,p),4.))
with (O/'source-bootstrap.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(O/'source-bootstrap-blocks.json').write_text(json.dumps(indices))
manifest={'complete':True,'seedCount':40,'rows':len(rows),'config':cfg,'sources':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'public-data').glob('results-*.json')}}
(O/'source-bootstrap-manifest.json').write_text(json.dumps(manifest,indent=2))
assert all(0<=r['coverageLower']<=r['coverageUpper']<=1 for r in rows)
print(json.dumps({'bootstrapRows':len(rows),'seeds':40,'allPlacementsAndMissingDataRetained':True}))
