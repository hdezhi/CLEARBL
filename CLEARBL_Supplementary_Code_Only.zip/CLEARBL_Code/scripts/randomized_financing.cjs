// Random financing structure: restriction bits, institution order, signature order.
const L=require('./lib.cjs'),fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto');
const spec=JSON.parse(fs.readFileSync(path.join(L.root,'experiment-spec18.json'))),pilot=process.argv.includes('--pilot'),tag=pilot?'finance-pilot':'financing',out=path.join(L.root,'results/randomized18');
function rng(seed){let s=seed>>>0;return()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};}
function shuffle(a,r){a=a.slice();for(let i=a.length-1;i>0;i--){let j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
(async()=>{
 const ctx=await L.environment();for(let i=0;i<16;i++)ctx.wallets.push(new L.ethers.Wallet(L.key(100+i),ctx.provider));
 const d=await L.deploy(ctx,'IssuanceDirectory'),contracts={};
 for(const mode of ['direct','reserved']){
  contracts[mode]=await L.deploy(ctx,'ClearBL',[await d.getAddress(),mode==='reserved',[...ctx.wallets.slice(0,15),...ctx.wallets.slice(18)].map(w=>w.address),[...L.institutions,...Array.from({length:16},(_,i)=>100+i)],[...L.roles,...Array(16).fill(4)]]);
  await(await d.enroll(await contracts[mode].getAddress())).wait();
 }await(await d.seal()).wait();
 const rows=[],receiptFile=path.join(out,tag+'-receipts.jsonl');fs.writeFileSync(receiptFile,'');let saved=0;
 function flush(){for(const row of ctx.rows.slice(saved))fs.appendFileSync(receiptFile,JSON.stringify(row)+'\n');saved=ctx.rows.length;}
 const cfg=spec.financingCampaign;
 for(const seed of (pilot?[18100]:cfg.seeds))for(const n of (pilot?[0,4]:cfg.claims))for(const probability of (pilot?[0,1]:cfg.blockingProbabilities)){
  const rand=rng(seed+n*100),order=shuffle(Array.from({length:n},(_,i)=>18+i),rand),flags=order.map(()=>Number(rand()<probability));
  const signatureOrder=shuffle([1,2,...order.filter((_,i)=>flags[i])],rand);
  for(const mode of (seed%2?['direct','reserved']:['reserved','direct'])){
   const c=contracts[mode],meta={seed,n,probability,mode},first=ctx.rows.length,b=await L.issue(ctx,c,`${tag}-${seed}-${n}-${probability}-${mode}`,1,meta);
   for(let i=0;i<n;i++)await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[order[i]].address,ref:L.ethers.toBeHex(i,32),terms:L.H('terms:'+seed+':'+i),flags:flags[i]},[1,order[i]]),'claim',mode==='reserved',meta);
   const before=L.stringify(await c.activeClaims(b)),start=ctx.rows.length;
   await L.execute(ctx,c,await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},signatureOrder),'transfer',mode==='reserved',meta);
   assert.equal(L.stringify(await c.activeClaims(b)),before);
   const transfers=ctx.rows.slice(start),all=ctx.rows.slice(first);
   rows.push({...meta,registrationOrder:order,flags,signatureOrder,signatures:signatureOrder.length,transferGas:transfers.reduce((a,r)=>a+Number(r.gas),0),inputBytes:transfers.reduce((a,r)=>a+r.inputBytes,0),cumulativeIssueClaimTransferGas:all.reduce((a,r)=>a+Number(r.gas),0),claimsPreserved:true});
   flush();L.save('randomized18/'+tag+'-trials.json',rows);
  }
  console.log(tag,seed,n,probability,'cells',rows.length);
 }
 L.save('randomized18/'+tag+'-manifest.json',{completed:new Date().toISOString(),cells:rows.length,pilot,engine:await ctx.provider.send('web3_clientVersion',[]),sourceSHA256:crypto.createHash('sha256').update(fs.readFileSync(path.join(L.root,'contracts/ClearBL.sol'))).digest('hex')});
 await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1;});
