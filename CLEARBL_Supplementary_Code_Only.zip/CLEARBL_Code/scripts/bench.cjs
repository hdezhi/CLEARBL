const L=require('./lib.cjs'),assert=require('assert/strict'),fs=require('fs'),os=require('os');
(async()=>{
 const url=process.env.CLEARBL_RPC,tag=process.env.CLEARBL_TAG||'local',repeats=Number(process.env.CLEARBL_REPEATS||20);
 const compiler=JSON.parse(fs.readFileSync(L.root+'/build/manifest.json'));
 const ctx=await L.environment(url),f=await L.fixture(ctx),runs=[],baseline=[];
 const ttFactory=await L.deploy(ctx,'TitleEscrowFactory');
 const tt=await L.deploy(ctx,'TradeTrustToken',['eBL baseline','EBL',await ttFactory.getAddress()]);
 for(let i=0;i<repeats;i++){
  // Alternate order to reduce systematic drift, preserving all measured runs.
  for(const mode of (i%2?['reserved','single']:['single','reserved'])){
   const r=await L.lifecycle(ctx,f[mode],`${tag}-${mode}-${i}`,mode==='reserved',{mode,run:i});runs.push({mode,run:i,...r});
   console.log(tag,mode,i,r.gas,r.ms.toFixed(1));
  }
  await L.receipt(ctx,'erc721.issue',f.nft.issue(ctx.wallets[1].address,i+1),{mode:'erc721',run:i});
  baseline.push(await L.receipt(ctx,'erc721.transfer',f.nft.connect(ctx.signers[1]).transferFrom(ctx.wallets[1].address,ctx.wallets[2].address,i+1),{mode:'erc721',run:i}));
  await L.receipt(ctx,'tradetrust.issue',tt.mint(ctx.wallets[1].address,ctx.wallets[1].address,i+1,'0x'),{mode:'tradetrust',run:i});
  const address=await ttFactory.getEscrowAddress(await tt.getAddress(),i+1);
  const escrow=new L.ethers.Contract(address,L.artifact('TitleEscrow').abi,ctx.signers[1]);
  baseline.push(await L.receipt(ctx,'tradetrust.transferOwners',escrow.transferOwners(ctx.wallets[2].address,ctx.wallets[2].address,'0x'),{mode:'tradetrust',run:i}));
  assert.equal(await escrow.beneficiary(),ctx.wallets[2].address);assert.equal(await escrow.holder(),ctx.wallets[2].address);
  let rejected=false;try{await escrow.transferOwners.staticCall(ctx.wallets[12].address,ctx.wallets[12].address,'0x')}catch(e){if(e.code==='CALL_EXCEPTION')rejected=true;else throw e;}assert.ok(rejected,'TradeTrust stale actor rejected');
 }
 L.save(`${tag}/lifecycle.json`,runs);L.save(`${tag}/receipts.json`,ctx.rows);L.save(`${tag}/baselines.json`,baseline);
 L.save(`${tag}/environment.json`,{node:process.version,platform:process.platform,cpu:os.cpus()[0].model,logicalCPUs:os.cpus().length,ram:os.totalmem(),freeRam:os.freemem(),chainId:ctx.chainId,rpc:!!url,client:await ctx.provider.send('web3_clientVersion',[]),repeats,compiler,contracts:await Promise.all(Object.entries(f).map(async([k,c])=>[k,await c.getAddress()]))});
 if(ctx.engine)await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
