// Mechanism ablations, NOT published competitors. Every final outcome is mined.
const L=require('./lib.cjs'),fs=require('fs'),path=require('path'),solc=require('solc'),crypto=require('crypto'),assert=require('assert/strict');
const src=fs.readFileSync(path.join(L.root,'contracts/ClearBL.sol'),'utf8');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
function replaceOnce(s,a,b){assert.equal(s.split(a).length,2,'exact mutation anchor');return s.replace(a,b);}
const mutations={
 business:s=>replaceOnce(replaceOnce(s,'delete s.pay; delete s.doc; ',''),' && c.version == v',''),
 policy:s=>replaceOnce(replaceOnce(s,' && c.policy == policyEpoch',''),' && s.capabilityPolicy == policyEpoch',''),
 useTime:s=>replaceOnce(s,'require(s.capabilityUntil > block.timestamp && s.capabilityPolicy == policyEpoch && ready(b), "release-not-ready");','// Ablation: authorization-time validation only.')
};
function compile(name){
 const content=mutations[name](src);const input={language:'Solidity',sources:{'ClearBL.sol':{content}},settings:{optimizer:{enabled:true,runs:200},viaIR:true,evmVersion:'paris',outputSelection:{'*':{'*':['abi','evm.bytecode.object']}}}};
 const output=JSON.parse(solc.compile(JSON.stringify(input),{import:p=>({contents:fs.readFileSync(path.join(L.root,'node_modules',p),'utf8')})}));
 if((output.errors||[]).some(e=>e.severity==='error'))throw Error(JSON.stringify(output.errors));
 return {sourceSHA256:hash(content),content,compiled:output.contracts['ClearBL.sol'].ClearBL};
}
(async()=>{
 const mutants=Object.fromEntries(Object.keys(mutations).map(k=>[k,compile(k)])),ctx=await L.environment(),rows=[];
 const dir=path.join(L.root,'results/composition');fs.mkdirSync(dir,{recursive:true});
 for(const [k,v] of Object.entries(mutants))fs.writeFileSync(path.join(dir,k+'.mutant.sol.txt'),v.content);
 async function deploy(mode,mutation){
  const d=await L.deploy(ctx,'IssuanceDirectory'),a=mutation?mutants[mutation].compiled:L.artifact('ClearBL');
  const c=await new L.ethers.ContractFactory(a.abi,a.evm.bytecode.object,ctx.signers[0]).deploy(await d.getAddress(),mode==='reserved',ctx.wallets.slice(0,15).map(w=>w.address),L.institutions,L.roles);
  await c.waitForDeployment();await(await d.enroll(await c.getAddress())).wait();await(await d.seal()).wait();return c;
 }
 for(const scenario of Object.keys(mutations))for(const mode of ['single','reserved'])for(const variant of ['full','ablated']){
  const c=await deploy(mode,variant==='ablated'?scenario:null),start=ctx.rows.length,b=await L.issue(ctx,c,`${scenario}-${mode}-${variant}`);
  await L.confirm(ctx,c,b,0);await L.confirm(ctx,c,b,1);let cap,finish;
  if(scenario==='business'){
   await L.execute(ctx,c,await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]),'transfer',mode==='reserved');
   const x=await L.signedAction(ctx,c,b,4,{target:ctx.wallets[8].address,recipient:ctx.wallets[2].address,ref:L.H('job'),terms:L.H('location')},[0,2,8]);
   // A direct attempt is available in both configurations. A reservation cannot
   // repair a missing business-evidence relation: it checks the same predicates.
   finish=()=>c.connect(ctx.signers[12]).execute(x.a,x.sigs,{gasLimit:1000000});
  }else{
   cap=await L.authorize(ctx,c,b,1,mode==='reserved');
   if(scenario==='policy'){
    const v={oldKey:ctx.wallets[5].address,newKey:ctx.wallets[15].address,policy:await c.policyEpoch(),deadline:await L.now(ctx)+600};
    const sigs=await L.signatures(ctx,c,L.RT,v,[9,10,5]);
    await L.receipt(ctx,'rotate',c.rotateKey(v.oldKey,v.newKey,v.deadline,sigs));
   }else{await ctx.provider.send('evm_increaseTime',[601]);await ctx.provider.send('evm_mine',[]);}
   finish=()=>c.connect(ctx.signers[8]).consume(b,cap,{gasLimit:1000000});
  }
  const before=await c.record(b),tx=await finish();let receipt;
  try{receipt=await tx.wait()}catch(e){if(e.code!=='CALL_EXCEPTION')throw e;receipt=e.receipt;}
  const after=await c.record(b),expected=variant==='full'?0:1;assert.equal(receipt.status,expected);
  if(variant==='full')assert.equal(L.stringify(after),L.stringify(before),'revert changes record');
  rows.push({scenario,mode,variant,status:receipt.status,hash:tx.hash,gas:receipt.gasUsed.toString(),block:receipt.blockNumber,b,phaseBefore:Number(before.phase),phaseAfter:Number(after.phase),version:Number(after.version),policy:Number(await c.policyEpoch()),steps:ctx.rows.slice(start)});
  L.save('composition/outcomes.json',{sourceSHA256:hash(src),compiler:solc.version(),mutantHashes:Object.fromEntries(Object.entries(mutants).map(([k,v])=>[k,v.sourceSHA256])),rows});
  console.log(scenario,mode,variant,receipt.status);
 }
 assert.equal(rows.length,12);await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
