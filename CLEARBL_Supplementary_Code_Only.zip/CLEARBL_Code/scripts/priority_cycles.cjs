// Ten adversarial registration cycles per fixture; actual mined outcomes.
const L=require('./lib.cjs'),assert=require('assert/strict');
(async()=>{const ctx=await L.environment(),f=await L.fixture(ctx),rows=[],receipts=[];
for(const mode of ['single','reserved'])for(const seed of [101,202,303]){
 const c=f[mode],b=await L.issue(ctx,c,`priority-cycles-${mode}-${seed}`);
 const fin=seed===202?[4,3,4]:[3,4,3];
 for(let i=0;i<3;i++)await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[fin[i]].address,ref:L.ethers.toBeHex(i,32),terms:L.H('terms-'+i),flags:3},[1,fin[i]]),'cycle.initial',mode==='reserved');
 for(let round=1;round<=10;round++){
  const forged=await L.signedAction(ctx,c,b,1,{target:ctx.wallets[3].address,ref:L.Z,terms:L.H('forged-'+round),flags:3},[1,3]);
  const tx=await c.connect(ctx.signers[12]).execute(forged.a,forged.sigs,{gasLimit:2000000});let r;try{r=await tx.wait()}catch(e){if(e.code!=='CALL_EXCEPTION')throw e;r=e.receipt;}assert.equal(r.status,0);
  receipts.push({mode,seed,round,hash:tx.hash,data:tx.data,status:r.status,gas:Number(r.gasUsed),block:r.blockNumber,blockHash:r.blockHash});
  let claims=await c.activeClaims(b);const remove=claims[1];const idx=remove.financier===ctx.wallets[3].address?3:4;
  await L.execute(ctx,c,await L.signedAction(ctx,c,b,2,{ref:L.ethers.toBeHex(remove.seq,32)},[idx]),'cycle.discharge');
  const s=await c.record(b);await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[idx].address,ref:L.ethers.toBeHex(s.nextClaim,32),terms:L.H('replacement-'+round),flags:3},[1,idx]),'cycle.append',mode==='reserved');
  claims=await c.activeClaims(b);assert.equal(claims.length,3);assert.equal(claims[0].seq,0n);assert.equal(new Set(claims.map(x=>Number(x.seq))).size,3);
  rows.push({mode,seed,round,forgedAccepted:0,activeClaims:3,seniorCount:1,sequences:claims.map(x=>Number(x.seq))});
 }
 console.log('Cycles complete',mode,seed);
 L.save('safety-sweeps/priority-cycles.json',{rows,receipts,setupReceipts:ctx.rows});
}
await ctx.engine.disconnect();ctx.provider.destroy();})().catch(e=>{console.error(e);process.exitCode=1});
