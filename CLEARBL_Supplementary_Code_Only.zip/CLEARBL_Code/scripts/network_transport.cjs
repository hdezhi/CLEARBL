// Bound pooled RPC connections so receipt watchers cannot exhaust Besu's
// concurrent-connection limit. All final load cells use this same transport.
const ethers=require('ethers'),http=require('http');
const agent=new http.Agent({keepAlive:true,maxSockets:8,maxFreeSockets:8});
ethers.FetchRequest.registerGetUrl(ethers.FetchRequest.createGetUrlFunc({agent}));
module.exports=agent;
