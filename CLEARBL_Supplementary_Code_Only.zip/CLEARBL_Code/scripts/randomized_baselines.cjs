// Published ERC721/TradeTrust implementations; no claim of equivalent financing semantics.
const L=require('./lib.cjs'),fs=require('fs'),path=require('path'),assert=require('assert/strict');
function rng(seed){let s=seed;return()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};}
(async()=>{
 const ctx=await L.environment(),f=await L.fixture(ctx),factory=await L.deploy(ctx,'TitleEscrowFactory'),tt=await L.deploy(ctx,'TradeTrustToken',['Randomized eBL','RBL',await factory.getAddress()]),rows=[];
 for(const seed of [18301,18302,18303,18304,18305,18306,18307,18308]){
  const r=rng(seed),targets=[];let prev=1;for(let i=0;i<12;i++){const candidates=[1,2,12].filter(x=>x!==prev);prev=candidates[Math.floor(r()*2)];targets.push(prev);}
  for(const platform of ['erc721','tradetrust','direct','reserved']){
   let current=1,b,escrow;
   if(platform==='erc721')await L.receipt(ctx,'erc721.issue',f.nft.issue(ctx.wallets[1].address,seed));
   else if(platform==='tradetrust'){
    await L.receipt(ctx,'tradetrust.issue',tt.mint(ctx.wallets[1].address,ctx.wallets[1].address,seed,'0x'));
    escrow=new L.ethers.Contract(await factory.getEscrowAddress(await tt.getAddress(),seed),L.artifact('TitleEscrow').abi,ctx.signers[1]);
   }else b=await L.issue(ctx,f[platform==='direct'?'single':'reserved'],'baseline-'+platform+'-'+seed);
   for(let step=0;step<targets.length;step++){
    const target=targets[step],meta={seed,step,platform,current,target},first=ctx.rows.length;
    if(platform==='erc721'){
     await L.receipt(ctx,'erc721.transfer',f.nft.connect(ctx.signers[current]).transferFrom(ctx.wallets[current].address,ctx.wallets[target].address,seed),meta);
     assert.equal(await f.nft.ownerOf(seed),ctx.wallets[target].address);
    }else if(platform==='tradetrust'){
     await L.receipt(ctx,'tradetrust.transfer',escrow.connect(ctx.signers[current]).transferOwners(ctx.wallets[target].address,ctx.wallets[target].address,'0x'),meta);
     assert.equal(await escrow.beneficiary(),ctx.wallets[target].address);assert.equal(await escrow.holder(),ctx.wallets[target].address);
    }else{
     const c=f[platform==='direct'?'single':'reserved'];await L.execute(ctx,c,await L.signedAction(ctx,c,b,0,{target:ctx.wallets[target].address},[current,target]),'transfer',platform==='reserved',meta);
     assert.equal((await c.record(b)).controller,ctx.wallets[target].address);
    }
    const txs=ctx.rows.slice(first);rows.push({...meta,gas:txs.reduce((n,x)=>n+Number(x.gas),0),inputBytes:txs.reduce((n,x)=>n+x.inputBytes,0),transactions:txs.length});current=target;
   }
  }
  L.save('randomized18/baseline-trials.json',rows);L.save('randomized18/baseline-receipts.json',ctx.rows);console.log('baseline seed',seed,'transfers',rows.length);
 }
 L.save('randomized18/baseline-manifest.json',{seeds:8,transfers:rows.length,completed:new Date().toISOString(),scope:'Common task: aligned controller/beneficiary/holder transfer without claims; native guards retained. Eager-mined gas and calldata only, not timing.',versions:JSON.parse(fs.readFileSync(path.join(L.root,'package.json'))).dependencies});
 await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1;});
