const L=require('./lib.cjs'),assert=require('assert/strict'),fs=require('fs'),path=require('path'),crypto=require('crypto');
(async()=>{
 const ctx=await L.environment(),rows=[],cases=[],cost=[];
 const roles=ctx.wallets.map((_,i)=>i===0?3:i===1?2:6);
 roles[5]|=8;roles[6]|=8;roles[7]|=16;roles[8]|=32;roles[9]|=64;roles[10]|=64;
 const ids=roles.map((_,i)=>i+1),hashOrder=x=>L.ethers.keccak256(L.ethers.AbiCoder.defaultAbiCoder().encode(['uint256[]'],[x]));
 const dir=await L.deploy(ctx,'IssuanceDirectory'),cs=[];
 for(const reserved of [false,true])cs.push(await L.deploy(ctx,'ClearBLPriority',[await dir.getAddress(),reserved,ctx.wallets.map(x=>x.address),ids,roles]));
 const dest=await L.deploy(ctx,'ClearBLPriority',[await dir.getAddress(),false,ctx.wallets.map(x=>x.address),ids,roles]);
 for(const c of [...cs,dest])await(await dir.enroll(await c.getAddress())).wait();await(await dir.seal()).wait();
 async function tx(label,promise,success,meta={}){
  const t=await promise;let r;try{r=await t.wait()}catch(e){r=e.receipt;if(!r)throw e;}
  assert.equal(r.status,success?1:0,label);
  const row={label,...meta,status:r.status,hash:t.hash,block:r.blockNumber,blockHash:r.blockHash,to:t.to,from:t.from,nonce:t.nonce,data:t.data,gas:String(r.gasUsed),logs:r.logs.map(x=>({address:x.address,topics:x.topics,data:x.data}))};rows.push(row);return row;
 }
 async function snap(c,b){return L.stringify({record:await c.record(b),claims:await c.activeClaims(b),order:await c.priorityOrder(b)})}
 async function prepare(c,b,order,signers,overrides={}){
  const old=Array.from(await c.priorityOrder(b));const a=await L.action(ctx,c,b,8,{ref:hashOrder(old),terms:hashOrder(order),...overrides});return {a,order,sigs:await L.signatures(ctx,c,L.AT,a,signers)};
 }
 async function check(label,c,b,x,success,meta={}){
  const before=await snap(c,b);const r=await tx(label,c.connect(ctx.signers[12]).reprioritize(x.a,x.order,x.sigs,{gasLimit:8000000}),success,meta);const after=await snap(c,b);
  if(!success)assert.equal(after,before,label+' state rollback');cases.push({label,...meta,expected:success?'accept':'reject',status:r.status,stateChanged:before!==after});return r;
 }
 for(let mode=0;mode<2;mode++){
  const c=cs[mode];
  for(const n of [2,4,8,16]){
   const b=await L.issue(ctx,c,`priority-${mode}-${n}`),fins=Array.from({length:n},(_,i)=>i+2),all=[1,...fins],order=Array.from({length:n},(_,i)=>n-1-i);
   for(let i=0;i<n;i++)await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[fins[i]].address,ref:L.ethers.toBeHex(i,32),terms:L.H(`terms-${i}`),flags:0},[1,fins[i]]),'create-priority-claim',false,{mode,n});
   await L.confirm(ctx,c,b,0);await L.confirm(ctx,c,b,1);
   for(const omitted of all)await check('missing-consent',c,b,await prepare(c,b,order,all.filter(i=>i!==omitted)),false,{mode,n,omitted});
   const invalid=[['duplicate',order.map((x,i)=>i===1?order[0]:x),{}],['unknown',order.map((x,i)=>i===0?999:x),{}],['short',order.slice(1),{}],['wrong-commitment',order,{terms:L.H('different')}],['wrong-predecessor',order,{ref:L.H('old')}],['unchanged',Array.from({length:n},(_,i)=>i),{}],['version',order,{version:999}],['policy',order,{policy:999}],['wrong-kind',order,{kind:0}],['unused-fields',order,{target:ctx.wallets[2].address}]];
   for(const [label,o,a]of invalid)await check(label,c,b,await prepare(c,b,o,all,a),false,{mode,n});
   const before=await c.record(b),claimsBefore=Array.from(await c.activeClaims(b)).map(x=>[String(x.seq),x.financier,x.terms,String(x.blocks)]),stale=await prepare(c,b,order,all);
   for(let rep=0;rep<3;rep++){
    const next=Array.from(await c.priorityOrder(b)).reverse();const r=await check('consented-priority',c,b,await prepare(c,b,next,all),true,{mode,n,rep});cost.push({mode,n,rep,gas:Number(r.gas),signatures:all.length});
    assert.deepEqual(Array.from(await c.priorityOrder(b)).map(Number),next.map(Number));
   }
   const after=await c.record(b);assert.equal(after.version,before.version+3n);assert.equal(after.nextClaim,before.nextClaim);assert.equal(after.pay.digest,L.Z);assert.equal(after.doc.digest,L.Z);
   assert.deepEqual(Array.from(await c.activeClaims(b)).map(x=>[String(x.seq),x.financier,x.terms,String(x.blocks)]).sort(),claimsBefore.sort());
   await check('stale-replay',c,b,stale,false,{mode,n});
   // Transfer and same-ledger migration preserve the negotiated order and claim data.
   const saved=Array.from(await c.priorityOrder(b)).map(Number);
   await L.execute(ctx,c,await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]),'transfer-with-priority',false,{mode,n});
   assert.deepEqual(Array.from(await c.priorityOrder(b)).map(Number),saved);
   await L.execute(ctx,c,await L.signedAction(ctx,c,b,7,{target:await dest.getAddress()},Array.from(new Set([0,2,...fins]))),'migrate-priority',false,{mode,n});
   assert.deepEqual(Array.from(await dest.priorityOrder(b)).map(Number),saved);
   // A signature for the old domain cannot change destination order.
   const migrated=await prepare(dest,b,[...saved].reverse(),Array.from(new Set([2,...fins])));
   migrated.sigs=await L.signatures(ctx,c,L.AT,migrated.a,Array.from(new Set([2,...fins])));
   await check('cross-domain-replay',dest,b,migrated,false,{mode,n});
   const remove=saved[1];await L.execute(ctx,dest,await L.signedAction(ctx,dest,b,2,{ref:L.ethers.toBeHex(remove,32)},[fins[remove]]),'discharge-negotiated-rank',false,{mode,n});
   assert.deepEqual(Array.from(await dest.priorityOrder(b)).map(Number),saved.filter(x=>x!==remove));
   await L.execute(ctx,dest,await L.signedAction(ctx,dest,b,1,{target:ctx.wallets[fins[0]].address,ref:L.ethers.toBeHex(n,32),terms:L.H('new-junior'),flags:0},Array.from(new Set([2,fins[0]]))),'append-junior',false,{mode,n});
   assert.deepEqual(Array.from(await dest.priorityOrder(b)).map(Number),[...saved.filter(x=>x!==remove),n]);
   cases.push({label:'transfer-migration-discharge-append-preserve-priority',mode,n,status:1});
  }
 }
 // Phase and pending guards, after the scalable matrix.
 const c=cs[1],b=await L.issue(ctx,c,'phase-guards'),all=[1,3,4];
 for(let i=0;i<2;i++)await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[i+3].address,ref:L.ethers.toBeHex(i,32),terms:L.H('phase'+i),flags:0},[1,i+3]),'phase-claim');
 const transfer=await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]);await tx('reserve',c.reserve(transfer.a,transfer.sigs,await L.now(ctx)+30),true);
 await check('pending',c,b,await prepare(c,b,[1,0],all),false);
 await ctx.provider.send('evm_increaseTime',[31]);await ctx.provider.send('evm_mine',[]);await tx('cleanup',c.expire(b),true);
 const expired=await prepare(c,b,[1,0],all,{deadline:await L.now(ctx)-1});await check('expired',c,b,expired,false);
 await L.execute(ctx,c,await L.signedAction(ctx,c,b,5,{},[9,10]),'freeze');await check('frozen',c,b,await prepare(c,b,[1,0],all),false);
 await L.execute(ctx,c,await L.signedAction(ctx,c,b,6,{target:ctx.wallets[5].address},[0,1,3,4,9,10]),'recover');
 await L.confirm(ctx,c,b,0);await L.confirm(ctx,c,b,1);const cap=await L.authorize(ctx,c,b);await check('authorized',c,b,await prepare(c,b,[1,0],all),false);
 await tx('consume',c.connect(ctx.signers[8]).consume(b,cap),true);await check('consumed',c,b,await prepare(c,b,[1,0],all),false);
 const source=fs.readFileSync(path.join(L.root,'contracts/ClearBLPriority.sol'));const out={schema:1,scope:'Executed Solidity extension tests on Ganache; no legal-priority or real financing-service claim',sourceSHA256:crypto.createHash('sha256').update(source).digest('hex'),compiler:JSON.parse(fs.readFileSync(path.join(L.root,'build/manifest.json'))).compiler,cases,cost,receipts:rows,setupAndBusinessReceipts:ctx.rows};
 L.save('revision8/priority.json',out);console.log(L.stringify({cases:cases.length,accepted:cases.filter(x=>x.status===1).length,rejected:cases.filter(x=>x.status===0).length,receipts:rows.length+ctx.rows.length,cost}));
 await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
