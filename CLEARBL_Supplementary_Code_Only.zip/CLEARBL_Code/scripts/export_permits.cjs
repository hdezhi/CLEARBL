// Trusted consortium RPC comparison, not an independent IBFT light client.
const L=require('./lib.cjs'),fs=require('fs');
(async()=>{
 const rows=JSON.parse(fs.readFileSync(L.root+'/results/ibft4/receipts.json')).filter(r=>r.label==='consume');
 const providers=Array.from({length:4},(_,i)=>new L.ethers.JsonRpcProvider('http://127.0.0.1:'+(39400+i),undefined,{batchMaxCount:1,cacheTimeout:-1}));
 const abi=new L.ethers.Interface(L.artifact('ClearBL').abi),out=[];
 for(const row of rows){
  const r=await providers[0].getTransactionReceipt(row.hash);if(!r||r.status!==1)throw Error('receipt');
  const blocks=await Promise.all(providers.map(p=>p.getBlock(r.blockNumber)));
  const agreeing=blocks.filter(b=>b&&b.hash===r.blockHash).length;if(agreeing<3)throw Error('insufficient trusted RPC agreement');
  const log=r.logs.filter(l=>l.address.toLowerCase()===row.to.toLowerCase()).map(l=>{try{return abi.parseLog(l)}catch{return null}}).find(l=>l&&l.name==='Consumed');
  if(!log)throw Error('Consumed missing');
  out.push({transaction:row.hash,block:r.blockNumber,blockHash:r.blockHash,contract:row.to,chainId:20260929,agreeingRPCs:agreeing,finalized:true,finalityAssumption:'IBFT-finalized receipt from known enrolled contract; at least three trusted local RPCs agree on its block hash; no independent seal verification',businessId:log.args.b,capability:log.args.capability,terminal:log.args.terminal,beneficiary:log.args.beneficiary,job:log.args.job,location:log.args.location});
 }
 L.save('ibft4/consumed-permits.json',out);console.log('Exported',out.length,'real consumption receipts');providers.forEach(p=>p.destroy());
})().catch(e=>{console.error(e);process.exitCode=1});
