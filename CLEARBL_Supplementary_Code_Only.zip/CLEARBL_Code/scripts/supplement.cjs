const L=require('./lib.cjs'),assert=require('assert/strict');
(async()=>{
 const ctx=await L.environment(),f=await L.fixture(ctx),c=f.single,checks=[];
 for(const first of [2,12]){
  const b=await L.issue(ctx,c,'ordered-'+first),x=await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]),y=await L.signedAction(ctx,c,b,0,{target:ctx.wallets[12].address},[1,12]);
  await L.execute(ctx,c,first===2?x:y,'ordered-transfer');let rejected=false;const second=first===2?y:x;
  try{await c.execute.staticCall(second.a,second.sigs)}catch(e){if(e.code!=='CALL_EXCEPTION')throw e;rejected=true;}
  assert(rejected);assert.equal((await c.record(b)).controller,ctx.wallets[first].address);checks.push({case:'proposer-order',first:ctx.wallets[first].address,secondRejected:rejected,guaranteesFairness:false});
 }
 const b=await L.issue(ctx,c,'mandatory-bank-offline');const fr=await L.signedAction(ctx,c,b,5,{},[9,10]);await L.execute(ctx,c,fr,'freeze');
 const rec=await L.signedAction(ctx,c,b,6,{target:ctx.wallets[13].address},[9,10,0,1]);await L.execute(ctx,c,rec,'recover');
 await L.confirm(ctx,c,b,0,[13,6]);await L.confirm(ctx,c,b,1);assert(await c.ready(b));checks.push({case:'mandatory-bank-replacement',requiresAffectedPartyConsent:true,ready:true});
 const growth=[];
 for(const count of [1,4,8,16]){
  const id=await L.issue(ctx,c,'manyclaims'+count);let total=0;
  for(let i=0;i<count;i++){const r=await L.execute(ctx,c,await L.signedAction(ctx,c,id,1,{target:ctx.wallets[3].address,ref:L.ethers.toBeHex(i,32),terms:L.H('c'+i),flags:3},[1,3]),'create-claim');total+=Number(r.gas);}
  const transfer=await L.execute(ctx,c,await L.signedAction(ctx,c,id,0,{target:ctx.wallets[2].address},[1,2,3]),'transfer-manyclaims');
  const discharge=await L.execute(ctx,c,await L.signedAction(ctx,c,id,2,{ref:L.Z},[3]),'discharge-first');
  growth.push({activeClaims:count,allCreateGas:total,transferGas:Number(transfer.gas),firstDischargeGas:Number(discharge.gas)});
 }
 L.save('supplement-tests.json',checks);L.save('claim-gas.json',growth);L.save('supplement-receipts.json',ctx.rows);console.log(L.stringify({checks,growth}));await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
