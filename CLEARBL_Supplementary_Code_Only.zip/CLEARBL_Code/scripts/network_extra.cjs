// Additional packet-stream disruption, partition and paced-load observations.
const L=require('./lib.cjs'),fs=require('fs'),path=require('path');
const rpcAgent=require('./network_transport.cjs');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const dir=path.resolve(process.argv[2]),tag=process.env.CLEARBL_TAG||'ibft4',n=JSON.parse(fs.readFileSync(path.join(dir,'network.json'))).length;
 const faultPath=path.join(L.root,'results',tag,'network-extra.json');const results=fs.existsSync(faultPath)?JSON.parse(fs.readFileSync(faultPath)):[];
 const ctx=await L.environment('http://127.0.0.1:39400'),f=await L.fixture(ctx);
 function bytes(p){let total=0;try{for(const e of fs.readdirSync(p,{withFileTypes:true})){const q=path.join(p,e.name);try{total+=e.isDirectory()?bytes(q):fs.statSync(q).size}catch{}}}catch{}return total;}
 const diskPath=path.join(L.root,'results',tag,'database-growth.json');const disk=fs.existsSync(diskPath)?JSON.parse(fs.readFileSync(diskPath)):[];function snapshot(stage){disk.push({stage,utc:new Date().toISOString(),node0DatabaseBytes:bytes(path.join(dir,'node0/database')),note:'live filesystem logical file sizes; includes all historical/setup/empty-block activity and compaction; not per-document attribution'});L.save(tag+'/database-growth.json',disk);}
 const cfg=x=>fs.writeFileSync(path.join(dir,'impairment.json'),JSON.stringify({delayMs:0,jitterMs:0,cut:[],...x}));
 // Logical node partition filters both ends of every proxied connection.
 for(const [label,config] of [['connected',{}],['one-isolated',{isolated:[n-1]}],['two-isolated',{isolated:[n-2,n-1]}],['stream-reset-10pct',{resetProbability:.10}],['restored',{}]]){
  if(results.some(r=>r.label===label))continue;
  const initialHeight=await ctx.provider.getBlockNumber(),changed=performance.now();cfg(config);let recoveryMs=null;if(label==='restored'){for(let j=0;j<120;j++){await sleep(500);if(await ctx.provider.getBlockNumber()>initialHeight){recoveryMs=performance.now()-changed;break;}}}await sleep(5000);let before=await ctx.provider.getBlockNumber(),start=performance.now();await sleep(12000);let after=await ctx.provider.getBlockNumber();
  results.push({label,config,validators:n,recoveryMs,blocks:after-before,elapsedMs:performance.now()-start});L.save(tag+'/network-extra.json',results);console.log(tag,label,after-before);
 }
 cfg({});
 // Fixed 96-operation offered-load bursts. Includes submission pacing and drain,
 // so these are finite offered-load comparisons, not a steady-state capacity claim.
 const loadsPath=path.join(L.root,'results',tag,'paced-load.json');const loads=fs.existsSync(loadsPath)?JSON.parse(fs.readFileSync(loadsPath)):[];snapshot(loads.length?'before-resumed-paced-workloads':'before-paced-workloads');
 for(const rate of [8,32,128])for(const mode of ['single','reserved']){
  if(loads.some(r=>r.rate===rate&&r.mode===mode))continue;
  const c=f[mode],count=96,ids=[];
  for(let off=0;off<count;off+=12)ids.push(...await Promise.all(Array.from({length:12},(_,j)=>L.issue(ctx,c,`${tag}-paced-${rate}-${mode}-${off+j}`))));
  const intents=[];for(let off=0;off<ids.length;off+=8)intents.push(...await Promise.all(ids.slice(off,off+8).map(b=>L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]))));
  const start=performance.now(),rows=[],nonces=await Promise.all([9,10,11].map(i=>ctx.provider.getTransactionCount(ctx.wallets[i].address,'pending')));
  async function submit(i,stage){const k=i%3,w=ctx.wallets[k+9],nonce=nonces[k]++,x=intents[i];
   const until=await L.now(ctx)+25;const data=stage==='reserve'?c.interface.encodeFunctionData('reserve',[x.a,x.sigs,until]):c.interface.encodeFunctionData('execute',[x.a,x.sigs]);
   const t=performance.now(),tx=await w.sendTransaction({to:await c.getAddress(),data,nonce,gasLimit:400000,gasPrice:1000000000n});let r;
   try{r=await tx.wait()}catch(e){if(e.code!=='CALL_EXCEPTION')throw e;r=e.receipt;}
   rows.push({i,stage,status:r.status,ms:performance.now()-t,completedMs:performance.now()-start,gas:r.gasUsed.toString(),hash:tx.hash});return r.status;
  }
  const tasks=[];
  for(let i=0;i<count;i++){
   await sleep(Math.max(0,start+i*1000/rate-performance.now()));
   const task=(async()=>{if(mode==='reserved'&&await submit(i,'reserve')!==1)return;await submit(i,'execute')})();task.catch(()=>{});tasks.push(task);
  }
  await Promise.all(tasks);const elapsed=performance.now()-start,success=rows.filter(r=>r.stage==='execute'&&r.status===1).length;
  loads.push({mode,rate,attempted:count,success,ms:elapsed,usefulPerSecond:success/(elapsed/1000),rows});L.save(tag+'/paced-load.json',loads);console.log(tag,'paced',rate,mode,success,elapsed.toFixed(0));snapshot(`after-${rate}-${mode}`);
 }
 ctx.provider.destroy();rpcAgent.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
