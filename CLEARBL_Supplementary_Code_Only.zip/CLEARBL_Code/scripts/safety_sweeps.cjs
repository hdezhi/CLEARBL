// Parameter sweeps of actual EVM transactions. No inferred attack probabilities.
const L=require('./lib.cjs'),assert=require('assert/strict'),crypto=require('crypto'),fs=require('fs'),path=require('path');
const out={method:'Ganache eager mining; signed conflicting intents; deterministic seeds 101,202,303; no timing inference',utc:new Date().toISOString(),sourceSHA256:crypto.createHash('sha256').update(fs.readFileSync(path.join(L.root,'contracts/ClearBL.sol'))).digest('hex'),conflict:[],financing:[],release:[],replay:[],receipts:[]};
function shuffled(a,seed){a=a.slice();let s=seed;for(let i=a.length-1;i>0;i--){s=(Math.imul(s,1664525)+1013904223)>>>0;const j=s%(i+1);[a[i],a[j]]=[a[j],a[i]];}return a;}
(async()=>{
 const ctx=await L.environment();
 for(let i=0;i<16;i++)ctx.wallets.push(new L.ethers.Wallet(L.key(100+i),ctx.provider));
 const dir=await L.deploy(ctx,'IssuanceDirectory');const contracts={};
 for(const mode of ['single','reserved']){contracts[mode]=await L.deploy(ctx,'ClearBL',[await dir.getAddress(),mode==='reserved',[...ctx.wallets.slice(0,15),...ctx.wallets.slice(18)].map(w=>w.address),[...L.institutions,...Array.from({length:16},(_,i)=>100+i)],[...L.roles,...Array(16).fill(4)]]);await(await dir.enroll(await contracts[mode].getAddress())).wait();}
 await(await dir.seal()).wait();
 async function mined(promise,meta,expected){const tx=await promise;let r;try{r=await tx.wait()}catch(e){if(e.code!=='CALL_EXCEPTION')throw e;r=e.receipt;}assert.ok(r);if(expected!==undefined)assert.equal(r.status,expected,JSON.stringify(meta));const row={...meta,hash:tx.hash,from:tx.from,to:tx.to,nonce:tx.nonce,data:tx.data,status:r.status,gas:Number(r.gasUsed),block:r.blockNumber,blockHash:r.blockHash};out.receipts.push(row);return row;}
 const save=()=>{L.save('safety-sweeps/results.json',out);L.save('safety-sweeps/setup-receipts.json',ctx.rows);};
 for(const mode of ['single','reserved'])for(const n of [2,4,8,12,16,20])for(const seed of [101,202,303]){
  const c=contracts[mode],b=await L.issue(ctx,c,`conflict-${mode}-${n}-${seed}`),xs=[];
  for(let i=0;i<n;i++)xs.push(await L.signedAction(ctx,c,b,0,{target:ctx.wallets[i%2?2:12].address,ref:L.H('intent-'+i)},[1,i%2?2:12]));
  const order=shuffled(Array.from({length:n},(_,i)=>i),seed),until=await L.now(ctx)+30;
  const rows=await Promise.all(order.map(i=>mined(mode==='single'?c.connect(ctx.signers[12]).execute(xs[i].a,xs[i].sigs,{gasLimit:2000000}):c.connect(ctx.signers[12]).reserve(xs[i].a,xs[i].sigs,until,{gasLimit:2000000}),{family:'conflict',mode,n,seed,i})));
  assert.equal(rows.filter(x=>x.status===1).length,1);const winner=rows.find(x=>x.status===1).i;
  if(mode==='reserved')await mined(c.connect(ctx.signers[12]).execute(xs[winner].a,xs[winner].sigs,{gasLimit:2000000}),{family:'conflict-commit',mode,n,seed},1);
  const state=await c.record(b);assert.equal(state.version,1n);assert.equal(state.controller,xs[winner].a.target);
  out.conflict.push({mode,n,seed,accepted:1,rejected:n-1,version:Number(state.version),winner,order});save();
 }
 console.log('Conflict matrix complete:',out.conflict.length);
 for(const mode of ['single','reserved'])for(const n of [1,2,4,8,16])for(const seed of [101,202,303]){
  const c=contracts[mode],b=await L.issue(ctx,c,`finance-${mode}-${n}-${seed}`),order=shuffled(Array.from({length:n},(_,i)=>18+i),seed);
  for(let i=0;i<n;i++)await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[order[i]].address,ref:L.ethers.toBeHex(i,32),terms:L.H('terms-'+i),flags:3},[1,order[i]]),'sweep.claim',mode==='reserved',{mode,n,seed});
  const before=await c.record(b),claims=await c.activeClaims(b);assert.deepEqual(claims.map(x=>Number(x.seq)),Array.from({length:n},(_,i)=>i));
  assert.deepEqual(claims.map(x=>x.financier),order.map(i=>ctx.wallets[i].address));
  for(const omit of order){const x=await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2,...order.filter(i=>i!==omit)]);await mined(c.connect(ctx.signers[12]).execute(x.a,x.sigs,{gasLimit:4000000}),{family:'missing-financier',mode,n,seed,omit},0);}
  assert.equal(L.stringify(await c.record(b)),L.stringify(before));
  const valid=await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2,...order]);await L.execute(ctx,c,valid,'sweep.consented-transfer',mode==='reserved',{mode,n,seed});assert.equal(L.stringify(await c.activeClaims(b)),L.stringify(claims));
  const mid=Math.floor(n/2);await L.execute(ctx,c,await L.signedAction(ctx,c,b,2,{ref:L.ethers.toBeHex(mid,32)},[order[mid]]),'sweep.discharge',false,{mode,n,seed});
  const remaining=await c.activeClaims(b);assert.deepEqual(remaining.map(x=>Number(x.seq)),Array.from({length:n},(_,i)=>i).filter(i=>i!==mid));
  // After discharge there is capacity: rejection isolates the stale sequence, not MAX_CLAIMS.
  const forged=await L.signedAction(ctx,c,b,1,{target:ctx.wallets[order[mid]].address,ref:L.Z,terms:L.H('forged-seniority'),flags:3},[2,order[mid]]);
  await mined(c.connect(ctx.signers[12]).execute(forged.a,forged.sigs,{gasLimit:4000000}),{family:'forged-sequence',mode,n,seed},0);
  const legal=await L.signedAction(ctx,c,b,1,{target:ctx.wallets[order[mid]].address,ref:L.ethers.toBeHex(n,32),terms:L.H('new-claim'),flags:3},[2,order[mid]]);
  await L.execute(ctx,c,legal,'sweep.append-after-discharge',mode==='reserved',{mode,n,seed});const final=await c.activeClaims(b);assert.deepEqual(final.map(x=>Number(x.seq)),[...remaining.map(x=>Number(x.seq)),n]);
  out.financing.push({mode,n,seed,registrationOrder:order,missingConsentAttempts:n,missingConsentAccepted:0,legalTransferAccepted:1,forgedSequenceAccepted:0,sequenceAfterDischarge:remaining.map(x=>Number(x.seq)),sequenceAfterAppend:final.map(x=>Number(x.seq)),seniorCount:1});save();
 }
 console.log('Financing matrix complete:',out.financing.length);
 const cases=['missing-payment','missing-document','blocking-claim','bad-source','stale-evidence','wrong-terminal','expired-permit','withdrawn-permit','valid'];
 for(const mode of ['single','reserved'])for(const scenario of cases)for(const seed of [101,202,303]){
  const c=contracts[mode],b=await L.issue(ctx,c,`release-${mode}-${scenario}-${seed}`);
  if(scenario==='blocking-claim')await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[3].address,terms:L.H('terms'),flags:3},[1,3]),'sweep.blocking-claim',mode==='reserved');
  if(!['missing-payment','bad-source'].includes(scenario))await L.confirm(ctx,c,b,0);
  if(scenario!=='missing-document')await L.confirm(ctx,c,b,1);
  if(scenario==='bad-source'){const e=await L.evidence(ctx,c,b,0,[6,13]);await mined(c.connect(ctx.signers[12]).confirm(e.e,e.sigs,{gasLimit:2000000}),{family:'bad-source-proof',mode,scenario,seed},0);}
  if(scenario==='stale-evidence')await L.execute(ctx,c,await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]),'sweep.evidence-staling-transfer',mode==='reserved');
  let result,stage;
  if(['wrong-terminal','expired-permit','withdrawn-permit','valid'].includes(scenario)){
   const cap=await L.authorize(ctx,c,b,1,mode==='reserved');stage='consume';
   if(scenario==='expired-permit'){await ctx.provider.send('evm_increaseTime',[901]);await ctx.provider.send('evm_mine',[]);}
   if(scenario==='withdrawn-permit')await L.receipt(ctx,'sweep.withdraw',c.connect(ctx.signers[5]).revokeEvidence(b,0));
   const before=await c.record(b);result=await mined(c.connect(ctx.signers[scenario==='wrong-terminal'?12:8]).consume(b,cap,{gasLimit:2000000}),{family:'release',mode,scenario,seed,stage},scenario==='valid'?1:0);if(scenario!=='valid')assert.equal(L.stringify(await c.record(b)),L.stringify(before));
  }else{stage='authorize';const controller=scenario==='stale-evidence'?2:1,x=await L.signedAction(ctx,c,b,4,{target:ctx.wallets[8].address,recipient:ctx.wallets[controller].address,ref:L.H('job'),terms:L.H('port')},[0,controller,8]),before=await c.record(b);result=await mined(c.connect(ctx.signers[12]).execute(x.a,x.sigs,{gasLimit:2000000}),{family:'release',mode,scenario,seed,stage},0);assert.equal(L.stringify(await c.record(b)),L.stringify(before));}
  out.release.push({mode,scenario,seed,stage,status:result.status,gas:result.gas});save();
 }
 console.log('Release matrix complete:',out.release.length);
 for(const mode of ['single','reserved']){
  const c=contracts[mode],b=await L.issue(ctx,c,'replay-'+mode);await L.confirm(ctx,c,b,0);await L.confirm(ctx,c,b,1);const cap=await L.authorize(ctx,c,b,1,mode==='reserved');await L.receipt(ctx,'sweep.first-consume',c.connect(ctx.signers[8]).consume(b,cap));const before=L.stringify(await c.record(b)),rows=[];
  for(let start=0;start<500;start+=25){rows.push(...await Promise.all(Array.from({length:25},(_,i)=>mined(c.connect(ctx.signers[8]).consume(b,cap,{gasLimit:300000}),{family:'replay',mode,attempt:start+i+1},0))));if((start+25)%100===0)console.log('Replay',mode,start+25);save();}
  assert.equal(L.stringify(await c.record(b)),before);for(const n of [1,10,50,100,250,500])out.replay.push({mode,attempts:n,accepted:rows.slice(0,n).filter(x=>x.status===1).length,rejected:n,receiptPrefix:true});save();
 }
 out.completedUtc=new Date().toISOString();save();console.log('COMPLETE',JSON.stringify({conflict:out.conflict.length,financing:out.financing.length,release:out.release.length,replay:out.replay.length,minedOutcomes:out.receipts.length,setup:ctx.rows.length}));await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
