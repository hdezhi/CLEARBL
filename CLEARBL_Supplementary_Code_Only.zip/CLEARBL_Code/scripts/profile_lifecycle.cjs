// Integrated admission + negotiated priority + full release profile.
// Eager-mined EVM functional/gas experiment; no network latency claim.
const L=require('./lib.cjs'),assert=require('assert/strict'),fs=require('fs'),path=require('path'),crypto=require('crypto');
(async()=>{
 const ctx=await L.environment(),directory=await L.deploy(ctx,'AdmittedIssuanceDirectory');
 const registry=await L.deploy(ctx,'ObligationAdmissionRegistry',[await directory.getAddress()]);
 await(await directory.bindRegistry(await registry.getAddress())).wait();
 const issuer=await L.deploy(ctx,'AdmittedIssuer',[await registry.getAddress(),ctx.wallets[0].address,ctx.wallets[7].address,1,L.H('integrated-carrier')]);
 await(await registry.enroll(await issuer.getAddress(),L.H('integrated-carrier'))).wait();await(await registry.seal()).wait();
 const roles=[...L.roles];roles[0]=2;const contracts=[];
 for(const mode of [false,true])contracts.push(await L.deploy(ctx,'ClearBLPriority',[await directory.getAddress(),mode,[...ctx.wallets.slice(0,15).map(x=>x.address),await issuer.getAddress()],[...L.institutions,1],[...roles,1]]));
 for(const c of contracts)await(await directory.enroll(await c.getAddress())).wait();await(await directory.seal()).wait();
 const domain={name:'CLEAR-BL-Admission',version:'1',chainId:ctx.chainId,verifyingContract:await issuer.getAddress()};
 const types={Admission:[['target','address'],['carrierReference','bytes32'],['platformAlias','bytes32'],['controller','address'],['bank','address'],['document','bytes32'],['paymentTerms','bytes32'],['deadline','uint256']].map(([name,type])=>({name,type}))};
 const hashOrder=x=>L.ethers.keccak256(L.ethers.AbiCoder.defaultAbiCoder().encode(['uint256[]'],[x]));const runs=[];
 for(let rep=0;rep<3;rep++)for(const mode of (rep%2?[1,0]:[0,1])){
  const c=contracts[mode],first=ctx.rows.length,name=`integrated-${mode}-${rep}`;
  const admission={target:await c.getAddress(),carrierReference:L.H(name),platformAlias:L.H('alias-'+name),controller:ctx.wallets[1].address,bank:ctx.wallets[5].address,document:L.H('document-'+name),paymentTerms:L.H('payment-'+name),deadline:await L.now(ctx)+600};
  const sigs=await Promise.all([0,7].map(i=>ctx.wallets[i].signTypedData(domain,types,admission)));
  await L.receipt(ctx,'joint-issue',issuer.issue(admission,...sigs));const o=await issuer.obligation(admission.carrierReference),b=await c.businessId(await issuer.getAddress(),o);
  await L.execute(ctx,c,await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]),'transfer',!!mode);
  for(let j=0;j<2;j++)await L.execute(ctx,c,await L.signedAction(ctx,c,b,1,{target:ctx.wallets[j+3].address,ref:L.ethers.toBeHex(j,32),terms:L.H('claim-'+j),flags:3},[2,j+3]),'claim-'+j,!!mode);
  const x=await L.signedAction(ctx,c,b,8,{ref:hashOrder([0,1]),terms:hashOrder([1,0])},[2,3,4]);
  await L.receipt(ctx,'reprioritize',c.reprioritize(x.a,[1,0],x.sigs));assert.deepEqual(Array.from(await c.priorityOrder(b)),[1n,0n]);
  for(const j of [1,0])await L.execute(ctx,c,await L.signedAction(ctx,c,b,2,{ref:L.ethers.toBeHex(j,32)},[j+3]),'discharge-'+j,false);
  assert.equal((await c.activeClaims(b)).length,0);
  await L.confirm(ctx,c,b,0);await L.confirm(ctx,c,b,1);const cap=await L.authorize(ctx,c,b,2,!!mode);await L.receipt(ctx,'consume',c.connect(ctx.signers[8]).consume(b,cap));
  assert.equal((await c.record(b)).phase,3n);assert.equal(await registry.admittedBy(o),await issuer.getAddress());assert.equal(await directory.current(b),await c.getAddress());
  const receipts=ctx.rows.slice(first);assert.equal(receipts.length,mode?15:11);
  runs.push({mode:mode?'reserved':'direct',rep,b,transactions:receipts.length,gas:receipts.reduce((n,r)=>n+Number(r.gas),0),inputBytes:receipts.reduce((n,r)=>n+r.inputBytes,0),logBytes:receipts.reduce((n,r)=>n+r.logBytes,0),receipts});
 }
 const sourceSHA256=Object.fromEntries(['ClearBL.sol','ClearBLPriority.sol','AdmittedIssuer.sol'].map(name=>[name,crypto.createHash('sha256').update(fs.readFileSync(path.join(L.root,'contracts',name))).digest('hex')]));
 L.save('revision8/profile-lifecycle.json',{scope:'Eager-mined integrated profile; two claims, negotiated priority and both discharges. Different workflow from historical one-claim core lifecycle. No network latency claim.',sourceSHA256,runs});
 console.log(L.stringify(runs.map(({receipts,...r})=>r)));await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
