const fs=require('fs'),path=require('path'),L=require('./lib.cjs');
(async()=>{
 const dir=path.resolve(process.argv[2]),faults=JSON.parse(fs.readFileSync(L.root+'/results/ibft4/faults.json'));
 const last=faults.at(-1),requested=fs.statSync(path.join(dir,'fault-request.json')).mtimeMs,start=Date.now(),observations=[];
 for(let i=0;i<120;i++){
  const r=await fetch('http://127.0.0.1:39400',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'eth_blockNumber',params:[]})});
  const height=Number(BigInt((await r.json()).result));observations.push({utc:new Date().toISOString(),height});
  if(height>last.after)break;await new Promise(r=>setTimeout(r,1000));
 }
 const recovered=observations.at(-1).height>last.after;
 const result={requested:new Date(requested).toISOString(),observationStart:new Date(start).toISOString(),firstPollAlreadyAdvanced:observations[0].height>last.after,recovered,elapsedSinceRequestMs:Date.now()-requested,observations,note:'first observed progress; if first poll already advanced the elapsed time is an upper bound, not exact recovery latency'};
 const logPath=path.join(dir,'node0.log');
 if(fs.existsSync(logPath)){
  const lines=fs.readFileSync(logPath,'utf8').split(/\r?\n/),needle='#'+(last.after+1).toLocaleString('en-US')+' /';
  const line=lines.find(s=>s.includes(needle)&&(s.includes('Produced')||s.includes('Imported')));
  if(line){const stamp=line.split(' | ')[0].replace(' ','T').replace(/([+-]\d\d)(\d\d)$/,'$1:$2');result.firstNewBlockLog=line;result.restartRequestToFirstNewBlockLogSeconds=(Date.parse(stamp)-requested)/1000;result.method='same-host request-file timestamp and validator-0 block log; includes startup/synchronization and consensus recovery';}
 }
 L.save('ibft4/recovery-followup.json',result);
 console.log('Recovery followup',recovered,'seconds since request',(Date.now()-requested)/1000);
})().catch(e=>{console.error(e);process.exit(1)});
