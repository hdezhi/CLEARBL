const fs=require('fs'),path=require('path'),solc=require('solc'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const sources=Object.fromEntries(fs.readdirSync(path.join(root,'contracts')).filter(x=>x.endsWith('.sol')).map(x=>[x,{content:fs.readFileSync(path.join(root,'contracts',x),'utf8')}]));
for(const name of ['TradeTrustToken','TitleEscrowFactory','TitleEscrow']) sources['vendor/'+name+'.sol']={content:fs.readFileSync(path.join(root,'node_modules/@tradetrust-tt/token-registry/contracts',name+'.sol'),'utf8')};
const input={language:'Solidity',sources,settings:{optimizer:{enabled:true,runs:200},viaIR:true,evmVersion:'paris',outputSelection:{'*':{'*':['abi','evm.bytecode.object','evm.deployedBytecode.object','storageLayout']}}}};
const output=JSON.parse(solc.compile(JSON.stringify(input),{import:p=>{try{return {contents:fs.readFileSync(p.startsWith('vendor/')?path.join(root,'node_modules/@tradetrust-tt/token-registry/contracts',p.slice(7)):path.join(root,'node_modules',p),'utf8')}}catch{return {error:`missing ${p}`}}}}));
for(const e of output.errors||[]) console.log(e.formattedMessage);
if((output.errors||[]).some(e=>e.severity==='error'))process.exit(1);
fs.mkdirSync(path.join(root,'build'),{recursive:true});
const manifest={compiler:solc.version(),optimizer:input.settings.optimizer,viaIR:true,evmVersion:'paris',sources:{},contracts:{}};
for(const [file,data]of Object.entries(sources))manifest.sources[file]=crypto.createHash('sha256').update(data.content).digest('hex');
for(const [file,contracts] of Object.entries(output.contracts))for(const [name,c] of Object.entries(contracts))if(sources[file]){
 fs.writeFileSync(path.join(root,'build',name+'.json'),JSON.stringify(c,null,2));
 manifest.contracts[name]={runtimeBytes:c.evm.deployedBytecode.object.length/2,source:file};
}
fs.writeFileSync(path.join(root,'build','manifest.json'),JSON.stringify(manifest,null,2));console.log(JSON.stringify(manifest.contracts));
