const fs=require('fs'),path=require('path'),L=require('./lib.cjs');
const rpcAgent=require('./network_transport.cjs');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function rpc(url,method,params=[]){let r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})});let j=await r.json();if(j.error)throw Error(JSON.stringify(j.error));return j.result;}
(async()=>{
 const dir=path.resolve(process.argv[2]),url='http://127.0.0.1:39400';
 const ctx=await L.environment(url),f=await L.fixture(ctx);
 function impairment(value){fs.writeFileSync(path.join(dir,'impairment.json'),JSON.stringify({delayMs:0,jitterMs:0,cut:[],seed:260929,...value}));}
 const prior=path.join(L.root,'results/ibft4/network-load.json');
 const results=fs.existsSync(prior)?JSON.parse(fs.readFileSync(prior)):[];
 async function batch(profile,objects,mode){
  const n=objects===1?24:objects,c=f[mode];
  const list=[];
  for(let offset=0;offset<objects;offset+=8)list.push(...await Promise.all(Array.from({length:Math.min(8,objects-offset)},(_,j)=>L.issue(ctx,c,`${profile}-${mode}-${objects}-${offset+j}`))));
  const requests=[];
  for(let i=0;i<n;i++){
   const b=list[i%objects];requests.push(await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]));
  }
  const start=performance.now(),nonces={},allRows=[];
  async function stage(name,indices){const pending=[];const until=await L.now(ctx)+25;
  for(const i of indices){
   const signer=i%3+9,w=ctx.wallets[signer];if(nonces[signer]===undefined)nonces[signer]=await ctx.provider.getTransactionCount(w.address,'pending');
   const data=name==='reserve'?c.interface.encodeFunctionData('reserve',[requests[i].a,requests[i].sigs,until]):c.interface.encodeFunctionData('execute',[requests[i].a,requests[i].sigs]);
   const submitted=performance.now();
   const tx=await w.sendTransaction({to:await c.getAddress(),data,nonce:nonces[signer]++,gasLimit:400000,gasPrice:1000000000n});pending.push({tx,submitted,i});
  }
  const rows=await Promise.all(pending.map(async p=>{let r;try{r=await p.tx.wait()}catch(e){if(e.code!=='CALL_EXCEPTION')throw e;r=e.receipt;}return {stage:name,hash:p.tx.hash,data:p.tx.data,ms:performance.now()-p.submitted,endToEndMs:performance.now()-start,status:r.status,gas:r.gasUsed.toString(),block:r.blockNumber,i:p.i};}));allRows.push(...rows);return rows;}
  let indices=Array.from({length:n},(_,i)=>i);
  if(mode==='reserved'){const r=await stage('reserve',indices);indices=r.filter(x=>x.status===1).map(x=>x.i);}
  const rows=await stage('execute',indices);
  const elapsed=performance.now()-start;const success=rows.filter(r=>r.status===1).length;
  return {profile,mode,objects,attempted:n,transactions:allRows.length,success,ms:elapsed,successPerSecond:success/(elapsed/1000),transactionsPerSecond:allRows.length/(elapsed/1000),rows:allRows};
 }
 for(const [profile,config] of [['loopback',{}],['delay50_jitter20',{delayMs:50,jitterMs:20}],['delay150_jitter50',{delayMs:150,jitterMs:50}]]){
  impairment(config);await delay(3000);
  for(const objects of [1,8,24,48])for(let run=0;run<3;run++)for(const mode of (run%2?['reserved','single']:['single','reserved'])){
   if(results.some(x=>x.profile===profile&&x.objects===objects&&x.mode===mode&&x.run===run))continue;
   const r=await batch(`${profile}-run${run}`,objects,mode);results.push({...r,profile,run});console.log(profile,mode,objects,run,r.success,r.ms.toFixed(1));L.save('ibft4/network-load.json',results);
  }
 }
 impairment({});
 const fault=[];
 // The harness stops selected owned JVMs: omission faults, not equivocation.
 const net=JSON.parse(fs.readFileSync(path.join(dir,'network.json')));
 for(const [label,cut] of [['all_available',[]],['one_omitting',[3]],['two_omitting',[2,3]],['recovered',[]]]){
  fs.writeFileSync(path.join(dir,'fault-request.json'),JSON.stringify({label,stop:cut}));
  await delay(5000);
  const before=Number(BigInt(await rpc(url,'eth_blockNumber'))),start=performance.now();await delay(12000);
  const after=Number(BigInt(await rpc(url,'eth_blockNumber')));const hashes=[];
  for(let i=0;i<net.length;i++)if(!cut.includes(i))try{const b=await rpc(`http://127.0.0.1:${net[i].rpc}`,'eth_getBlockByNumber',['0x'+Math.min(after,before+1).toString(16),false]);hashes.push(b&&b.hash);}catch(e){hashes.push('rpc-error');}
  fault.push({label,cut,before,after,elapsedMs:performance.now()-start,blocks:after-before,hashes});console.log('fault',label,after-before);L.save('ibft4/faults.json',fault);
 }
 impairment({});ctx.provider.destroy();rpcAgent.destroy();
})().catch(e=>{console.error(e);process.exitCode=1});
