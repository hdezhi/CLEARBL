const fs=require('fs'),path=require('path'),ethers=require('ethers');
const root=path.resolve(__dirname,'..');
const Z=ethers.ZeroHash, A0=ethers.ZeroAddress, H=x=>ethers.id(String(x));
const key=i=>'0x'+BigInt(i+101).toString(16).padStart(64,'0'); // Public, funded LOCAL TEST keys only.
const keys=Array.from({length:18},(_,i)=>key(i));
const roles=[3,2,2,4,4,8,8,16,32,64,64,64,2,8,8];
const institutions=roles.map((_,i)=>i===14?7:i+1);
const AT={Action:[['b','bytes32'],['kind','uint8'],['target','address'],['recipient','address'],['ref','bytes32'],['terms','bytes32'],['flags','uint8'],['version','uint256'],['policy','uint256'],['deadline','uint256']].map(([name,type])=>({name,type}))};
const ET={Evidence:[['b','bytes32'],['kind','uint8'],['version','uint256'],['policy','uint256'],['subject','bytes32'],['deadline','uint256']].map(([name,type])=>({name,type}))};
const RT={Rotate:[['oldKey','address'],['newKey','address'],['policy','uint256'],['deadline','uint256']].map(([name,type])=>({name,type}))};
const stringify=x=>JSON.stringify(x,(_,v)=>typeof v==='bigint'?v.toString():v,2);
function artifact(name){return JSON.parse(fs.readFileSync(path.join(root,'build',name+'.json')))}
async function environment(url,options={}){
 let provider,engine;
 if(url){provider=new ethers.JsonRpcProvider(url,undefined,{cacheTimeout:-1,batchMaxCount:1});}
 else {const ganache=require('ganache');engine=ganache.provider({logging:{quiet:true},chain:{chainId:20260929,hardfork:'merge'},wallet:{accounts:keys.map(secretKey=>({secretKey,balance:'0x3635c9adc5dea00000'}))},miner:{blockGasLimit:30000000,instamine:'eager',...(options.miner||{})}});provider=new ethers.BrowserProvider(engine,undefined,{cacheTimeout:-1});}
 provider.pollingInterval=50;
 const wallets=keys.map(k=>new ethers.Wallet(k,provider));
 return {provider,engine,wallets,signers:wallets.map(w=>new ethers.NonceManager(w)),chainId:(await provider.getNetwork()).chainId,rows:[],root};
}
async function deploy(ctx,name,args=[],idx=0){const a=artifact(name);const c=await new ethers.ContractFactory(a.abi,a.evm.bytecode.object,ctx.signers[idx]).deploy(...args);await c.waitForDeployment();return c;}
async function receipt(ctx,label,promise,meta={}){
 const started=performance.now(),tx=await promise;const r=await tx.wait();const elapsed=performance.now()-started;
 const row={label,...meta,hash:tx.hash,block:r.blockNumber,blockHash:r.blockHash,from:tx.from,to:tx.to,nonce:tx.nonce,data:tx.data,gas:r.gasUsed.toString(),status:r.status,ms:elapsed,inputBytes:(tx.data.length-2)/2,logBytes:r.logs.reduce((n,l)=>n+(l.data.length-2)/2+l.topics.length*32,0),logs:r.logs.map(l=>({address:l.address,topics:l.topics,data:l.data}))};ctx.rows.push(row);return row;
}
async function fixture(ctx){
 const directory=await deploy(ctx,'IssuanceDirectory');
 const args=[await directory.getAddress(),false,ctx.wallets.slice(0,15).map(w=>w.address),institutions,roles];
 const single=await deploy(ctx,'ClearBL',args);args[1]=true;const reserved=await deploy(ctx,'ClearBL',args);args[1]=false;const destination=await deploy(ctx,'ClearBL',args);
 for(const c of [single,reserved,destination])await (await directory.enroll(await c.getAddress())).wait();await(await directory.seal()).wait();
 const nft=await deploy(ctx,'ERC721Baseline');return {directory,single,reserved,destination,nft};
}
async function now(ctx){
 for(let attempt=0;attempt<5;attempt++){
  const block=await ctx.provider.getBlock('latest');if(block)return Number(block.timestamp);
  await new Promise(resolve=>setTimeout(resolve,25));
 }
 throw Error('Latest block remained unavailable after five reads');
}
async function domain(ctx,c){return {name:'CLEAR-BL',version:'2',chainId:ctx.chainId,verifyingContract:await c.getAddress()}}
async function action(ctx,c,b,kind,options={}){
 const s=await c.record(b);
 return {b,kind,target:A0,recipient:A0,ref:Z,terms:Z,flags:0,version:s.version,policy:await c.policyEpoch(),deadline:await now(ctx)+600,...options};
}
async function signatures(ctx,c,types,value,indices){const d=await domain(ctx,c);return Promise.all(indices.map(i=>ctx.wallets[i].signTypedData(d,types,value)))}
async function signedAction(ctx,c,b,kind,options,indices){const a=await action(ctx,c,b,kind,options);return {a,sigs:await signatures(ctx,c,AT,a,indices)}}
async function execute(ctx,c,signed,label,reserve=false,meta={}){
 if(reserve)await receipt(ctx,label+'.reserve',c.connect(ctx.signers[12]).reserve(signed.a,signed.sigs,await now(ctx)+25),meta);
 return receipt(ctx,label,c.connect(ctx.signers[12]).execute(signed.a,signed.sigs),meta);
}
async function issue(ctx,c,name,controller=1,meta={}){
 const ref=H(name),b=await c.businessId(ctx.wallets[0].address,ref);
 await receipt(ctx,'issue',c.issue(ref,ctx.wallets[controller].address,ctx.wallets[5].address,H('document:'+name),H('USD:1000:beneficiary:invoice:'+name)),meta);return b;
}
async function evidence(ctx,c,b,kind,indices,options={}){
 const s=await c.record(b);const e={b,kind,version:s.version,policy:await c.policyEpoch(),subject:await c.evidenceSubject(b,kind),deadline:await now(ctx)+900,...options};
 return {e,sigs:await signatures(ctx,c,ET,e,indices|| (kind===0?[5,6]:[0,7]))};
}
async function confirm(ctx,c,b,kind,indices,meta={}){const x=await evidence(ctx,c,b,kind,indices);await receipt(ctx,kind===0?'confirmPay':'confirmDoc',c.connect(ctx.signers[12]).confirm(x.e,x.sigs),meta);return x;}
async function authorize(ctx,c,b,controller=1,reserve=false,meta={}){
 const x=await signedAction(ctx,c,b,4,{target:ctx.wallets[8].address,recipient:ctx.wallets[controller].address,ref:H('job:'+b),terms:H('terminal-A/gate-1')},[0,controller,8]);
 await execute(ctx,c,x,'authorize',reserve,meta);return c.actionDigest(x.a);
}
async function lifecycle(ctx,c,name,reserve=false,meta={}){
 const start=performance.now(),first=ctx.rows.length,b=await issue(ctx,c,name,1,meta);
 await execute(ctx,c,await signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]),'transfer',reserve,meta);
 await execute(ctx,c,await signedAction(ctx,c,b,1,{target:ctx.wallets[3].address,terms:H('claim:'+name),flags:3},[2,3]),'claim',reserve,meta);
 await execute(ctx,c,await signedAction(ctx,c,b,2,{ref:Z},[3]),'discharge',false,meta);
 await confirm(ctx,c,b,0,undefined,meta);await confirm(ctx,c,b,1,undefined,meta);
 const cap=await authorize(ctx,c,b,2,reserve,meta);
 await receipt(ctx,'consume',c.connect(ctx.signers[8]).consume(b,cap),meta);
 const rows=ctx.rows.slice(first);return {b,ms:performance.now()-start,gas:rows.reduce((n,r)=>n+Number(r.gas),0),transactions:rows.length,inputBytes:rows.reduce((n,r)=>n+r.inputBytes,0),logBytes:rows.reduce((n,r)=>n+r.logBytes,0)};
}
function save(name,data){const p=path.join(root,'results',name);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,stringify(data));}
module.exports={root,ethers,Z,A0,H,key,keys,roles,institutions,AT,ET,RT,artifact,environment,deploy,receipt,fixture,now,domain,action,signatures,signedAction,execute,issue,evidence,confirm,authorize,lifecycle,save,stringify};
