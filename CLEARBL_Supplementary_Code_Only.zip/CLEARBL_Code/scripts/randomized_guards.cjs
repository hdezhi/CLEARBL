// Paired randomized schedules, executed against actual EVM contracts.
// Snapshot branches are independent trials; hashes are scoped by trial ID.
const L=require('./lib.cjs'),fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict'),solc=require('solc');
const spec=JSON.parse(fs.readFileSync(path.join(L.root,'experiment-spec18.json'))),pilot=process.argv.includes('--pilot');
const out=path.join(L.root,'results/randomized18'),tag=pilot?'guard-pilot':'guards';
fs.mkdirSync(out,{recursive:true});
const src=fs.readFileSync(path.join(L.root,'contracts/ClearBL.sol'),'utf8');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
function replace(s,a,b){assert.equal(s.split(a).length,2,a);return s.replace(a,b);}
const mutate={
 'full':s=>s,
 'no-business':s=>replace(replace(s,'delete s.pay; delete s.doc; ',''),' && c.version == v',''),
 'no-policy':s=>replace(replace(s,' && c.policy == policyEpoch',''),' && s.capabilityPolicy == policyEpoch',''),
 'no-use-time':s=>replace(s,'require(s.capabilityUntil > block.timestamp && s.capabilityPolicy == policyEpoch && ready(b), "release-not-ready");','// Experimental ablation: no consumption-time readiness check.')
};
function rng(seed){let s=seed>>>0;return()=>{s+=0x6D2B79F5;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
function artifact(name){
 if(name==='full')return L.artifact('ClearBL');
 const content=mutate[name](src),cache=path.join(out,name+'.artifact.json');
 fs.writeFileSync(path.join(out,name+'.sol.txt'),content);
 if(fs.existsSync(cache)){const a=JSON.parse(fs.readFileSync(cache));if(a.sourceSHA256===sha(content))return a.compiled;}
 console.log('Compiling',name);
 const input={language:'Solidity',sources:{'ClearBL.sol':{content}},settings:{optimizer:{enabled:true,runs:200},viaIR:true,evmVersion:'paris',outputSelection:{'*':{'*':['abi','evm.bytecode.object']}}}};
 const result=JSON.parse(solc.compile(JSON.stringify(input),{import:p=>({contents:fs.readFileSync(path.join(L.root,'node_modules',p),'utf8')})}));
 assert.ok(!(result.errors||[]).some(e=>e.severity==='error'),JSON.stringify(result.errors));
 const compiled=result.contracts['ClearBL.sol'].ClearBL;
 fs.writeFileSync(cache,JSON.stringify({sourceSHA256:sha(content),compiled}));return compiled;
}
(async()=>{
 const started=new Date().toISOString(),variants=spec.guardCampaign.variants,builds=Object.fromEntries(variants.map(v=>[v,artifact(v)]));
 const ctx=await L.environment(),fixtures={};
 // All variants start with issued objects and two valid source certificates.
 for(const mode of spec.guardCampaign.modes)for(const variant of variants){
  const d=await L.deploy(ctx,'IssuanceDirectory'),a=builds[variant];
  const c=await new L.ethers.ContractFactory(a.abi,a.evm.bytecode.object,ctx.signers[0]).deploy(await d.getAddress(),mode==='reserved',ctx.wallets.slice(0,15).map(w=>w.address),L.institutions,L.roles);
  await c.waitForDeployment();await(await d.enroll(await c.getAddress())).wait();await(await d.seal()).wait();
  const b=await L.issue(ctx,c,tag+'-'+mode+'-'+variant);await L.confirm(ctx,c,b,0);await L.confirm(ctx,c,b,1);
  fixtures[mode+'/'+variant]={c,b};
 }
 const baseTime=await L.now(ctx);let snap=await ctx.provider.send('evm_snapshot',[]);
 const raw=path.join(out,tag+'-receipts.jsonl'),result=path.join(out,tag+'-trials.jsonl');fs.writeFileSync(raw,'');fs.writeFileSync(result,'');
 const probabilities=pilot?[0,.6,1]:spec.guardCampaign.probabilities,seeds=pilot?[18000]:spec.seeds,nt=pilot?2:spec.guardCampaign.trialsPerSeed;
 let count=0;const rows=[];
 for(const seed of seeds){
  // Same uniforms at each p provide coupled sensitivity curves as well as paired variants.
  const rand=rng(seed),schedules=Array.from({length:nt},(_,trial)=>({trial,uBusiness:rand(),uPolicy:rand(),uDelay:rand(),delay:Math.floor(rand()*91),ttl:[30,45,60][Math.floor(rand()*3)]}));
  for(const p of probabilities)for(const schedule of schedules){
   const descriptor={...schedule,business:schedule.uBusiness<p,policy:schedule.uPolicy<p,elapsed:schedule.uDelay<p?schedule.delay:0};
   descriptor.invalid=descriptor.business||descriptor.policy||descriptor.elapsed>=descriptor.ttl;
   const variantOrder=[...variants.slice((seed+schedule.trial)%4),...variants.slice(0,(seed+schedule.trial)%4)];
   for(const mode of (seed%2?['direct','reserved']:['reserved','direct']))for(const variant of variantOrder){
    assert.equal(await ctx.provider.send('evm_revert',[snap]),true);snap=await ctx.provider.send('evm_snapshot',[]);ctx.signers.forEach(s=>s.reset());ctx.rows=[];
    await ctx.provider.send('evm_setTime',[baseTime*1000]);await ctx.provider.send('evm_mine',[]);
    const {c,b}=fixtures[mode+'/'+variant],id=[seed,p,schedule.trial,mode,variant].join('/'),receipts=[];
    async function mine(stage,invoke){
     const tx=await invoke();let r;try{r=await tx.wait();}catch(e){if(!e.receipt)throw e;r=e.receipt;}
     const row={id,stage,hash:tx.hash,status:r.status,gas:Number(r.gasUsed),block:r.blockNumber,blockHash:r.blockHash,data:tx.data,from:tx.from,to:tx.to};receipts.push(row);fs.appendFileSync(raw,L.stringify(row).replace(/\n\s*/g,'')+'\n');return r.status;
    }
    let controller=1;
    if(descriptor.business){
     const x=await L.signedAction(ctx,c,b,0,{target:ctx.wallets[2].address},[1,2]);
     assert.equal(await mine('transfer',()=>c.connect(ctx.signers[12]).execute(x.a,x.sigs,{gasLimit:2000000})),1);controller=2;
    }
    const authorizationTime=await L.now(ctx),x=await L.signedAction(ctx,c,b,4,{target:ctx.wallets[8].address,recipient:ctx.wallets[controller].address,ref:L.H('job:'+seed+':'+schedule.trial),terms:L.H('location'),deadline:authorizationTime+descriptor.ttl},[0,controller,8]);
    let accepted=1;
    if(mode==='reserved')accepted=await mine('reserve',()=>c.connect(ctx.signers[12]).reserve(x.a,x.sigs,authorizationTime+Math.min(25,descriptor.ttl),{gasLimit:2000000}));
    if(accepted)accepted=await mine('authorize',()=>c.connect(ctx.signers[12]).execute(x.a,x.sigs,{gasLimit:2000000}));
    let consumed=0;
    if(accepted){
     if(descriptor.policy){
      const v={oldKey:ctx.wallets[5].address,newKey:ctx.wallets[15].address,policy:await c.policyEpoch(),deadline:authorizationTime+600},sigs=await L.signatures(ctx,c,L.RT,v,[9,10,5]);
      assert.equal(await mine('rotate',()=>c.rotateKey(v.oldKey,v.newKey,v.deadline,sigs,{gasLimit:2000000})),1);
     }
     await ctx.provider.send('evm_setTime',[(authorizationTime+descriptor.elapsed)*1000]);await ctx.provider.send('evm_mine',[]);
     const cap=await c.actionDigest(x.a),before=L.stringify(await c.record(b));
     consumed=await mine('consume',()=>c.connect(ctx.signers[8]).consume(b,cap,{gasLimit:2000000}));
     if(!consumed)assert.equal(L.stringify(await c.record(b)),before,'revert must preserve state');
    }
    const row={id,seed,p,mode,variant,...descriptor,acceptedAuthorization:accepted,consumed,correct:Number(Boolean(consumed)===!descriptor.invalid),gas:receipts.reduce((n,r)=>n+r.gas,0),transactions:receipts.length};
    if(variant==='full')assert.equal(row.correct,1,L.stringify(row));
    rows.push(row);fs.appendFileSync(result,JSON.stringify(row)+'\n');count++;
   }
  }
  console.log(tag,'seed',seed,'trials',count,'correct full',rows.filter(r=>r.variant==='full').every(r=>r.correct));
 }
 const manifest={started,completed:new Date().toISOString(),engine:await ctx.provider.send('web3_clientVersion',[]),sourceSHA256:sha(src),specificationSHA256:sha(fs.readFileSync(path.join(L.root,'experiment-spec18.json'))),trials:rows.length,receiptSHA256:sha(fs.readFileSync(raw)),trialsSHA256:sha(fs.readFileSync(result)),pilot,snapshotScope:'Each trial is an independent snapshot branch; transaction hashes are not globally unique across branches.'};
 L.save('randomized18/'+tag+'-manifest.json',manifest);console.log('COMPLETE',JSON.stringify(manifest));await ctx.engine.disconnect();ctx.provider.destroy();
})().catch(e=>{console.error(e);process.exitCode=1;});
