# Run network_bench.cjs and export_permits.cjs first to create input permits.
"""Crash/restart campaign with separate durable dispatcher and mock actuator DBs.

Replays retained local-IBFT receipts under their documented trusted-RPC finality
assumption. A SQLite transaction simulates atomic effect+deduplication; no physical
gate or live bank is used. os._exit models abrupt process death at each boundary.
"""
from pathlib import Path
import hashlib,json,sqlite3,subprocess,sys,tempfile,os

FIELDS=('chainId','contract','businessId','capability','terminal','beneficiary','job','location')
ASSIGNED='0x997cf669860A1DCC76344866534D8679A7B562E2'
def payload(p):return json.dumps({k:p[k] for k in FIELDS},sort_keys=True,separators=(',',':'))
def identity(p):return f"{p['chainId']}:{p['contract']}:{p['capability']}"
def connect(p):
 c=sqlite3.connect(p,timeout=20);c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA synchronous=FULL');return c
def die(actual,wanted):
 if actual==wanted:os._exit(71)

def worker(folder,permit,cut='',atomic=True):
 folder=Path(folder);p=json.loads(Path(permit).read_text());key=identity(p);body=payload(p)
 if not p['finalized'] or p['agreeingRPCs']<3 or p['terminal']!=ASSIGNED:raise ValueError('receipt provenance/terminal')
 # Input receipt provenance was checked by the export harness; this program does
 # not independently verify IBFT seals or infer finality from an arbitrary boolean.
 j=connect(folder/'jobs.sqlite');a=connect(folder/'actuator.sqlite')
 j.execute('CREATE TABLE IF NOT EXISTS jobs(task TEXT PRIMARY KEY, payload TEXT, done INT)')
 a.executescript('CREATE TABLE IF NOT EXISTS effects(task TEXT PRIMARY KEY, payload TEXT, effects INT); CREATE TABLE IF NOT EXISTS markers(task TEXT PRIMARY KEY);')
 die('before_accept',cut)
 old=j.execute('SELECT payload FROM jobs WHERE task=?',(key,)).fetchone()
 if old and old[0]!=body:raise ValueError('conflicting task payload')
 with j:j.execute('INSERT OR IGNORE INTO jobs VALUES(?,?,0)',(key,body))
 die('after_accept',cut)
 if j.execute('SELECT done FROM jobs WHERE task=?',(key,)).fetchone()[0]:return
 die('before_effect',cut)
 if atomic:
  with a:
   old=a.execute('SELECT payload FROM effects WHERE task=?',(key,)).fetchone()
   if old and old[0]!=body:raise ValueError('actuator payload mismatch')
   a.execute('INSERT OR IGNORE INTO effects VALUES(?,?,1)',(key,body))
 else:
  # Negative control: effect and durable marker are separate commits.
  if not a.execute('SELECT 1 FROM markers WHERE task=?',(key,)).fetchone():
   with a:a.execute('INSERT INTO effects VALUES(?,?,1) ON CONFLICT(task) DO UPDATE SET effects=effects+1',(key,body))
   die('after_effect',cut)
   with a:a.execute('INSERT INTO markers VALUES(?)',(key,))
 die('after_effect',cut)
 with j:j.execute('UPDATE jobs SET done=1 WHERE task=?',(key,))
 die('after_ack',cut)
 a.close();j.close()

def run():
 root=Path(__file__).parents[1];source=root/'results/ibft4/consumed-permits.json';permits=json.loads(source.read_text());cases=[]
 cuts=['before_accept','after_accept','before_effect','after_effect','after_ack']
 with tempfile.TemporaryDirectory(prefix='clearbl-release-') as td:
  td=Path(td)
  for i,p in enumerate(permits):
   for cut in cuts:
    folder=td/f'{i}-{cut}';folder.mkdir();f=folder/'permit.json';f.write_text(json.dumps(p))
    def invoke(c='',atomic=True):
     return subprocess.run([sys.executable,__file__,'worker',str(folder),str(f),c,str(int(atomic))],capture_output=True,text=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    abrupt=invoke(cut);assert abrupt.returncode==71,(cut,abrupt.stderr)
    for _ in range(3):
     ok=invoke();assert ok.returncode==0,ok.stderr
    a=connect(folder/'actuator.sqlite');effect=a.execute('SELECT effects FROM effects').fetchone()[0];a.close();j=connect(folder/'jobs.sqlite');done=j.execute('SELECT done FROM jobs').fetchone()[0];j.close();assert effect==done==1
    cases.append({'receiptTransaction':p['transaction'],'cut':cut,'crashExit':abrupt.returncode,'restarts':3,'effects':effect,'acknowledged':done})
  # Actual process crash negative control, kept separate from safe profiles.
  folder=td/'unsafe';folder.mkdir();f=folder/'permit.json';f.write_text(json.dumps(permits[0]))
  def unsafe(c):return subprocess.run([sys.executable,__file__,'worker',str(folder),str(f),c,'0'],capture_output=True,text=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  assert unsafe('after_effect').returncode==71;assert unsafe('').returncode==0
  a=connect(folder/'actuator.sqlite');twice=a.execute('SELECT effects FROM effects').fetchone()[0];a.close();assert twice==2
  # Rebinding a previously accepted capability to a different task is rejected.
  f.write_text(json.dumps({**permits[0],'location':'altered-location'}));mismatch=unsafe('');assert mismatch.returncode!=0 and 'conflicting task payload' in mismatch.stderr
 out={'receiptSourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'finality':'Inherited from retained receipt export: >=3 trusted RPCs; no independent seal verification','physicalModel':'Two SQLite databases, atomic mock-actuator effect+deduplication; no physical cargo','cases':cases,'unsafeSplitCommitEffects':twice,'conflictingPayloadRejected':True}
 path=root/'results/revision8/release-crashes.json';path.parent.mkdir(exist_ok=True);path.write_text(json.dumps(out,indent=2));print(json.dumps({'safeCases':len(cases),'crashPoints':len(cuts),'actualRetainedReceipts':len(permits),'negativeControlEffects':twice}))
if __name__=='__main__':
 if len(sys.argv)>1:worker(sys.argv[2],sys.argv[3],sys.argv[4],bool(int(sys.argv[5])))
 else:run()
