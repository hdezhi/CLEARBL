"""Dispatch actual exported local-IBFT permits to an idempotent mock terminal."""
import json,pathlib,tempfile
from gateway import Gateway
root=pathlib.Path(__file__).parents[1]
permits=json.loads((root/'results/ibft4/consumed-permits.json').read_text())
results=[]
with tempfile.TemporaryDirectory() as d:
    p=pathlib.Path(d)/'gateway.sqlite'
    for i,permit in enumerate(permits):
        # Fixed enrolled demonstration terminal, not a value trusted from input.
        assigned='0x997cf669860A1DCC76344866534D8679A7B562E2'  # Public local-test key 109.
        assert permit['terminal']==assigned and permit['agreeingRPCs']>=3
        # Namespaced task identity prevents cross-domain/cross-chain digest reuse.
        task=f"{permit['chainId']}:{permit['contract']}:{permit['capability']}"
        g=Gateway(p);g.accept(task,permit['terminal'],permit['finalized'],assigned)
        try:g.dispatch(task,True)
        except RuntimeError:pass
        g.close();g=Gateway(p);g.accept(task,permit['terminal'],True,assigned);g.dispatch(task);g.dispatch(task)
        n=g.db.execute('SELECT COUNT(*) FROM gate_receipts WHERE cap=?',(task,)).fetchone()[0];g.close()
        assert n==1;results.append({'transaction':permit['transaction'],'task':task,'mockExecutions':n,'crashAndRetry':True})
(root/'results/ibft4/gateway-receipts.json').write_text(json.dumps(results,indent=2))
print(f'{len(results)} finalized receipt tasks, one idempotent mock execution each')
