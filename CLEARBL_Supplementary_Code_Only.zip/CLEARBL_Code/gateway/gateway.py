"""Durable dispatcher demonstration with an explicitly IDEMPOTENT mock terminal.
Caller must supply a verified finalized Consumed event; this demo is not a
ledger light client or a physical terminal integration.
"""
import sqlite3,pathlib,json,tempfile
class Gateway:
    def __init__(self,path):
        self.db=sqlite3.connect(path)
        self.db.executescript('CREATE TABLE IF NOT EXISTS jobs(cap TEXT PRIMARY KEY, terminal TEXT, state TEXT); CREATE TABLE IF NOT EXISTS gate_receipts(cap TEXT PRIMARY KEY);')
    def accept(self,cap,terminal,finalized,assigned_terminal):
        if not finalized or terminal!=assigned_terminal:raise ValueError('unfinalized/wrong terminal')
        with self.db:self.db.execute('INSERT OR IGNORE INTO jobs VALUES(?,?,?)',(cap,terminal,'pending'))
    def dispatch(self,cap,crash_after_gate=False):
        row=self.db.execute('SELECT state FROM jobs WHERE cap=?',(cap,)).fetchone()
        if not row:raise ValueError('no consumed permit')
        # Separate durable idempotent actuator: a physical production device must
        # implement this task-id deduplication, or the exactly-once claim fails.
        with self.db:self.db.execute('INSERT OR IGNORE INTO gate_receipts VALUES(?)',(cap,))
        if crash_after_gate:raise RuntimeError('simulated crash after gate before acknowledgement')
        with self.db:self.db.execute('UPDATE jobs SET state=? WHERE cap=?',('done',cap))
    def close(self):self.db.close()
if __name__=='__main__':
    results=[]
    with tempfile.TemporaryDirectory() as d:
        p=pathlib.Path(d)/'gateway.sqlite';g=Gateway(p)
        for cap,term,final,expected in [('unfinal','T',False,False),('wrong','X',True,False),('ok','T',True,True)]:
            try:g.accept(cap,term,final,'T');accepted=True
            except ValueError:accepted=False
            assert accepted==expected;results.append({'case':cap,'accepted':accepted,'expected':expected})
        try:g.dispatch('ok',True)
        except RuntimeError:pass
        g.close();g=Gateway(p);g.accept('ok','T',True,'T')
        g.dispatch('ok');g.dispatch('ok');n=g.db.execute('SELECT COUNT(*) FROM gate_receipts').fetchone()[0]
        assert n==1;results.append({'case':'crash/restart/retry','physical_mock_receipts':n,'requires_idempotent_actuator':True});g.close()
    out=pathlib.Path(__file__).parents[1]/'results/gateway.json';out.write_text(json.dumps(results,indent=2));print(json.dumps(results))
