// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;
import {ClearBL} from "./ClearBL.sol";

/// @notice Explicitly consented intercreditor-priority extension of the core.
/// @dev Immutable seq identifies a claim; array position is current contractual rank.
///      This profile must be declared at enrollment. It does not adjudicate outside liens.
contract ClearBLPriority is ClearBL {
    uint8 public constant REPRIORITIZE = 8;
    event PriorityChanged(bytes32 indexed b, uint256 version, bytes32 previousOrder, bytes32 nextOrder);
    constructor(address dir, bool reservations, address[] memory keys, uint256[] memory institutions, uint256[] memory roles)
        ClearBL(dir, reservations, keys, institutions, roles) {}

    function priorityOrder(bytes32 b) public view returns (uint256[] memory order) {
        order = new uint256[](claims[b].length);
        for (uint256 i; i < order.length; i++) order[i] = claims[b][i].seq;
    }
    /// @notice The complete new order is signed in a.terms; a.ref commits the old order.
    /// @dev Every active financier and the controller consents, including creditors
    ///      whose bits are zero. No signature authorizes removing a claim or its terms.
    function reprioritize(Action calldata a, uint256[] calldata order, bytes[] calldata signatures) external {
        _active(a.b); _deadline(a.deadline);
        Record storage s = records[a.b];
        require(s.pending == bytes32(0), "pending-priority");
        require(a.kind == REPRIORITIZE && a.version == s.version && a.policy == policyEpoch, "priority-context");
        require(a.target == address(0) && a.recipient == address(0) && a.flags == 0, "priority-fields");
        uint256[] memory old = priorityOrder(a.b);
        require(order.length >= 2 && order.length == old.length, "priority-length");
        bytes32 beforeHash = keccak256(abi.encode(old));
        bytes32 afterHash = keccak256(abi.encode(order));
        require(a.ref == beforeHash && a.terms == afterHash && beforeHash != afterHash, "priority-commitment");
        bytes32 digest = actionDigest(a);
        address[] memory signers = _signers(digest, signatures);
        require(_has(signers, s.controller), "controller-consent");
        Claim[] memory ordered = new Claim[](old.length);
        for (uint256 i; i < old.length; i++) {
            require(_has(signers, claims[a.b][i].financier), "financier-consent");
            uint256 index = _claimIndex(a.b, order[i]);
            for (uint256 j; j < i; j++) require(order[j] != order[i], "duplicate-claim");
            ordered[i] = claims[a.b][index];
        }
        // Validate all inputs before any write. The permutation preserves each claim.
        for (uint256 i; i < old.length; i++) claims[a.b][i] = ordered[i];
        _bump(a.b);
        emit PriorityChanged(a.b, s.version, beforeHash, afterHash);
        emit Transition(a.b, REPRIORITIZE, s.version, digest);
    }
}
