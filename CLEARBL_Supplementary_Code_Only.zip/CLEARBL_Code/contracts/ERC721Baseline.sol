// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;
import {ERC721} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
/// @notice Thin issuance wrapper; all transfer authorization is unmodified OZ 5.4.0.
contract ERC721Baseline is ERC721 {
    address public immutable issuer;
    constructor() ERC721("eBL control baseline", "EBL") { issuer = msg.sender; }
    function issue(address recipient, uint256 id) external {
        require(msg.sender == issuer, "issuer"); _mint(recipient, id);
    }
}
