// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;
import {ClearBL, IssuanceDirectory} from "./ClearBL.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";

/// @notice Permanent obligation admission shared by all participating issuers.
/// @dev Enrollment is sealed before use; an adapter may claim only its namespace.
contract ObligationAdmissionRegistry {
    address public immutable owner = msg.sender;
    IssuanceDirectory public immutable directory;
    bool public isSealed;
    mapping(address => bytes32) public namespaceOf;
    mapping(bytes32 => address) public admittedBy;
    constructor(address dir) { directory = IssuanceDirectory(dir); }
    function enroll(address adapter, bytes32 carrierNamespace) external {
        require(msg.sender == owner && !isSealed && adapter.code.length != 0 && carrierNamespace != bytes32(0), "registry-enrollment");
        require(namespaceOf[adapter] == bytes32(0), "registry-already-enrolled");
        namespaceOf[adapter] = carrierNamespace;
    }
    function seal() external { require(msg.sender == owner && !isSealed, "registry-owner"); isSealed = true; }
    function claim(bytes32 carrierReference) external returns (bytes32 o) {
        bytes32 ns = namespaceOf[msg.sender];
        require(isSealed && directory.isSealed() && ns != bytes32(0), "registry-adapter");
        o = keccak256(abi.encode(ns, carrierReference));
        require(admittedBy[o] == address(0), "registry-duplicate-obligation");
        admittedBy[o] = msg.sender;
    }
}

/// @notice IssuanceDirectory-compatible admission gate, also covering rotated keys.
/// @dev Core domains use the same ABI. Only an admitted adapter may stage issuance;
///      a bare ISSUER credential, including one obtained by rotation, is insufficient.
contract AdmittedIssuanceDirectory {
    address public immutable setupAuthority = msg.sender;
    bool public isSealed;
    ObligationAdmissionRegistry public admissionRegistry;
    mapping(address => bool) public domain;
    mapping(bytes32 => address) public current;
    mapping(bytes32 => address) public previous;
    mapping(bytes32 => uint256) public moves;
    mapping(bytes32 => address) public stagedDomain;
    event Assigned(bytes32 indexed businessId, address indexed source, address indexed destination);
    function bindRegistry(address registry) external {
        require(msg.sender == setupAuthority && !isSealed && address(admissionRegistry) == address(0), "directory-registry");
        require(address(ObligationAdmissionRegistry(registry).directory()) == address(this), "registry-directory");
        admissionRegistry = ObligationAdmissionRegistry(registry);
    }
    function enroll(address d) external {
        require(msg.sender == setupAuthority && !isSealed && d.code.length > 0, "setup"); domain[d] = true;
    }
    function seal() external {
        require(msg.sender == setupAuthority && address(admissionRegistry) != address(0) && admissionRegistry.isSealed(), "setup"); isSealed = true;
    }
    function stage(bytes32 obligationId, address target) external {
        require(isSealed && domain[target] && admissionRegistry.admittedBy(obligationId) == msg.sender, "admitted-adapter");
        uint256 institution = AdmittedIssuer(msg.sender).issuerInstitution();
        bytes32 b = keccak256(abi.encode(institution, obligationId));
        require(current[b] == address(0) && stagedDomain[b] == address(0), "directory-staged");
        stagedDomain[b] = target;
    }
    function issue(bytes32 b) external {
        require(isSealed && domain[msg.sender] && current[b] == address(0) && stagedDomain[b] == msg.sender, "unadmitted-issue");
        delete stagedDomain[b]; current[b] = msg.sender;
        emit Assigned(b, address(0), msg.sender);
    }
    function move(bytes32 b, address destination) external {
        require(domain[msg.sender] && domain[destination] && current[b] == msg.sender && destination != msg.sender, "domain");
        previous[b] = msg.sender; current[b] = destination; moves[b]++;
        emit Assigned(b, msg.sender, destination);
    }
}

/// @notice Carrier-endorsed issuance admission for an enrolled single-shipment profile.
/// @dev Enroll this contract as the ONLY ISSUER credential of its institution in
///      every participating domain; the human issuer signing key has PARTY role.
///      Canonical carrier reference reconciliation remains a carrier obligation.
contract AdmittedIssuer is EIP712 {
    struct Admission {
        address target; bytes32 carrierReference; bytes32 platformAlias;
        address controller; address bank; bytes32 document; bytes32 paymentTerms;
        uint256 deadline;
    }
    bytes32 public constant TYPEHASH = keccak256("Admission(address target,bytes32 carrierReference,bytes32 platformAlias,address controller,address bank,bytes32 document,bytes32 paymentTerms,uint256 deadline)");
    bytes32 public constant WITHDRAW_TYPEHASH = keccak256("WithdrawDocument(address target,bytes32 b,uint256 version,uint256 policy,uint256 deadline)");
    IssuanceDirectory public immutable directory;
    ObligationAdmissionRegistry public immutable admissionRegistry;
    address public immutable issuerSigner;
    address public immutable carrierSigner;
    uint256 public immutable issuerInstitution;
    bytes32 public immutable carrierNamespace;
    mapping(bytes32 => bool) public admitted;
    event Admitted(bytes32 indexed obligation, bytes32 indexed businessId, address target, bytes32 platformAlias);
    constructor(address registry, address issuer, address carrier, uint256 institution, bytes32 carrierId)
        EIP712("CLEAR-BL-Admission", "1") {
        require(issuer != address(0) && carrier != address(0) && issuer != carrier && institution != 0 && carrierId != bytes32(0), "admission-config");
        admissionRegistry = ObligationAdmissionRegistry(registry);
        directory = admissionRegistry.directory(); issuerSigner = issuer; carrierSigner = carrier;
        issuerInstitution = institution; carrierNamespace = carrierId;
    }
    function obligation(bytes32 carrierReference) public view returns (bytes32) {
        return keccak256(abi.encode(carrierNamespace, carrierReference));
    }
    function digest(Admission calldata a) public view returns (bytes32) {
        return _hashTypedDataV4(keccak256(abi.encode(TYPEHASH, a)));
    }
    function _institutionSigned(ClearBL c, bytes32 signed, bytes calldata signature, uint256 institution, uint256 requiredRole) internal view returns (bool) {
        (uint256 id, uint256 roles) = c.identities(ECDSA.recover(signed, signature));
        return id == institution && id != 0 && roles != 0 && (requiredRole == 0 || (roles & requiredRole) != 0);
    }
    function issue(Admission calldata a, bytes calldata issuerSignature, bytes calldata carrierSignature) external returns (bytes32 b) {
        require(a.deadline > block.timestamp && a.deadline <= block.timestamp + 3600, "admission-deadline");
        require(a.carrierReference != bytes32(0) && a.platformAlias != bytes32(0), "admission-reference");
        require(directory.isSealed() && directory.domain(a.target), "admission-domain");
        ClearBL c = ClearBL(a.target);
        require(address(c.directory()) == address(directory) && c.institutionOf(address(this)) == issuerInstitution, "admission-profile");
        bytes32 signed = digest(a);
        uint256 carrierInstitution = c.institutionOf(carrierSigner);
        require(c.institutionOf(issuerSigner) == issuerInstitution && carrierInstitution != issuerInstitution, "admission-institutions");
        require(_institutionSigned(c, signed, issuerSignature, issuerInstitution, 0) && _institutionSigned(c, signed, carrierSignature, carrierInstitution, c.DOC_CHECKER()), "admission-signatures");
        bytes32 o = obligation(a.carrierReference);
        require(!admitted[o], "duplicate-obligation");
        require(admissionRegistry.namespaceOf(address(this)) == carrierNamespace, "registry-namespace");
        require(admissionRegistry.claim(a.carrierReference) == o, "registry-obligation");
        admitted[o] = true;
        AdmittedIssuanceDirectory(address(directory)).stage(o, a.target);
        b = c.issue(o, a.controller, a.bank, a.document, a.paymentTerms);
        emit Admitted(o, b, a.target, a.platformAlias);
    }
    /// @notice Preserve the source-withdrawal path when this adapter owns ISSUER role.
    function withdrawDocument(address target, bytes32 b, uint256 deadline, bytes calldata signature) external {
        require(directory.domain(target) && deadline > block.timestamp && deadline <= block.timestamp + 3600, "withdraw-context");
        ClearBL c = ClearBL(target);
        require(address(c.directory()) == address(directory) && c.institutionOf(address(this)) == issuerInstitution, "withdraw-profile");
        ClearBL.Record memory s = c.record(b);
        require(s.issuer == address(this), "withdraw-issuer");
        bytes32 signed = _hashTypedDataV4(keccak256(abi.encode(WITHDRAW_TYPEHASH, target, b, s.version, c.policyEpoch(), deadline)));
        require(_institutionSigned(c, signed, signature, issuerInstitution, 0), "withdraw-signature");
        c.revokeEvidence(b, 1);
    }
}
