// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";

/// @notice Shared issuance directory for enrolled domains on ONE ledger.
/// @dev The directory does not discover fraudulent external business identifiers.
contract IssuanceDirectory {
    address public immutable setupAuthority;
    bool public isSealed;
    mapping(address => bool) public domain;
    mapping(bytes32 => address) public current;
    mapping(bytes32 => address) public previous;
    mapping(bytes32 => uint256) public moves;
    event Assigned(bytes32 indexed businessId, address indexed source, address indexed destination);
    constructor() { setupAuthority = msg.sender; }
    function enroll(address d) external {
        require(msg.sender == setupAuthority && !isSealed && d.code.length > 0, "setup");
        domain[d] = true;
    }
    function seal() external { require(msg.sender == setupAuthority, "setup"); isSealed = true; }
    function issue(bytes32 b) external {
        require(isSealed && domain[msg.sender] && current[b] == address(0), "duplicate/domain");
        current[b] = msg.sender;
        emit Assigned(b, address(0), msg.sender);
    }
    function move(bytes32 b, address destination) external {
        require(domain[msg.sender] && domain[destination] && current[b] == msg.sender, "domain");
        require(destination != msg.sender, "same-domain");
        previous[b] = msg.sender; current[b] = destination; moves[b]++;
        emit Assigned(b, msg.sender, destination);
    }
}

/// @notice Revision reference implementation; newly built, not the original prototype.
/// @dev Direct execution is default. Optional reservations do NOT supply fairness.
contract ClearBL is EIP712 {
    uint256 public constant ISSUER = 1;
    uint256 public constant PARTY = 2;
    uint256 public constant FINANCIER = 4;
    uint256 public constant BANK = 8;
    uint256 public constant DOC_CHECKER = 16;
    uint256 public constant TERMINAL = 32;
    uint256 public constant GOVERNOR = 64;
    uint256 public constant MAX_CLAIMS = 16;
    uint256 public constant MAX_SIGNATURES = 24;
    uint256 public constant MAX_LIFETIME = 3600;
    uint256 public constant MAX_RESERVATION = 30;
    uint256 public constant PAYMENT_QUORUM = 2;
    uint256 public constant GOVERNANCE_QUORUM = 2;
    enum Phase { Absent, Active, Authorized, Consumed, Migrated }
    enum Kind { Transfer, Claim, Discharge, Waive, Release, Freeze, Recover, Migrate }
    struct Identity { uint256 institution; uint256 roles; }
    struct Claim { uint256 seq; address financier; bytes32 terms; uint8 blocks; }
    struct Evidence { bytes32 b; uint8 kind; uint256 version; uint256 policy; bytes32 subject; uint256 deadline; }
    struct Certificate { bytes32 digest; uint256 version; uint256 policy; uint256 deadline; }
    struct Action {
        bytes32 b; uint8 kind; address target; address recipient; bytes32 ref;
        bytes32 terms; uint8 flags; uint256 version; uint256 policy; uint256 deadline;
    }
    struct Record {
        address issuer; address controller; address bank;
        bytes32 document; bytes32 paymentTerms;
        uint256 version; uint256 nextClaim;
        Phase phase; bool frozen;
        bytes32 pending; uint256 pendingUntil; uint256 pendingPolicy;
        uint256 reservedVersionPlusOne;
        Certificate pay; Certificate doc;
        bytes32 capability; address terminal; address beneficiary;
        bytes32 job; bytes32 location; uint256 capabilityUntil; uint256 capabilityPolicy;
    }
    bytes32 public constant ACTION_TYPEHASH = keccak256("Action(bytes32 b,uint8 kind,address target,address recipient,bytes32 ref,bytes32 terms,uint8 flags,uint256 version,uint256 policy,uint256 deadline)");
    bytes32 public constant EVIDENCE_TYPEHASH = keccak256("Evidence(bytes32 b,uint8 kind,uint256 version,uint256 policy,bytes32 subject,uint256 deadline)");
    bytes32 public constant ROTATE_TYPEHASH = keccak256("Rotate(address oldKey,address newKey,uint256 policy,uint256 deadline)");
    IssuanceDirectory public immutable directory;
    bool public immutable reservationsEnabled;
    uint256 public policyEpoch = 1;
    bytes32 public identityProfile;
    mapping(address => Identity) public identities;
    mapping(bytes32 => Record) internal records;
    mapping(bytes32 => Claim[]) internal claims;
    event Transition(bytes32 indexed b, uint8 indexed kind, uint256 version, bytes32 digest);
    event Issued(bytes32 indexed b, address issuer, address controller, bytes32 document, bytes32 paymentTerms);
    event Reserved(bytes32 indexed b, bytes32 digest, uint256 until);
    event ReservationExpired(bytes32 indexed b, bytes32 digest);
    event EvidenceAccepted(bytes32 indexed b, uint8 kind, bytes32 digest, uint256 version, uint256 policy, uint256 deadline);
    event Consumed(bytes32 indexed b, bytes32 indexed capability, address terminal, address beneficiary, bytes32 job, bytes32 location);
    event KeyRotated(address oldKey, address newKey, uint256 policy);
    event Invalidated(bytes32 indexed b, uint256 version, uint8 reason);

    constructor(address dir, bool reservations, address[] memory keys, uint256[] memory institutions, uint256[] memory roles)
        EIP712("CLEAR-BL", "2") {
        require(keys.length == institutions.length && keys.length == roles.length, "identity-length");
        directory = IssuanceDirectory(dir); reservationsEnabled = reservations;
        identityProfile = keccak256(abi.encode(keys, institutions, roles));
        for (uint256 i; i < keys.length; i++) {
            require(keys[i] != address(0) && institutions[i] != 0 && identities[keys[i]].institution == 0, "identity");
            identities[keys[i]] = Identity(institutions[i], roles[i]);
        }
    }
    function record(bytes32 b) external view returns (Record memory) { return records[b]; }
    function activeClaims(bytes32 b) external view returns (Claim[] memory) { return claims[b]; }
    function businessId(address issuer, bytes32 documentReference) public view returns (bytes32) {
        require(_role(issuer, ISSUER), "issuer");
        return keccak256(abi.encode(identities[issuer].institution, documentReference));
    }
    function issue(bytes32 documentReference, address controller, address bank, bytes32 document, bytes32 paymentTerms) external returns (bytes32 b) {
        require(_role(msg.sender, ISSUER) && _role(controller, PARTY) && _role(bank, BANK), "role");
        require(document != bytes32(0) && paymentTerms != bytes32(0), "subject");
        b = businessId(msg.sender, documentReference);
        require(records[b].phase == Phase.Absent, "duplicate");
        directory.issue(b);
        Record storage s = records[b];
        s.issuer = msg.sender; s.controller = controller; s.bank = bank;
        s.document = document; s.paymentTerms = paymentTerms; s.phase = Phase.Active;
        emit Issued(b, msg.sender, controller, document, paymentTerms);
    }
    function actionDigest(Action calldata a) public view returns (bytes32) {
        return _hashTypedDataV4(keccak256(abi.encode(ACTION_TYPEHASH, a)));
    }
    function evidenceDigest(Evidence calldata e) public view returns (bytes32) {
        return _hashTypedDataV4(keccak256(abi.encode(EVIDENCE_TYPEHASH, e)));
    }
    function evidenceSubject(bytes32 b, uint8 kind) public view returns (bytes32) {
        Record storage s = records[b];
        require(kind < 2 && s.phase != Phase.Absent, "kind/object");
        return keccak256(abi.encode(b, s.version, s.controller, kind == 0 ? s.paymentTerms : s.document));
    }
    function _role(address who, uint256 role) internal view returns (bool) { return (identities[who].roles & role) != 0; }
    function _sameInstitution(address x, address y) internal view returns (bool) {
        return identities[x].institution != 0 && identities[x].institution == identities[y].institution;
    }
    function _signers(bytes32 digest, bytes[] calldata signatures) internal view returns (address[] memory out) {
        require(signatures.length > 0 && signatures.length <= MAX_SIGNATURES, "signature-count");
        out = new address[](signatures.length);
        for (uint256 i; i < signatures.length; i++) {
            address signer = ECDSA.recover(digest, signatures[i]);
            require(identities[signer].institution != 0 && identities[signer].roles != 0, "unknown-signer");
            for (uint256 j; j < i; j++) require(!_sameInstitution(signer, out[j]), "duplicate-institution");
            out[i] = signer;
        }
    }
    function _has(address[] memory signers, address who) internal view returns (bool) {
        for (uint256 i; i < signers.length; i++) if (_sameInstitution(signers[i], who)) return true;
        return false;
    }
    function _count(address[] memory signers, uint256 role) internal view returns (uint256 n) {
        for (uint256 i; i < signers.length; i++) if (_role(signers[i], role)) n++;
    }
    function _deadline(uint256 deadline) internal view {
        require(deadline > block.timestamp && deadline <= block.timestamp + MAX_LIFETIME, "deadline");
    }
    function _live(bytes32 b) internal view {
        require(directory.current(b) == address(this), "inactive-domain");
        require(records[b].phase != Phase.Absent && records[b].phase != Phase.Consumed && records[b].phase != Phase.Migrated, "terminal-state");
    }
    function _active(bytes32 b) internal view {
        _live(b); require(records[b].phase == Phase.Active && !records[b].frozen, "not-active");
    }
    function _fresh(Certificate storage c, uint256 v) internal view returns (bool) {
        return c.digest != bytes32(0) && c.version == v && c.policy == policyEpoch && c.deadline > block.timestamp;
    }
    function ready(bytes32 b) public view returns (bool) {
        Record storage s = records[b];
        if (s.frozen || !_fresh(s.pay, s.version) || !_fresh(s.doc, s.version)) return false;
        for (uint256 i; i < claims[b].length; i++) if ((claims[b][i].blocks & 2) != 0) return false;
        return true;
    }
    function _bump(bytes32 b) internal {
        Record storage s = records[b]; s.version++;
        delete s.pay; delete s.doc; delete s.pending; delete s.pendingUntil; delete s.pendingPolicy;
        delete s.capability; delete s.terminal; delete s.beneficiary; delete s.job; delete s.location;
        delete s.capabilityUntil; delete s.capabilityPolicy;
        if (s.phase == Phase.Authorized) s.phase = Phase.Active;
    }
    function _claimIndex(bytes32 b, uint256 seq) internal view returns (uint256) {
        for (uint256 i; i < claims[b].length; i++) if (claims[b][i].seq == seq) return i;
        revert("claim-missing");
    }
    function _check(Action calldata a, address[] memory signers) internal view {
        Record storage s = records[a.b];
        _live(a.b); _deadline(a.deadline);
        require(a.version == s.version && a.policy == policyEpoch && a.kind <= uint8(Kind.Migrate), "context");
        if (a.kind == uint8(Kind.Freeze)) {
            require(!s.frozen && _count(signers, GOVERNOR) >= GOVERNANCE_QUORUM, "governance"); return;
        }
        if (a.kind == uint8(Kind.Recover)) {
            require(s.frozen && _count(signers, GOVERNOR) >= GOVERNANCE_QUORUM, "recovery-governance");
            require(_has(signers, s.issuer) && _has(signers, s.controller) && _role(a.target, BANK), "recovery-consent");
            for (uint256 i; i < claims[a.b].length; i++) require(_has(signers, claims[a.b][i].financier), "financier-consent");
            return;
        }
        _active(a.b);
        if (a.kind == uint8(Kind.Transfer)) {
            require(_has(signers, s.controller) && _has(signers, a.target) && _role(a.target, PARTY) && !_sameInstitution(s.controller, a.target), "transfer-consent");
            for (uint256 i; i < claims[a.b].length; i++) if ((claims[a.b][i].blocks & 1) != 0) require(_has(signers, claims[a.b][i].financier), "financier-consent");
        } else if (a.kind == uint8(Kind.Claim)) {
            require(_has(signers, s.controller) && _has(signers, a.target) && _role(a.target, FINANCIER), "claim-consent");
            require(claims[a.b].length < MAX_CLAIMS && uint256(a.ref) == s.nextClaim && a.flags <= 3 && a.terms != bytes32(0), "claim-input");
        } else if (a.kind == uint8(Kind.Discharge) || a.kind == uint8(Kind.Waive)) {
            Claim storage c = claims[a.b][_claimIndex(a.b, uint256(a.ref))];
            require(_has(signers, c.financier), "financier-consent");
            if (a.kind == uint8(Kind.Waive)) require(a.flags < c.blocks && (a.flags | c.blocks) == c.blocks, "waiver-only");
        } else if (a.kind == uint8(Kind.Release)) {
            require(ready(a.b) && _has(signers, s.controller) && _has(signers, s.issuer) && _has(signers, a.target), "release-consent/ready");
            require(_role(a.target, TERMINAL) && _sameInstitution(a.recipient, s.controller) && a.ref != bytes32(0) && a.terms != bytes32(0), "release-target");
            require(a.deadline <= s.pay.deadline && a.deadline <= s.doc.deadline, "certificate-expiry");
        } else if (a.kind == uint8(Kind.Migrate)) {
            require(directory.domain(a.target) && a.target != address(this), "destination");
            require(_has(signers, s.issuer) && _has(signers, s.controller), "migration-consent");
            for (uint256 i; i < claims[a.b].length; i++) require(_has(signers, claims[a.b][i].financier), "financier-consent");
        }
    }
    /// @notice Optional fully authorized reservation. One reservation per business version.
    function reserve(Action calldata a, bytes[] calldata signatures, uint256 until) external {
        require(reservationsEnabled && (a.kind == 0 || a.kind == 1 || a.kind == 4), "reservation-kind");
        Record storage s = records[a.b];
        bytes32 digest = actionDigest(a); _check(a, _signers(digest, signatures));
        require(s.pending == bytes32(0) && s.reservedVersionPlusOne != s.version + 1, "reservation-budget");
        require(until > block.timestamp && until <= block.timestamp + MAX_RESERVATION && until <= a.deadline, "reservation-deadline");
        s.pending = digest; s.pendingUntil = until; s.pendingPolicy = policyEpoch;
        s.reservedVersionPlusOne = s.version + 1;
        emit Reserved(a.b, digest, until);
    }
    /// @notice Any relayer may submit a fully signed action; every guard is rechecked here.
    function execute(Action calldata a, bytes[] calldata signatures) external {
        Record storage s = records[a.b]; bytes32 digest = actionDigest(a);
        _check(a, _signers(digest, signatures));
        bool governance = a.kind == uint8(Kind.Freeze) || a.kind == uint8(Kind.Recover);
        if (!governance && s.pending != bytes32(0)) require(s.pending == digest && s.pendingUntil > block.timestamp && s.pendingPolicy == policyEpoch, "reservation-conflict");
        if (a.kind == uint8(Kind.Transfer)) { s.controller = a.target; _bump(a.b); }
        else if (a.kind == uint8(Kind.Claim)) {
            claims[a.b].push(Claim(s.nextClaim++, a.target, a.terms, a.flags)); _bump(a.b);
        } else if (a.kind == uint8(Kind.Discharge)) {
            uint256 index = _claimIndex(a.b, uint256(a.ref));
            for (uint256 i = index; i + 1 < claims[a.b].length; i++) claims[a.b][i] = claims[a.b][i+1];
            claims[a.b].pop(); _bump(a.b);
        } else if (a.kind == uint8(Kind.Waive)) { claims[a.b][_claimIndex(a.b, uint256(a.ref))].blocks = a.flags; _bump(a.b); }
        else if (a.kind == uint8(Kind.Release)) {
            s.phase = Phase.Authorized; s.capability = digest; s.terminal = a.target; s.beneficiary = a.recipient;
            s.job = a.ref; s.location = a.terms; s.capabilityUntil = a.deadline; s.capabilityPolicy = policyEpoch;
            delete s.pending; delete s.pendingUntil; delete s.pendingPolicy;
        } else if (a.kind == uint8(Kind.Freeze)) { s.frozen = true; _bump(a.b); }
        else if (a.kind == uint8(Kind.Recover)) { s.frozen = false; s.bank = a.target; _bump(a.b); }
        else if (a.kind == uint8(Kind.Migrate)) {
            _bump(a.b); s.phase = Phase.Migrated;
            directory.move(a.b, a.target);
            ClearBL(a.target).importRecord(a.b, s, claims[a.b]);
        }
        emit Transition(a.b, a.kind, s.version, digest);
    }
    function confirm(Evidence calldata e, bytes[] calldata signatures) external {
        _active(e.b); Record storage s = records[e.b]; _deadline(e.deadline);
        require(s.pending == bytes32(0) && e.version == s.version && e.policy == policyEpoch && e.kind < 2, "context/lock");
        require(e.subject == evidenceSubject(e.b, e.kind), "subject");
        bytes32 digest = evidenceDigest(e); address[] memory signers = _signers(digest, signatures);
        if (e.kind == 0) require(_has(signers, s.bank) && _count(signers, BANK) >= PAYMENT_QUORUM, "payment-policy");
        else {
            require(_has(signers, s.issuer), "issuer-evidence");
            bool independent;
            for (uint256 i; i < signers.length; i++) if (_role(signers[i], DOC_CHECKER) && !_sameInstitution(signers[i], s.issuer)) independent = true;
            require(independent, "document-policy");
        }
        Certificate memory c = Certificate(digest, e.version, e.policy, e.deadline);
        if (e.kind == 0) s.pay = c; else s.doc = c;
        emit EvidenceAccepted(e.b, e.kind, digest, e.version, e.policy, e.deadline);
    }
    function consume(bytes32 b, bytes32 capability) external {
        _live(b); Record storage s = records[b];
        require(s.phase == Phase.Authorized && !s.frozen && s.capability == capability, "capability");
        require(_sameInstitution(msg.sender, s.terminal) && _role(msg.sender, TERMINAL), "terminal");
        require(s.capabilityUntil > block.timestamp && s.capabilityPolicy == policyEpoch && ready(b), "release-not-ready");
        s.phase = Phase.Consumed;
        emit Consumed(b, capability, s.terminal, s.beneficiary, s.job, s.location);
    }
    function expire(bytes32 b) external {
        _live(b); Record storage s = records[b];
        if (s.pending != bytes32(0)) {
            require(block.timestamp >= s.pendingUntil || s.pendingPolicy != policyEpoch, "not-expired");
            bytes32 old = s.pending; delete s.pending; delete s.pendingUntil; delete s.pendingPolicy;
            emit ReservationExpired(b, old);
        } else {
            require(s.phase == Phase.Authorized && (block.timestamp >= s.capabilityUntil || s.capabilityPolicy != policyEpoch), "not-expired");
            _bump(b); emit Invalidated(b, s.version, 0);
        }
    }
    /// @notice An authoritative source can withdraw its own assertion before consumption.
    function revokeEvidence(bytes32 b, uint8 kind) external {
        _live(b); Record storage s = records[b];
        require((kind == 0 && _role(msg.sender, BANK) && _sameInstitution(msg.sender, s.bank)) || (kind == 1 && _role(msg.sender, ISSUER) && _sameInstitution(msg.sender, s.issuer)), "source");
        _bump(b); emit Invalidated(b, s.version, 1);
    }
    function rotateKey(address oldKey, address newKey, uint256 deadline, bytes[] calldata signatures) external {
        _deadline(deadline);
        require(identities[oldKey].roles != 0 && identities[newKey].institution == 0 && newKey != address(0), "key");
        bytes32 digest = _hashTypedDataV4(keccak256(abi.encode(ROTATE_TYPEHASH, oldKey, newKey, policyEpoch, deadline)));
        address[] memory signers = _signers(digest, signatures);
        require(_count(signers, GOVERNOR) >= GOVERNANCE_QUORUM, "governance");
        require(_has(signers, oldKey), "institution-consent");
        // Keep identity references resolvable, but remove the old key's signing roles.
        identities[newKey] = identities[oldKey]; identities[oldKey].roles = 0;
        identityProfile = keccak256(abi.encode(identityProfile, oldKey, newKey));
        policyEpoch++; emit KeyRotated(oldKey, newKey, policyEpoch);
    }
    /// @notice Atomic same-ledger domain migration; NOT a trustless cross-chain bridge.
    function importRecord(bytes32 b, Record calldata incoming, Claim[] calldata incomingClaims) external {
        require(directory.domain(msg.sender) && directory.current(b) == address(this) && directory.previous(b) == msg.sender, "migration-source");
        require(records[b].phase == Phase.Absent || records[b].phase == Phase.Migrated, "already-active");
        require(incoming.phase == Phase.Migrated && !incoming.frozen && incomingClaims.length <= MAX_CLAIMS, "migration-state");
        require(identityProfile == ClearBL(msg.sender).identityProfile() && policyEpoch == ClearBL(msg.sender).policyEpoch(), "identity-profile");
        require(identities[incoming.issuer].institution == ClearBL(msg.sender).institutionOf(incoming.issuer), "identity-mapping");
        // Stored references may name revoked keys; authorization resolves institutions.
        require(identities[incoming.controller].institution != 0 && identities[incoming.bank].institution != 0, "identity-mapping");
        records[b] = incoming; records[b].phase = Phase.Active;
        delete claims[b];
        for (uint256 i; i < incomingClaims.length; i++) {
            require(identities[incomingClaims[i].financier].institution != 0, "financier-mapping");
            claims[b].push(incomingClaims[i]);
        }
        emit Transition(b, uint8(Kind.Migrate), incoming.version, bytes32(uint256(uint160(msg.sender))));
    }
    function institutionOf(address key) external view returns (uint256) { return identities[key].institution; }
}
