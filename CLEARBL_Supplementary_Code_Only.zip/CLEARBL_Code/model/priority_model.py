"""Exhaustive priority-order transitions for up to four immutable claim IDs.
Checks permutations, all consent subsets, deletion and append. Not a Solidity
refinement proof; the separate EVM tests execute the implementation.
"""
from itertools import permutations,combinations
from pathlib import Path
import json

checks=0;authorized=0;rejected=0;traces=[]
for n in range(2,5):
 ids=tuple(range(n));parties=tuple(range(n+1)) # controller n; distinct financiers 0..n-1
 for before in permutations(ids):
  for after in permutations(ids):
   if before==after:continue
   for size in range(n+2):
    for consent in combinations(parties,size):
     accepted=set(consent)==set(parties);checks+=1
     final=after if accepted else before
     if accepted:
      authorized+=1;assert len(set(final))==n and set(final)==set(before)
      for e in final:
       surviving=tuple(x for x in final if x!=e)
       assert all(surviving.index(x)<surviving.index(y) for x in surviving for y in surviving if final.index(x)<final.index(y))
       appended=surviving+(n,);assert appended[-1]==n and len(set(appended))==n
     else:rejected+=1;assert final==before
   if after.index(0)>before.index(0) and not traces:
    traces.append({'before':before,'proposed':after,'controllerOnly':n,'unsafeWithoutFinancierConsent':after,'protected':before})
out={'bound':'2..4 active claims; all before/after nonidentity permutations and all institutional consent subsets','checks':checks,'accepted':authorized,'rejected':rejected,'omittedConsentCounterexample':traces}
p=Path(__file__).parents[1]/'results/revision8/priority-model.json';p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(out,indent=2));print(json.dumps(out))
