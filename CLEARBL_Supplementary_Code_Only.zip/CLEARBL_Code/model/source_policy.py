"""Synthetic fact adapters and exact policy cut sets; no live bank connector.

This layer decides whether an institution should sign. The on-chain contract
checks who signed and the subject/context; it cannot verify these observations.
"""
from pathlib import Path
import itertools,json,hashlib,copy
ROOT=Path(__file__).resolve().parents[1]

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()

def payment_decision(expected,observation,now,max_age=60):
    fields=('payment_ref','amount_minor','currency','beneficiary_account','settlement_profile')
    if any(observation.get(k)!=expected[k] for k in fields):return False,'subject-mismatch'
    if observation.get('status')!='credited':return False,'not-beneficiary-credit'
    if observation.get('final_under_profile') is not True:return False,'finality-unconfirmed'
    stamp=observation.get('observed_at')
    if not isinstance(stamp,int) or not 0<=now-stamp<=max_age:return False,'stale-or-future-observation'
    return True,'eligible-to-sign'

def document_decision(expected,observation,now,max_age=60):
    if observation.get('document_digest')!=expected['document_digest']:return False,'wrong-document'
    if observation.get('operative_reference')!=expected['operative_reference']:return False,'wrong-reference'
    if observation.get('issuer_signature_valid') is not True:return False,'invalid-issuer-signature'
    if observation.get('presented') is not True or observation.get('revoked') is not False:return False,'presentation-or-revocation'
    if not 0<=now-observation.get('observed_at',-10**9)<=max_age:return False,'stale-or-future-observation'
    return True,'eligible-to-sign'

def pay_policy(s):return 'S' in s and bool({'V1','V2'}&s)
def doc_policy(s):return {'I','D'}<=s

def minimal(sets):return [sorted(s) for s in sets if not any(t<s for t in sets)]
def powerset(names):
    return [set(c) for n in range(len(names)+1) for c in itertools.combinations(names,n)]

def main():
    expected={'payment_ref':'synthetic-payment-01','amount_minor':100000,'currency':'USD','beneficiary_account':'synthetic-beneficiary','settlement_profile':'agreed-profile-v1'}
    base={**expected,'status':'credited','final_under_profile':True,'observed_at':1000};cases=[]
    changes=[('valid',{},True),('instruction-only',{'status':'sent'},False),('held',{'status':'held'},False),('rejected',{'status':'rejected'},False),('forwarded',{'status':'forwarded'},False),('wrong-amount',{'amount_minor':99999},False),('wrong-beneficiary',{'beneficiary_account':'other'},False),('wrong-reference',{'payment_ref':'other'},False),('wrong-currency',{'currency':'EUR'},False),('unknown-finality',{'final_under_profile':False},False),('stale',{'observed_at':900},False),('future',{'observed_at':1010},False)]
    for name,patch,wanted in changes:
        obs={**base,**patch};accepted,reason=payment_decision(expected,obs,1000);assert accepted==wanted
        cases.append({'id':'P-'+name,'observation':obs,'accepted':accepted,'reason':reason,'observationSHA256':hashlib.sha256(canonical(obs)).hexdigest()})
    de={'document_digest':'synthetic-digest','operative_reference':'synthetic-reference'}
    db={**de,'issuer_signature_valid':True,'presented':True,'revoked':False,'observed_at':1000}
    for name,patch,wanted in [('valid',{},True),('wrong-document',{'document_digest':'other'},False),('wrong-reference',{'operative_reference':'other'},False),('invalid-signature',{'issuer_signature_valid':False},False),('not-presented',{'presented':False},False),('revoked',{'revoked':True},False),('stale',{'observed_at':900},False)]:
        obs={**db,**patch};accepted,reason=document_decision(de,obs,1000);assert accepted==wanted
        cases.append({'id':'D-'+name,'observation':obs,'accepted':accepted,'reason':reason})
    policies={}
    for name,names,policy in [('payment',['S','V1','V2'],pay_policy),('document',['I','D'],doc_policy)]:
        subsets=powerset(names)
        policies[name]={'allSubsets':[{'members':sorted(s),'accepted':policy(s)} for s in subsets],
          'minimalDishonestCoalitions_assumingAccurateHonestObservation':minimal([s for s in subsets if policy(s)]),
          'minimalUnavailableSets':minimal([s for s in subsets if not policy(set(names)-s)])}
    assert policies['payment']['minimalDishonestCoalitions_assumingAccurateHonestObservation']==[['S','V1'],['S','V2']]
    assert policies['payment']['minimalUnavailableSets']==[['S'],['V1','V2']]
    # All institutions can honestly parse a common false record: signatures then
    # attest agreement on that record, not independent truth of settlement.
    correlated={'groundTruthPaid':False,'sharedInput':base,'signers':[s for s in ['S','V1','V2'] if payment_decision(expected,base,1000)[0]]}
    correlated['contractPolicyAccepts']=pay_policy(set(correlated['signers']));assert correlated['contractPolicyAccepts']
    out={'scope':'synthetic adapter tests and exhaustive finite source-policy enumeration','adapterCases':cases,'policies':policies,'commonSourceCounterexample':correlated,
      'limits':['observations are synthetic','finality flag supplied by agreed external source/profile','separate institution keys do not prove independent observations','contract does not execute these Python checks']}
    p=ROOT/'results/source-policy.json';p.write_text(json.dumps(out,indent=2),encoding='utf-8');print(f'{len(cases)} adapter cases; 12 source subsets; common-source counterexample retained')
if __name__=='__main__':main()
