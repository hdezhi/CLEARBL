"""Explicit-state finite abstraction, not Solidity verification or an unbounded proof.
One issued object, two controllers, two claims, versions <=3, policy <=1,
logical clock <=3. Signatures abstracted to valid current-context authorizations.
All enabled transitions in the finite domain are explored to a fixed point.
"""
from dataclasses import dataclass,replace,asdict
from collections import deque,Counter
import json,pathlib,time
@dataclass(frozen=True,slots=True)
class S:
    t:int=0;v:int=0;g:int=0;holder:int=0;seq:int=0;claims:tuple=()
    pay:tuple=();doc:tuple=();phase:str='active';frozen:bool=False
    pending:tuple=();reserved:bool=False;cap:tuple=();consumes:int=0;domain:int=0
MAXV=3;MAXT=3
def bump(s,**kw):
    return replace(s,v=s.v+1,pay=(),doc=(),pending=(),reserved=False,cap=(),phase='active',**kw)
def fresh(s,c):return bool(c) and c[0]==s.v and c[1]==s.g and c[2]>s.t
def ready(s,mutation=None):
    if mutation=='no_freshness':return not s.claims and bool(s.pay) and bool(s.doc) and not s.frozen
    return not s.claims and fresh(s,s.pay) and fresh(s,s.doc) and not s.frozen
def successors(s,mutation=None):
    if s.t<MAXT:yield 'tick',replace(s,t=s.t+1)
    if s.g<1:yield 'rotate_policy',replace(s,g=s.g+1)
    if s.phase=='consumed':
        if mutation=='no_consumption_guard' and s.consumes<2:yield 'consume_again',replace(s,consumes=s.consumes+1)
        return
    if s.phase=='authorized':
        if ready(s,mutation) and s.cap[2]>s.t and (s.cap[1]==s.g or mutation=='no_freshness'):
            yield 'consume',replace(s,phase='consumed',consumes=s.consumes+1)
        if s.v<MAXV and (s.cap[2]<=s.t or s.cap[1]!=s.g):yield 'expire_authorization',bump(s)
    if s.v<MAXV:
        if not s.frozen:yield 'freeze',bump(s,frozen=True)
        else:yield 'recover',bump(s,frozen=False)
        yield 'withdraw_source',bump(s)
    if s.frozen or s.phase!='active':return
    if s.pending:
        k,target,v,g,until=s.pending
        if until<=s.t or g!=s.g:yield 'expire_reservation',replace(s,pending=())
        elif v==s.v:
            if k=='transfer' and s.v<MAXV:yield 'commit_transfer',bump(s,holder=target)
            if k=='claim' and s.v<MAXV and len(s.claims)<2:yield 'commit_claim',bump(s,claims=s.claims+(s.seq,),seq=s.seq+1)
            if k=='release' and ready(s,mutation):yield 'commit_release',replace(s,pending=(),phase='authorized',cap=(s.v,s.g,until))
        return
    # Full source authorizations are abstract tokens. Replayed token choices are
    # enumerated separately and admitted only by the same context comparisons.
    for token_v in range(s.v+1):
        for token_g in range(s.g+1):
            if token_v!=s.v or token_g!=s.g:continue
            cert=(token_v,token_g,MAXT+1)
            yield 'confirm_pay',replace(s,pay=cert)
            yield 'confirm_doc',replace(s,doc=cert)
    if s.v<MAXV:
        yield 'transfer',bump(s,holder=1-s.holder)
        if len(s.claims)<2:yield 'claim',bump(s,claims=s.claims+(s.seq,),seq=s.seq+1)
        for seq in s.claims:yield 'discharge',bump(s,claims=tuple(x for x in s.claims if x!=seq))
        # Domain move is an atomic directory transfer in the Solidity artifact.
        yield 'migrate',bump(s,domain=1-s.domain)
    if ready(s,mutation):yield 'authorize',replace(s,phase='authorized',cap=(s.v,s.g,MAXT+1))
    if not s.reserved and s.t<MAXT:
        for k in ['transfer','claim','release']:
            if k=='release' and not ready(s,mutation):continue
            if k=='claim' and len(s.claims)>=2:continue
            if k!='release' and s.v>=MAXV:continue
            yield 'reserve_'+k,replace(s,pending=(k,1-s.holder,s.v,s.g,s.t+1),reserved=True)
def violation(old,action,new):
    if new.consumes>1:return 'at-most-once consumption'
    if tuple(sorted(set(new.claims)))!=new.claims:return 'ordered active claims'
    if action in ('authorize','commit_release','consume') and not ready(old):return 'fresh evidence at authorization/consumption'
    if old.phase=='consumed' and action not in ('tick','rotate_policy') and new!=old:return 'terminal object immutability'
    if action.startswith('reserve_') and old.reserved:return 'one reservation per version'
    if action in ('commit_transfer','commit_claim','commit_release'):
        if not old.pending or old.pending[2]!=old.v or old.pending[3]!=old.g or old.pending[4]<=old.t:return 'commit context'
    return None
def explore(mutation=None):
    start=time.perf_counter();initial=S();seen={initial};parents={initial:None};q=deque([initial]);edges=0;counts=Counter()
    while q:
        s=q.popleft()
        for action,n in successors(s,mutation):
            edges+=1;counts[action]+=1;failure=violation(s,action,n)
            if failure:
                trace=[{'action':action,'state':asdict(n)}];p=s
                while parents[p] is not None:
                    prev,a=parents[p];trace.append({'action':a,'state':asdict(p)});p=prev
                trace.append({'action':'initial','state':asdict(initial)});trace.reverse()
                return {'mutation':mutation,'failure':failure,'states':len(seen),'edges':edges,'trace':trace,'seconds':time.perf_counter()-start}
            if n not in seen:seen.add(n);parents[n]=(s,action);q.append(n)
    return {'mutation':mutation,'failure':None,'states':len(seen),'edges':edges,'actions':dict(counts),'seconds':time.perf_counter()-start,'fixed_point':True}
def migration(mutant=False):
    # Distributed recovery sketch, distinct from the atomic same-ledger adapter.
    # (source_active, source_retired, transfer_decided, destination_active, ack)
    initial=(True,False,False,False,False);parents={initial:None};q=deque([initial]);edges=0
    while q:
        s=q.popleft();src,retired,decided,dst,ack=s;nexts=[]
        if src and not decided:nexts.append(('retire_source',(False,True,False,False,False)))
        if retired and not decided:nexts.extend([('commit_directory',(False,True,True,False,False)),('abort_before_decision',initial)])
        if decided and not dst:nexts.append(('activate_destination',(False,True,True,True,False)))
        if dst and not ack:nexts.append(('ack',(False,True,True,True,True)))
        if mutant and decided and not ack:nexts.append(('unsafe_timeout_reopen',(True,retired,decided,dst,ack)))
        for a,n in nexts:
            edges+=1
            if n[0] and n[3]:
                trace=[a];p=s
                while parents[p] is not None:p,a=parents[p];trace.append(a)
                return {'failure':'two operative domains','trace':list(reversed(trace)),'states':len(parents),'edges':edges}
            if n not in parents:parents[n]=(s,a);q.append(n)
    return {'failure':None,'states':len(parents),'edges':edges,'fixed_point':True}
if __name__=='__main__':
    results={'bounds':{'versions':MAXV,'clock':MAXT,'policy_updates':1,'controllers':2,'max_claims':2,'objects':1},'core':explore(),'mutants':[explore('no_freshness'),explore('no_consumption_guard')],'migration':migration(),'migration_mutant':migration(True)}
    assert results['core']['failure'] is None and results['core']['fixed_point']
    assert all(x['failure'] is not None for x in results['mutants']) and results['migration_mutant']['failure']
    out=pathlib.Path(__file__).parents[1]/'results/model.json';out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(results,indent=2))
    print(json.dumps({k:v for k,v in results.items() if k not in ('mutants','migration_mutant')},indent=2))
